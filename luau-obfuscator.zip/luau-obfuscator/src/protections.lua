-- protections.lua :: supplementary hardening layer (works alongside
-- protection.lua's Anti-Tamper guard and the Integrity re-seal watchdog)
--
-- Provides:
--   * P.mangler(rng)  -- deterministic per-build identifier renaming for
--                       emitted interpreter regions
--   * P.extras(ctx)   -- anti-envlog channel canary (print/warn/error
--                       snapshots + behavioral fingerprints re-checked at
--                       boot) plus dumper bait decoy constants
--
-- Everything is portable Lua 5.1..5.4 / LuaJIT / Roblox Luau.

local bitutil = require("bitutil")

local P = {}

------------------------------------------------------------------ mangler
local TOKCHARS =
  "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_0123456789"

function P.mangler(rng)
  local map, inv, order = {}, {}, {}
  local function tok()
    local len = rng.int(7, 13)
    local t = {}
    for _ = 1, len do
      local pos = rng.int(1, #TOKCHARS)
      t[#t + 1] = TOKCHARS:sub(pos, pos)
    end
    -- underscore AND digit guaranteed: cannot collide with english words,
    -- magic literals, or comment text baked into output.
    return "_" .. table.concat(t) .. rng.int(0, 99)
  end
  local m = {}
  function m.add(base)
    assert(map[base] == nil, "mangler: duplicate base " .. base)
    local nm
    repeat nm = tok() until not inv[nm]
    inv[nm] = true
    map[base] = nm
    order[#order + 1] = base
    return nm
  end
  function m.apply(src)
    -- longest-first so shorter bases never shadow longer ones
    -- (_str before _strref would corrupt both).
    local sorted = {}
    for _, b in ipairs(order) do sorted[#sorted + 1] = b end
    table.sort(sorted, function(a, b) return #a > #b end)
    for _, b in ipairs(sorted) do
      src = src:gsub("%f[%w_]" .. b .. "%f[%W]", map[b])
    end
    return src
  end
  function m.name(base) return assert(map[base], "mangler: unknown " .. base) end
  return m
end

------------------------------------------------------------------ extras (Multi-Layered Garbage)
local DECOY_LABELS_L1 = {
  "MASTER", "INNER", "SEAL", "VAULT", "GUARD", "KEYRING",
}
local DECOY_LABELS_L2 = {
  "GARBAGE", "JUNK", "FAKE", "DECOY", "TRASH", "NOISE",
}
local DECOY_LABELS_L3 = {
  "VM_GARBAGE", "CONTROL_FLOW", "OPAQUE", "BAIT", "FAKE_OP", "JUNK_PROTO",
}
local DECOY_LABELS = DECOY_LABELS_L1

local hexblob = function(rng, n)
  local t = {}
  for _ = 1, n do t[#t + 1] = ("%02x"):format(rng.int(0, 255)) end
  return table.concat(t)
end

-- ctx: { fail="...", mockery="...", rng=<build rng> }
-- Emits: pristine channel snapshot + behavioral error fingerprint +
-- __skx_canary_recheck() + decoy bait constants. Body symbols are locally
-- unique via a dedicated sub-mangler so it composes safely anywhere.
function P.extras(ctx)
  local fail = ctx.fail or "__mock"
  local mrng = ctx.rng or bitutil.newrng(20240827)

  local n = {}
  local m = P.mangler(mrng)
  for _, base in ipairs({
    "PRINT0", "GREF", "WARN0", "CAP", "RECHECK", "ERRFP", "ERRMSG",
    "DECAY", "SUBF", "BCHAR", "CONCATF", "ORACLE",
  }) do n[base] = m.add("PX_" .. base) end

  -- Multi-Layered Garbage: 3 layers of decoy bait
  local decoys = {}
  -- Layer 1: Original 6 labels
  for i = 1, #DECOY_LABELS_L1 do
    decoys[#decoys+1] = ('["SKX/%s/%03d"]="%s\\0%d"'):format(
      DECOY_LABELS_L1[i], mrng.int(1, 999),
      hexblob(mrng, mrng.int(16, 48)), mrng.int(100000000, 999999999))
  end
  -- Layer 2: Garbage labels (6 more)
  for i = 1, #DECOY_LABELS_L2 do
    decoys[#decoys+1] = ('["GARBAGE/%s/%03d"]="%s\\0%d"'):format(
      DECOY_LABELS_L2[i], mrng.int(1, 999),
      hexblob(mrng, mrng.int(24, 64)), mrng.int(100000000, 999999999))
  end
  -- Layer 3: VM garbage labels (6 more) + fake control flow decoys
  for i = 1, #DECOY_LABELS_L3 do
    decoys[#decoys+1] = ('["VM/%s/%03d"]="%s\\0%d"'):format(
      DECOY_LABELS_L3[i], mrng.int(1, 999),
      hexblob(mrng, mrng.int(32, 80)), mrng.int(100000000, 999999999))
  end
  -- Extra layer: fake control-flow garbage (looks like real code but is dead)
  for i = 1, mrng.int(3, 6) do
    decoys[#decoys+1] = ('["FAKE/CTRL/%03d"]="if\\0%d\\0while\\0%d"'):format(
      mrng.int(1, 999), mrng.int(1, 100), mrng.int(1, 100))
  end

  local salt = ("%05d"):format(mrng.int(1, 99999))

  return ([=[
do
  local ]=] .. n.GREF .. [=[=_G or _ENV
  local ]=] .. n.PRINT0 .. [=[=print
  local ]=] .. n.WARN0 .. [=[=rawget(]=] .. n.GREF .. [=[,"warn")
  local ]=] .. n.SUBF .. [=[=string.sub
  local ]=] .. n.BCHAR .. [=[=string.byte
  local ]=] .. n.CONCATF .. [=[=table.concat

  -- expanded execution oracle (language/kernel contract)
  local function ]=] .. n.ORACLE .. [=[()
    if type(]=] .. n.SUBF .. [=[)~="function" or type(]=] .. n.BCHAR .. [=[)~="function"
       or type(]=] .. n.CONCATF .. [=[)~="function" then return true end
    if ]=] .. n.SUBF .. [=[("SKYNX",2,4)~="KYN" then return true end
    if string.format("%d|%s|%.3f",42,"x",0.125)~="42|x|0.125" then return true end
    if ("abc"):rep(2)~="abcabc" or #("xy\0z")~=4 then return true end
    if math.floor(-2.5)~=-3 or math.max(1,9)~=9 then return true end
    if not (tostring(12345)=="12345") then return true end
    local okc,c=pcall(function() return select("#",1,nil,3) end)
    if not okc or c~=3 then return true end
    local cwrap=coroutine and coroutine.wrap
    if type(cwrap)~="function" then return true end
    local co=cwrap(function(v) local got,y=coroutine.yield(v+1); return got*10 end)
    if co(41)~=42 or co(7)~=70 then return true end
    local oke,eb=pcall(error,"@@px@@")
    if oke or eb~="@@px@@" then return true end
    return false
  end
  do
    local ok,bad=pcall(]=] .. n.ORACLE .. [=[)
    if not ok or bad then ]=] .. fail .. [=[() end
  end
  -- anti env logger: httplog/sandbox hook trap - honeypot
  do
    local _, s = pcall(function(...) string.byte("a", function(...) return; end, 9999, 38); end)
    if s and (s:find(string.char(104,116,116,112,108,111,103)) or s:find(string.char(115,97,110,100,98,111,120))) then
      -- try to load fake honeypot if available
      if type(__SKX_FAKE)=="string" and type(__SKX_FAKE_KEY)=="number" then
        local ok, _ = pcall(function()
          local v=__SKX_FAKE_KEY%4294967296
          if v==0 then v=222222229 end
          local out={}
          for i=1,#__SKX_FAKE do
            v=(v*1103515245+12345)%4294967296
            out[i]=string.char((__SKX_FAKE:byte(i) - v%256)%256)
          end
          local fake=table.concat(out)
          local f=load or loadstring
          if f then local ok2,fn=pcall(f,fake) if ok2 and type(fn)=="function" then pcall(fn) end end
        end)
      end
      while true do end
    end
  end

  -- dumper bait pool: fake key material that wastes analyst time
  local ]=] .. n.DECAY .. [=[={]=] .. table.concat(decoys, ",") .. [=[}

  -- anti-envlog canary: snapshot pristine channels now, compare at boot
  ]=] .. n.ERRMSG .. [=[="\1canary_\1]=] .. salt .. [=["
  local __cae,__cer=pcall(error,]=] .. n.ERRMSG .. [=[)
  if __cae or __cer~=]=] .. n.ERRMSG .. [=[ then ]=] .. fail .. [=[() end
  ]=] .. n.CAP .. [=[={
    pf=(type(print)=="function") and tostring(print) or "",
    pr=]=] .. n.PRINT0 .. [=[,
    wr=]=] .. n.WARN0 .. [=[,
    wf=]=] .. n.WARN0 .. [=[ and tostring(]=] .. n.WARN0 .. [=[) or "",
    ef=tostring(error),
  }
  function __skx_canary_recheck()
    local g=]=] .. n.GREF .. [=[
    local wr=rawget(g,"warn")
    if (wr==nil)~=(]=] .. n.CAP .. [=[.wr==nil) then ]=] .. fail .. [=[() end
    if wr~=nil and tostring(wr)~=]=] .. n.CAP .. [=[.wf then ]=] .. fail .. [=[() end
    if tostring(error)~=]=] .. n.CAP .. [=[.ef then ]=] .. fail .. [=[() end
    local cae,cer=pcall(error,]=] .. n.ERRMSG .. [=[)
    if cae or cer~=]=] .. n.ERRMSG .. [=[ then ]=] .. fail .. [=[() end
    local okp=pcall(print,"")
    if not okp then ]=] .. fail .. [=[() end
  end
end
]=])
end

return P
