-- integrity.lua :: build-time payload seals and emitted runtime verification
local bitutil = require("bitutil")

local I = {}
local MOD = 4294967296

local function xor8(a, b)
  local result, place = 0, 1
  a, b = a % 256, b % 256
  for _ = 1, 8 do
    local abit, bbit = a % 2, b % 2
    if abit ~= bbit then result = result + place end
    a = (a - abit) / 2
    b = (b - bbit) / 2
    place = place * 2
  end
  return result
end

-- FNV-1a's prime is 2^24 + 403. Reducing the 2^24 term before
-- multiplication keeps every intermediate exactly representable by doubles.
local function hash_byte(hash, byte)
  local low = hash % 256
  hash = hash - low + xor8(low, byte)
  return ((hash % 256) * 16777216 + hash * 403) % MOD
end

local function hash_number(value, hash)
  value = math.floor(value) % MOD
  for _ = 1, 4 do
    local byte = value % 256
    hash = hash_byte(hash, byte)
    value = (value - byte) / 256
  end
  return hash
end

local function hash_string(value, hash, reverse)
  if reverse then
    for index = #value, 1, -1 do
      hash = hash_byte(hash, value:byte(index))
    end
  else
    for index = 1, #value do
      hash = hash_byte(hash, value:byte(index))
    end
  end
  return hash
end

-- Public, portable 32-bit digest helpers. These intentionally share the
-- exact-double-safe mixer used by the emitted verifier so build-time and
-- runtime results agree under Lua 5.1/LuaJIT, Lua 5.4, and Luau.
function I.hash(value, seed, reverse)
  assert(type(value) == "string", "integrity: hash input must be a string")
  return hash_string(value, math.floor(tonumber(seed) or 2166136261) % MOD,
    reverse == true)
end

function I.hash_number(value, seed)
  return hash_number(value, math.floor(tonumber(seed) or 2166136261) % MOD)
end

local function part_seed(seed, index)
  return hash_number(index, hash_number(seed, 374761393))
end

function I.create(segments, seed)
  assert(type(segments) == "table" and #segments > 0,
    "integrity: at least one segment is required")

  seed = math.floor(tonumber(seed) or 0) % MOD
  local manifest = {
    seed = seed,
    count = #segments,
    lengths = {},
    parts = {},
    total = 0,
  }

  local forward = hash_string("SKX2/F", hash_number(seed, 2166136261))
  forward = hash_number(#segments, forward)
  for index, segment in ipairs(segments) do
    assert(type(segment) == "string", "integrity: segment must be a string")
    local length = #segment
    manifest.lengths[index] = length
    manifest.total = manifest.total + length
    manifest.parts[index] = hash_string(segment, part_seed(seed, index), index % 2 == 0)

    forward = hash_number(index, forward)
    forward = hash_number(length, forward)
    forward = hash_string(segment, forward, false)
  end

  local reverse = hash_string("SKX2/R", hash_number(seed, 2246822519))
  reverse = hash_number(#segments, reverse)
  for index = #segments, 1, -1 do
    local segment = segments[index]
    reverse = hash_number(index, reverse)
    reverse = hash_number(#segment, reverse)
    reverse = hash_string(segment, reverse, true)
  end

  manifest.forward = forward
  manifest.reverse = reverse
  local metadata = hash_string("SKX3/M", hash_number(seed, 668265263))
  metadata = hash_number(manifest.count, metadata)
  metadata = hash_number(manifest.total, metadata)
  for index = 1, manifest.count do
    metadata = hash_number(index, metadata)
    metadata = hash_number(manifest.lengths[index], metadata)
    metadata = hash_number(manifest.parts[index], metadata)
  end
  manifest.metadata = metadata
  manifest.link = hash_number(metadata, hash_number(reverse,
    hash_number(forward, hash_number(manifest.total, 3266489917))))
  manifest.wrapped_forward = I.wrap(forward, metadata)
  manifest.wrapped_reverse = I.wrap(reverse, hash_number(metadata, 2246822519))
  manifest.wrapped_link = I.wrap(manifest.link, hash_number(metadata, 3266489917))
  return manifest
end

function I.wrap(value, seal)
  return bitutil.bxor(value % MOD, seal % MOD) % MOD
end

function I.crypt(data, key)
  local value = key % MOD
  if value == 0 then value = 222222229 end
  local out = {}
  for index = 1, #data do
    value = bitutil.bxor(value, bitutil.lshift(value, 13)) % MOD
    value = bitutil.bxor(value, bitutil.rshift(value, 17)) % MOD
    value = bitutil.bxor(value, bitutil.lshift(value, 5)) % MOD
    out[index] = string.char(xor8(data:byte(index), value % 256))
  end
  return table.concat(out)
end

local function number_list(values)
  local out = {}
  for index, value in ipairs(values) do out[index] = string.format("%.0f", value) end
  return table.concat(out, ",")
end

-- Emits a verifier for a local __SKX_SEG table. On success the three
-- payload seals become available as chunk locals for key unwrapping.
--
-- The full seal pass is always emitted as a named local function that is
-- invoked once immediately and returns the three seals. It doubles as a
-- re-sealable watchdog entry point: protection layers may call it again at
-- runtime to prove segments were not mutated after load. Any tamper raises
-- fail_name immediately.
function I.runtime(manifest, fail_name, opts)
  fail_name = fail_name or "__skx_fail"
  local verify_sym = (opts and opts.verify_sym) or "__skx_reseal"
  local lines = {
    "local __skx_abort=" .. fail_name,
    "local __skx_seed=" .. string.format("%.0f", manifest.seed),
    "local __skx_count=" .. tostring(manifest.count),
    "local __skx_total=" .. tostring(manifest.total),
    "local __skx_lengths={" .. number_list(manifest.lengths) .. "}",
    "local __skx_parts={" .. number_list(manifest.parts) .. "}",
    "local __skx_expect_meta=" .. string.format("%.0f", manifest.metadata),
    "local __skx_wrap_a=" .. string.format("%.0f", manifest.wrapped_forward),
    "local __skx_wrap_b=" .. string.format("%.0f", manifest.wrapped_reverse),
    "local __skx_wrap_c=" .. string.format("%.0f", manifest.wrapped_link),
  }

  -- Pristine hash primitives stay at chunk level: they are shared with the
  -- surrounding loader/decoder blocks emitted by build/emit2.
  local prim = [==[
local __skx_type=type
local __skx_floor=math and math.floor
local __skx_byte=string and string.byte
if __skx_type(__skx_type)~="function" or __skx_type(__skx_floor)~="function" or
   __skx_type(__skx_byte)~="function" then __skx_abort() end
local function __skx_xor8(a,b)
  local r,p=0,1
  a,b=a%256,b%256
  for _=1,8 do
    local x,y=a%2,b%2
    if x~=y then r=r+p end
    a=(a-x)/2 b=(b-y)/2 p=p*2
  end
  return r
end
local function __skx_hb(h,b)
  local low=h%256
  h=h-low+__skx_xor8(low,b)
  return ((h%256)*16777216+h*403)%4294967296
end
local function __skx_hn(n,h)
  n=__skx_floor(n)%4294967296
  for _=1,4 do
    local b=n%256
    h=__skx_hb(h,b)
    n=(n-b)/256
  end
  return h
end
local function __skx_hs(s,h,rev)
  if rev then
    for i=#s,1,-1 do h=__skx_hb(h,__skx_byte(s,i)) end
  else
    for i=1,#s do h=__skx_hb(h,__skx_byte(s,i)) end
  end
  return h
end
local function __skx_ps(i)
  return __skx_hn(i,__skx_hn(__skx_seed,374761393))
end
]==]

  -- Full seal pass: self-contained so it can run repeatedly (re-seal).
  local core = [==[
if __skx_type(__SKX_SEG)~="table" or #__SKX_SEG~=__skx_count then __skx_abort() end
local __SKX_META=__skx_hs("SKX3/M",__skx_hn(__skx_seed,668265263))
__SKX_META=__skx_hn(__skx_count,__SKX_META)
__SKX_META=__skx_hn(__skx_total,__SKX_META)
for i=1,__skx_count do
  __SKX_META=__skx_hn(i,__SKX_META)
  __SKX_META=__skx_hn(__skx_lengths[i],__SKX_META)
  __SKX_META=__skx_hn(__skx_parts[i],__SKX_META)
end
if __SKX_META~=__skx_expect_meta then __skx_abort() end
local function __skx_xor32_local(a,b)
  local r,p=0,1
  a,b=a%4294967296,b%4294967296
  for _=1,32 do
    local x,y=a%2,b%2
    if x~=y then r=r+p end
    a=(a-x)/2 b=(b-y)/2 p=p*2
  end
  return r
end
local __skx_expect_a=__skx_xor32_local(__skx_wrap_a,__SKX_META)
local __skx_expect_b=__skx_xor32_local(__skx_wrap_b,__skx_hn(__SKX_META,2246822519))
local __skx_expect_c=__skx_xor32_local(__skx_wrap_c,__skx_hn(__SKX_META,3266489917))
local __skx_seen_total=0
local __SKX_SEAL_A=__skx_hs("SKX2/F",__skx_hn(__skx_seed,2166136261))
__SKX_SEAL_A=__skx_hn(__skx_count,__SKX_SEAL_A)
for i=1,__skx_count do
  local s=__SKX_SEG[i]
  if __skx_type(s)~="string" or #s~=__skx_lengths[i] then __skx_abort() end
  __skx_seen_total=__skx_seen_total+#s
  local ph=__skx_hs(s,__skx_ps(i),i%2==0)
  if ph~=__skx_parts[i] then __skx_abort() end
  __SKX_SEAL_A=__skx_hn(i,__SKX_SEAL_A)
  __SKX_SEAL_A=__skx_hn(#s,__SKX_SEAL_A)
  __SKX_SEAL_A=__skx_hs(s,__SKX_SEAL_A,false)
end
if __skx_seen_total~=__skx_total or __SKX_SEAL_A~=__skx_expect_a then __skx_abort() end
local __SKX_SEAL_B=__skx_hs("SKX2/R",__skx_hn(__skx_seed,2246822519))
__SKX_SEAL_B=__skx_hn(__skx_count,__SKX_SEAL_B)
for i=__skx_count,1,-1 do
  local s=__SKX_SEG[i]
  __SKX_SEAL_B=__skx_hn(i,__SKX_SEAL_B)
  __SKX_SEAL_B=__skx_hn(#s,__SKX_SEAL_B)
  __SKX_SEAL_B=__skx_hs(s,__SKX_SEAL_B,true)
end
if __SKX_SEAL_B~=__skx_expect_b then __skx_abort() end
local __SKX_SEAL_C=__skx_hn(__SKX_SEAL_B,
  __skx_hn(__SKX_SEAL_A,__skx_hn(__skx_total,3266489917)))
__SKX_SEAL_C=__skx_hn(__SKX_META,__SKX_SEAL_C)
if __SKX_SEAL_C~=__skx_expect_c then __skx_abort() end
return __SKX_SEAL_A,__SKX_SEAL_B,__SKX_SEAL_C
]==]

  if verify_sym then
    lines[#lines + 1] = prim
    lines[#lines + 1] = ("local %s=function()"):format(verify_sym)
    lines[#lines + 1] = core
    lines[#lines + 1] = "end"
    lines[#lines + 1] =
      ("local __SKX_SEAL_A,__SKX_SEAL_B,__SKX_SEAL_C=%s()"):format(verify_sym)
  end
  return table.concat(lines, "\n")
end

return I
