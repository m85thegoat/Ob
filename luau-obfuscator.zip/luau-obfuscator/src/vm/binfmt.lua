-- vm/binfmt.lua :: binary program blob: unified encoder + cascade encryption
local bitutil = require("bitutil")
local Integrity = require("integrity")
local BF = {}

------------------------------------------------------------------ primitives
local function varint(n)
  n = math.floor(n)
  if n < 0 then error("binfmt: negative varint", 0) end
  local out = {}
  repeat
    local b = n % 128
    n = math.floor(n / 128)
    if n > 0 then b = b + 128 end
    out[#out + 1] = string.char(b)
  until n == 0
  return table.concat(out)
end

local zz = function(n) if n < 0 then return -n * 2 - 1 else return n * 2 end end

local function i32le(u)
  u = u % 4294967296
  return string.char(u % 256, math.floor(u / 256) % 256,
                     math.floor(u / 65536) % 256, math.floor(u / 16777216) % 256)
end

local function tuple_salt(opcode, fields, ordinal, key, maximum)
  local value = bitutil.bxor(key, opcode)
  value = bitutil.bxor(value, bitutil.lshift(ordinal, 11))
  value = bitutil.bxor(value, bitutil.rshift(ordinal, 3))
  value = bitutil.bxor(value, bitutil.lshift(fields, 19))
  value = bitutil.bxor(value, fields)
  value = bitutil.bxor(value, bitutil.lshift(value, 13))
  value = bitutil.bxor(value, bitutil.rshift(value, 17))
  value = bitutil.bxor(value, bitutil.lshift(value, 5))
  return (value % 4294967296) % (maximum + 1)
end
BF.tuple_salt = tuple_salt

-- Adds two independent keyed seals to the decrypted wire image. The outer
-- encrypted-segment manifest authenticates ciphertext; this trailer binds the
-- recovered plaintext to its mask, string stream, IV, and wire profile too.
function BF.authenticate(data, opts)
  local profile = assert(opts.profile, "wire profile required")
  local seed = bitutil.bxor(bitutil.bxor(opts.mask, opts.keystream_seed), profile.id)
  local forward_seed = Integrity.hash("SKX3/RAW/F", seed)
  local forward = Integrity.hash(data, forward_seed, false)
  local reverse_seed = Integrity.hash("SKX3/RAW/R",
    bitutil.bxor(bitutil.bxor(opts.ivseed, forward), profile.id))
  local reverse = Integrity.hash(data, reverse_seed, true)
  return data .. i32le(forward) .. i32le(reverse), {
    forward = forward,
    reverse = reverse,
  }
end

local function shuffled_bytes(rng, count)
  local pool = {}
  for value = 0, 255 do pool[#pool + 1] = value end
  local out = {}
  for index = 1, count do
    local selected = rng.int(1, #pool)
    out[index] = table.remove(pool, selected)
  end
  return out
end

function BF.make_profile(rng)
  local tags = shuffled_bytes(rng, 10)
  local layout = { "op", "fields", "salt" }
  for index = #layout, 2, -1 do
    local selected = rng.int(1, index)
    layout[index], layout[selected] = layout[selected], layout[index]
  end

  local magic = {}
  for index = 1, 4 do magic[index] = string.char(rng.int(1, 255)) end
  local profile = {
    magic = table.concat(magic),
    layout = layout,
    salt_max = rng.int(7, 63),
    field = {
      integer = tags[1], string = tags[2], tuple = tags[3],
      yes = tags[4], no = tags[5],
    },
    constant = {
      integer = tags[6], number = tags[7], string = tags[8],
      yes = tags[9], no = tags[10],
    },
  }
  local fingerprint = table.concat({
    profile.magic,
    string.char(tags[1], tags[2], tags[3], tags[4], tags[5],
      tags[6], tags[7], tags[8], tags[9], tags[10], profile.salt_max),
    table.concat(layout, ":"),
  })
  local hash = 2166136261
  for index = 1, #fingerprint do
    hash = bitutil.bxor(hash % 4294967296, fingerprint:byte(index))
    local mixed, value, prime = 0, hash % 4294967296, 16777619
    for _ = 1, 25 do
      if prime % 2 == 1 then mixed = (mixed + value) % 4294967296 end
      value = (value + value) % 4294967296
      prime = (prime - prime % 2) / 2
    end
    hash = mixed
  end
  profile.id = hash % 4294967296
  return profile
end

local pack_double
if string.pack then
  pack_double = function(v) return string.pack("<d", v) end
else
  local ok, ffi = pcall(require, "ffi")
  if ok then
    ffi.cdef[[typedef union { double d; uint8_t b[8]; } u_double;]]
    pack_double = function(v)
      local u = ffi.new("u_double")
      u.d = v
      return ffi.string(u.b, 8)
    end
  else
    error("binfmt: no double packing available", 0)
  end
end

------------------------------------------------------------------ crypto
function BF.make_sbox(rng)
  local fwd = {}
  for i = 0, 255 do fwd[i] = i end
  for i = 255, 1, -1 do
    local j = rng.int(0, i)
    local tmp = fwd[i]
    fwd[i] = fwd[j]
    fwd[j] = tmp
  end
  local inv = {}
  for i = 0, 255 do inv[fwd[i]] = i end
  -- bake as 256-char string for embedding
  local chars = {}
  for i = 0, 255 do chars[i + 1] = string.char(fwd[i]) end
  return { fwd = fwd, inv = inv, str = table.concat(chars) }
end

function BF.keystream(keyseed, len)
  local v = keyseed % 4294967296
  if v == 0 then v = 222222229 end
  local t = {}
  for i = 1, len do
    v = bitutil.bxor(v, bitutil.lshift(v, 13)) % 4294967296
    v = bitutil.bxor(v, bitutil.rshift(v, 17)) % 4294967296
    v = bitutil.bxor(v, bitutil.lshift(v, 5)) % 4294967296
    t[i] = v % 256
  end
  return t
end

-- Cascade-chained encryption: block N's keystream seeds from fnv(plaintext of
-- block N-1). Patching any byte corrupts EVERYTHING downstream on decrypt --
-- integrity enforced structurally, not by a separable check.
BF.BLOCK = 256

local fnv_cascade
local function fnv32(data)
  local out = 2166136261
  for i = 1, #data do
    out = bitutil.bxor(out % 4294967296, data:byte(i))
    local mm, aa, bb = 0, out % 4294967296, 16777619
    for j = 1, 25 do
      if bb % 2 == 1 then mm = (mm + aa) % 4294967296 end
      aa = (aa + aa) % 4294967296
      bb = (bb - bb % 2) / 2
    end
    out = mm
  end
  return out % 4294967296
end
fnv_cascade = fnv32

function BF.encrypt(data, ivseed, sbox, blockSize)
  local BL = blockSize or BF.BLOCK
  local nblk = math.ceil(#data / BL)
  local prevplain = nil
  local out = {}
  for blk = 0, nblk - 1 do
    local chunk = data:sub(blk * BL + 1, (blk + 1) * BL)
    if prevplain then
      -- key chains from previous plaintext block
      local bk = fnv32(prevplain)
      local ks = BF.keystream(bitutil.bxor(bk, ivseed), BL)
      for i = 1, #chunk do
        local b = bitutil.bxor(chunk:byte(i), ks[i])
        out[blk * BL + i] = string.char(sbox.fwd[b])
      end
    else
      -- first block uses IV-seeded stream
      local ks = BF.keystream(ivseed, BL)
      for i = 1, #chunk do
        local b = bitutil.bxor(chunk:byte(i), ks[i])
        out[blk * BL + i] = string.char(sbox.fwd[b])
      end
    end
    prevplain = chunk
  end
  return table.concat(out)
end

-- decrypt mirrors encrypt (used by tests / verifier tooling)
function BF.decrypt(data, ivseed, sboxinv, blockSize)
  local BL = blockSize or BF.BLOCK
  local nblk = math.ceil(#data / BL)
  local out = {}
  for blk = 0, nblk - 1 do
    local chunk = data:sub(blk * BL + 1, (blk + 1) * BL)
    local plain = {}
    if blk == 0 then
      local ks = BF.keystream(ivseed, BL)
      for i = 1, #chunk do
        plain[i] = bitutil.bxor(sboxinv[chunk:byte(i)], ks[i])
      end
    else
      local prevp = table.concat(out, "", (blk - 1) * BL + 1, (blk - 1) * BL + BL)
      local bk = fnv32(prevp)
      local ks = BF.keystream(bitutil.bxor(bk, ivseed), BL)
      for i = 1, #chunk do
        plain[i] = bitutil.bxor(sboxinv[chunk:byte(i)], ks[i])
      end
    end
    for i = 1, #plain do out[(blk) * BL + i] = string.char(plain[i]) end
  end
  return table.concat(out)
end

-- unsigned-normalized xor used for opcode masking
local function bxor_mask(a, b)
  return bitutil.bxor(a % 4294967296, b % 4294967296)
end

------------------------------------------------------------------ encoding
-- BF.encode(root, opts)
--   root.k            : constants array
--   root.allprotos    : { {params={}, va=bool, body=stmt-tuple-tree}, ... }
--   root.opmap        : name -> numeric opcode
--   opts.mask         : numeric mask applied to opcodes
--   opts.keystream_seed : number seeding the stream cipher
--   opts.profile      : build-specific tags/header layout from make_profile
-- Returns raw binary string (then encrypted by caller via BF.encrypt).
--
-- Tuple wire format (recursive):
--   varint zigzag(bxor(opcodeNum, mask))
--   varint nfields
--   nfields * field:
--     \0 int    : varint zigzag(value)
--     \1 string : varint len + keystream-ciphered bytes
--     \2 table  : nested tuple
--     \3 true / \4 false
BF.encode = function(root, opts)
  local opmap = assert(root.opmap, "opmap required")
  local profile = assert(opts.profile, "wire profile required")
  local mask = opts.mask % 4294967296
  local ks = BF.keystream(opts.keystream_seed, 4096)
  local soff = 0 -- string offset cursor for stream alignment
  local salt_key = bitutil.bxor(bitutil.bxor(mask, opts.keystream_seed), profile.id)
  local rng = opts.rng
  local tuple_ordinal = 0

  local function count_tuple(x)
    local count = 1
    local kids
    if x.op then
      kids = x.a
    else
      kids = {}
      for index = 2, #x do kids[#kids + 1] = x[index] end
    end
    for _, value in ipairs(kids) do
      if type(value) == "table" then count = count + count_tuple(value) end
    end
    return count
  end

  local tuple_total = 0
  for _, proto in ipairs(root.allprotos) do
    tuple_total = tuple_total + count_tuple(proto.b or proto.body)
  end

  local function estr(sv)
    local out = {}
    for i = 1, #sv do
      out[i] = string.char(bitutil.bxor(sv:byte(i), ks[((soff + i - 1) % #ks) + 1]))
    end
    soff = soff + #sv
    return varint(#sv) .. table.concat(out)
  end

  -- Anti-dump fragmentation: every CONSTANT string is split into a
  -- build-random number of length-varied chunks before hitting the wire,
  -- so no intact plaintext-hint substring survives even post-decrypt dumps.
  -- Each chunk flows through the SAME keystream cursor (contiguous),
  -- keeping decode alignment trivial while shattering static signatures.
  local function esplit(sv)
    local len = #sv
    if not rng or len <= 12 then return "\1" .. estr(sv) end
    local nparts = ({ [13] = 2, [14] = 3 })[rng.int(1, 3)] or 1
    if len > 96 then nparts = math.min(5, nparts + rng.int(1, 2)) end
    local head = ""
    local off = 0
    local remaining = len
    for part = 1, nparts - 1 do
      local maxl = remaining - (nparts - part)
      local take = rng.int(0, math.max(0, maxl))
      head = head .. estr(sv:sub(off + 1, off + take))
      off = off + take
      remaining = remaining - take
    end
    head = head .. estr(sv:sub(off + 1))
    return varint(nparts) .. head
  end

  local efield
  local function etuple(x)
    local name = x.op or x[1]
    local num = assert(opmap[name], "no opcode for " .. tostring(name))
    local kids
    if x.op then kids = x.a
    else
      kids = {}
      for i = 2, #x do kids[#kids + 1] = x[i] end
    end
    tuple_ordinal = tuple_ordinal + 1
    local header = {
      op = varint(zz(bxor_mask(num, mask))),
      fields = varint(#kids),
      salt = varint(tuple_salt(num, #kids, tuple_ordinal, salt_key,
        profile.salt_max)),
    }
    local parts = {}
    for _, field in ipairs(profile.layout) do parts[#parts + 1] = header[field] end
    for _, f in ipairs(kids) do
      local ft = type(f)
      if ft == "number" then
        parts[#parts + 1] = string.char(profile.field.integer) .. varint(zz(math.floor(f)))
      elseif ft == "string" then
        parts[#parts + 1] = string.char(profile.field.string) .. estr(f)
      elseif ft == "boolean" then
        parts[#parts + 1] = string.char(f and profile.field.yes or profile.field.no)
      elseif ft == "table" then
        parts[#parts + 1] = string.char(profile.field.tuple) .. etuple(f)
      elseif f == nil then
        error("binfmt: nil tuple field", 0)
      else
        error("binfmt: field type " .. ft, 0)
      end
    end
    return table.concat(parts)
  end

  local buf = {}
  buf[#buf + 1] = profile.magic
  buf[#buf + 1] = i32le(mask)
  buf[#buf + 1] = i32le(profile.id)
  buf[#buf + 1] = varint(tuple_total)
  buf[#buf + 1] = varint(#root.k)
  for _, v in ipairs(root.k) do
    local tv = type(v)
    if tv == "number" then
      if math.type and math.type(v) == "integer" then
        buf[#buf + 1] = string.char(profile.constant.integer) .. varint(zz(v))
      else
        buf[#buf + 1] = string.char(profile.constant.number) .. pack_double(v)
      end
    elseif tv == "string" then
      buf[#buf + 1] = string.char(profile.constant.string) .. esplit(v)
    elseif tv == "boolean" then
      buf[#buf + 1] = string.char(v and profile.constant.yes or profile.constant.no)
    else
      error("binfmt: const type " .. tv, 0)
    end
  end
  buf[#buf + 1] = varint(#root.allprotos)
  for _, pr in ipairs(root.allprotos) do
    local plist = pr.p or pr.params or {}
    local bodyt = pr.b or pr.body
      or error("binfmt: proto missing body", 0)
    buf[#buf + 1] = varint(#plist)
    for _, pn in ipairs(plist) do buf[#buf + 1] = estr(pn) end
    local is_vararg = pr.va
    if is_vararg == nil then is_vararg = pr.is_vararg end
    buf[#buf + 1] = is_vararg and "\1" or "\0"
    buf[#buf + 1] = etuple(bodyt)
  end
  assert(tuple_ordinal == tuple_total, "binfmt: tuple count mismatch")
  return table.concat(buf)
end

return BF
