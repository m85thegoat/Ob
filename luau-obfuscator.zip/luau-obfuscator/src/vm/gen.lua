-- vm/gen.lua :: seed-driven opcode/operator map generation
local G = {}

------------------------------------------------------------ opcode universe
local UNIVERSE = {
  "NIL","TRUE","FALSE","KON","VARG","NAME","IDX","CALL","MCALL","FUNC","TBL",
  "ANDJ","ORJ","BIN","UN","TBLK","TBLS","TGTNM","TGTIDX",
  "SEQ","IFCL",
  "SETL","LSET","SETGFN","ASN","CASN","EX","BLK","WHILE","REP","IF","NFOR","GFOR","RET",
  "BRK","CNT",
}
G.UNIVERSE = UNIVERSE

-- shuffled numeric ids for binary/unary operators (pool holds numbers only)
function G.make_binmaps(rng)
  local bins = {"+","-","*","/","%","^","//","..","==","~=","<","<=",">",">=","&","|","~","<<",">>"}
  local uns = {"not","#","-","~"}
  local function shuf(t)
    for i = #t, 2, -1 do
      local j = rng.int(1, i)
      t[i], t[j] = t[j], t[i]
    end
    return t
  end
  local binmap, unmap = {}, {}
  for i, nm in ipairs(shuf(bins)) do binmap[nm] = i end
  for i, nm in ipairs(shuf(uns)) do unmap[nm] = i end
  return binmap, unmap
end

-- builds opcode number mapping (seed-driven, non-contiguous) + fake bombs
function G.make_opmap(rng)
  local pool = {}
  for i, n in ipairs(UNIVERSE) do pool[i] = n end
  -- add 3-7 fake ops per build (never emitted, bomb if executed)
  do
    local fakeCount = rng.int(3,7)
    for i=1,fakeCount do
      pool[#pool+1] = "FAKE_"..rng.int(1000,9999).."_"..i
    end
  end
  local map, inv = {}, {}
  local nextnum = 13
  while #pool > 0 do
    local idx = rng.int(1, #pool)
    local nm = table.remove(pool, idx)
    map[nm] = nextnum
    inv[nextnum] = nm
    nextnum = nextnum + rng.int(3, 11)
  end
  return map, inv
end

return G

