-- vm/emit2.lua :: hardened VM output assembler
-- Emits complete standalone script: watermark -> segments -> guards ->
-- integrity/crypto -> blob decode -> tuple reader -> MANGLED engine -> boot.
--
-- Hardening layers (per build, seed-driven):
--   * protections.lua extras: print/warn/error channel canary (anti envlog)
--     plus decoy bait constants that poison naive dumpers
--   * re-sealable integrity watchdog (__skx_reseal) driven at every phase
--     boundary so post-load payload mutation fails closed instantly
--   * constant-index whitening: konstant slots XORed with a build-specific
--     mask unwrapped lazily inside KKREF (heap dumps reveal nothing)
--   * chunked string constants shattered across the keystream cursor
--   * decoder state scrubbed once consumed (inverse S-box wiped)
--   * fail-closed opcode bombs: any structural anomaly routes to __mock()
--   * deterministic per-build identifier mangling over the entire
--     crypto/reader/engine region hides every interpreter symbol
local E2 = {}

local Protections = require("protections")

local PUNCT_OK = {}
for ch in (" !#$%&()*+,-./:;<=>?@[]^_`{|}~"):gmatch(".") do PUNCT_OK[ch] = true end

local function quote_safe(value)
  -- numeric-escape everywhere except harmless punctuation: no alphanumeric
  -- token sequence can survive raw inside machine literals ahead of mangling.
  local out = {}
  for index = 1, #value do
    local char = value:sub(index, index)
    if PUNCT_OK[char] then out[#out + 1] = char
    else out[#out + 1] = string.format("\\%03d", value:byte(index)) end
  end
  return '"' .. table.concat(out) .. '"'
end

-- Identifier bases participating in per-build renaming across the
-- crypto/reader/engine region. Every generated replacement contains an
-- underscore AND a digit, so plain words/magic literals cannot collide.
local MANGLE_BASES = {
  "_n9","_x8","_l7","_r6","_ks","_f5","_f5r","_bA","_bO","_bX","_sL","_sR",
  "__BJ","_IV8","_SBF","__u32","__MK","__K1","__IV","__RAW","__RAW_N","__BLOCK",
  "__RAW_A","__RAW_B","__RAW_SEED","__RAW_FA","__RAW_RSEED","__RAW_FB",
  "__KS1","__SC","__P","_vi","__NT","__TO","__SALT_KEY","__salt_expected",
  "_uz","_op","_str","_strref","_double_at","_tup","K","PR",
  "__VALID_OP","__OP_ARITY","__MAGIC","__PROFILE_ID",
  "__TFI","__TFS","__TFT","__TFY","__TFN","__TCI","__TCN","__TCS","__TCY",
  "__TCF","__SALT_MAX","__PROFILE_BYTES","_B2","_U2","__KM",
  "_qA","_qB","_qN","_G9","_pack","_tZ","_sN","_put","_gL","_sG",
  "_set_path","KC","KKREF","_EVF","_EXG","_MV","_EL","_AV","_LV","_CA","_XP",
}

local function quote(value)
  local out = {}
  for index = 1, #value do
    local byte = value:byte(index)
    local char = value:sub(index, index)
    if char == "\\" then out[#out + 1] = "\\\\"
    elseif char == '"' then out[#out + 1] = '\\"'
    elseif byte >= 32 and byte <= 126 then out[#out + 1] = char
    else out[#out + 1] = string.format("\\%03d", byte) end
  end
  return '"' .. table.concat(out) .. '"'
end

E2.BIN_SRC = {
  ["+"]='function(a,b)return a+b end',
  ["-"]='function(a,b)return a-b end',
  ["*"]='function(a,b)return a*b end',
  ["/"]='function(a,b)return a/b end',
  ["%"]='function(a,b)return a%b end',
  ["^"]='function(a,b)return a^b end',
  ["//"]='function(a,b)local q=a/b return q-q%1 end',
  [".."]='function(a,b)return a..b end',
  ["=="]='function(a,b)return a==b end',
  ["~="]='function(a,b)return a~=b end',
  ["<"]='function(a,b)return a<b end',
  ["<="]='function(a,b)return a<=b end',
  [">"]='function(a,b)return a>b end',
  [">="]='function(a,b)return a>=b end',
  ["&"]='_bA', ["|"]='_bO', ["~"]='_bX',
  ["<<"]='_sL', [">>"]='_sR',
}
E2.UN_SRC = {
  ["not"]='function(v)return not v end',
  ["#"]='function(v)return #v end',
  ["-"]='function(v)return -v end',
  ["~"]='function(v)return _bX(v,4294967295) end',
}

local RT_CRYPTO = [=====[
local function _n9(r)r=r%4294967296 if r>=2147483648 then r=r-4294967296 end return r end
local function _x8(a,b)local r,p=0,1 a=a%4294967296 b=b%4294967296 for i=1,32 do local u,w=a%2,b%2 if u~=w then r=r+p end a=(a-u)/2 b=(b-w)/2 p=p*2 end return r end
local function _l7(a,n)n=n%32 if n==0 then return _n9(a)end return _n9((a%4294967296)*(2^n)) end
local function _r6(a,n)n=n%32 local ua=a%4294967296 if n==0 then return _n9(ua)end return _n9(math.floor(ua/(2^n))) end
local function _ks(k,len)local v=k%4294967296 if v==0 then v=222222229 end local q={} for i=1,len do v=_x8(v,_l7(v,13))%4294967296 v=_x8(v,_r6(v,17))%4294967296 v=_x8(v,_l7(v,5))%4294967296 q[i]=v%256 end return q end
    local function _f5(s,h)h=h or 2166136261 local o=h for i=1,#s do o=o%4294967296 o=_x8(o,s:byte(i)) local mm,aa,bb=0,o%4294967296,16777619 for j=1,25 do if bb%2==1 then mm=(mm+aa)%4294967296 end aa=(aa+aa)%4294967296 bb=(bb-bb%2)/2 end o=mm end return _n9(o) end
    local function _f5r(s,h)h=h or 2166136261 local o=h for i=#s,1,-1 do o=o%4294967296 o=_x8(o,s:byte(i)) local mm,aa,bb=0,o%4294967296,16777619 for j=1,25 do if bb%2==1 then mm=(mm+aa)%4294967296 end aa=(aa+aa)%4294967296 bb=(bb-bb%2)/2 end o=mm end return _n9(o) end
local function _bA(a,b)return _x8(a,b) end
local function _bO(a,b)local r,p=0,1 a=a%4294967296 b=b%4294967296 for i=1,32 do local x,y=a%2,b%2 if x==1 or y==1 then r=r+p end a=(a-x)/2 b=(b-y)/2 p=p*2 end return _n9(r) end
local function _bX(a,b)return _x8(a,b) end
local function _sL(a,b)b=b%32 if b==0 then return _n9(a)end return _n9((a%4294967296)*(2^b)) end
local function _sR(a,b)b=b%32 if b==0 then return _n9(a)end return _n9(math.floor((a%4294967296)/(2^b))) end
]=====]

E2.assemble = function(ctx)
  -- ctx fields:
  --   banner, seed, wrapped_mask, wrapped_iv, wrapped_key,
  --   seg_decls(list of 'NAME="..."'), seg_refs({'__SKX_SEG_1',...}),
  --   integrity_src(string defining verified __SKX_SEAL_A/B/C), sbox_str,
  --   opmap(name->num), binmap(name->idx), unmap(name->idx),
  --   mockery(str), disp_mode("if" or "table"), salt_mode(bool)
  local c = ctx
  local L = {}
  -- banner comments removed (no --)

  -- Per-build symbol mangler shared by every machine-region piece.
  local mrng = c.mangle_rng or bitutil.newrng((c.seed or 0) + 77031)
  local mang = Protections.mangler(mrng)
  for _, base in ipairs(MANGLE_BASES) do mang.add(base) end
  local function M(piece) return mang.apply(piece) end

  -- Local encrypted payload segments.
  L[#L+1] = table.concat(c.seg_decls, "\n")
  L[#L+1] = "local __SKX_SEG={" .. table.concat(c.seg_refs, ",") .. "}"

  -- inverse sbox
  -- S-box hardened: emit as encrypted string, decode at runtime (not plain array)
  local sbox_enc_key = c.mangle_rng.int(1, 253)
  local enc_parts = {}
  for i=1,#c.sbox_str do
    local b=c.sbox_str:byte(i)
    enc_parts[i]=tostring((b + sbox_enc_key + i*7) % 256)
  end
  L[#L+1] = M("local _SBI_enc={" .. table.concat(enc_parts, ",") .. "}")
  L[#L+1] = M(string.format("local _SBI_key=%d", sbox_enc_key))
  L[#L+1] = M("local _SBI={} local _SBF={} for i=1,256 do local v=_SBI_enc[i] v=(v - _SBI_key - i*7)%256 _SBI[i]=v _SBF[i]=v end _SBI_enc=nil _SBI_key=nil")

  -- The common guard owns the fail path in protected builds. Keep the compact
  -- fallback for explicitly unprotected VM output.
  if c.guard_src and c.guard_src ~= "" then
    L[#L + 1] = c.guard_src
  else
    L[#L+1] = ("local __mock_message=%q"):format(c.mockery)
    L[#L+1] = [=[
local __mocked=false
local __skx_fake_loaded=false
local function __skx_try_fake()
  if __skx_fake_loaded then return end
  __skx_fake_loaded=true
  local _load = load or loadstring
  if type(_load)=="function" and type(__SKX_FAKE)=="string" and type(__SKX_FAKE_KEY)=="number" then
    local v=__SKX_FAKE_KEY%4294967296
    if v==0 then v=222222229 end
    local out={}
    local function _xor32(a,b) local r,p=0,1 a=a%4294967296 b=b%4294967296 for i=1,32 do local u,w=a%2,b%2 if u~=w then r=r+p end a=(a-u)/2 b=(b-w)/2 p=p*2 end return r end
    local function _lshift(a,n) n=n%32 if n==0 then return a%4294967296 end return (a%4294967296)*(2^n)%4294967296 end
    local function _rshift(a,n) n=n%32 if n==0 then return a%4294967296 end return math.floor((a%4294967296)/(2^n)) end
    -- decrypt fake (same as Integrity.crypt)
    for i=1,#__SKX_FAKE do
      v=_xor32(v,_lshift(v,13))%4294967296
      v=_xor32(v,_rshift(v,17))%4294967296
      v=_xor32(v,_lshift(v,5))%4294967296
      local a,b=__SKX_FAKE:byte(i), v%256
      local r,p=0,1
      for _=1,8 do local x,y=a%2,b%2 if x~=y then r=r+p end a=(a-x)/2 b=(b-y)/2 p=p*2 end
      out[i]=string.char(r)
    end
    local fake_src=table.concat(out)
    local ok, fn = pcall(_load, fake_src, "=decoy")
    if ok and type(fn)=="function" then pcall(fn) end
  end
end
local function __mock()
  if __mocked then __skx_try_fake() error(__mock_message or "integrity failure",2) end
  __mocked=true
  if type(print)=="function" then pcall(print,__mock_message) end
  __skx_try_fake()
  error(__mock_message or "integrity failure",2)
end
local function __probe()
  local a="ABC"
  if string.sub(a,1,1) ~= "A" then return true end
  if string.sub(a,2,2) ~= "B" then return true end
  if math.floor(2.9) ~= 2 then return true end
  if math.floor(-2.1) ~= -3 then return true end
  if table.concat({"a","b"}) ~= "ab" then return true end
  if _x8(305419896,2596069104) ~= 2290649224 then return true end
  local f=function(x) return x+1 end
  if f(41) ~= 42 then return true end
  return false
end
local __probe_ok,__probe_bad=pcall(__probe)
if not __probe_ok or __probe_bad then __mock() end
]=]
  end
  -- Define crypto after the guard's captured aliases so all decoder helpers
  -- resolve to pinned primitives rather than mutable globals.
  L[#L + 1] = M(RT_CRYPTO)

  -- Anti-envlog channel canary + duper bait pool (own pristine captures).
  L[#L+1] = M(Protections.extras({
    fail = "__mock", mockery = c.mockery, rng = mrng,
  }))

  -- EnvLogger (opt-in, off by default): boundary telemetry, never weakens fail-closed
  if c.env_logger_src and c.env_logger_src ~= "" then
    L[#L+1] = c.env_logger_src
  end

  -- Verify the encrypted payload, then unwrap decoder material with its seals.
  L[#L+1] = c.integrity_src
  if c.env_logger_src and c.env_logger_src ~= "" then
    L[#L+1] = "if __skx_log.emit then __skx_log.emit(\"INTEGRITY_PHASE\",\"ok\",{phase=\"seal_ok\"}) end"
    L[#L+1] = "if __skx_log and __skx_log.set_phase then __skx_log.set_phase(\"seal\") end"
  end
  -- integrity runtime always exposes the re-sealable watchdog now
  local token_a = c.guard_tokens and "__SKX_GUARD_A" or "0"
  local token_b = c.guard_tokens and "__SKX_GUARD_B" or "0"
  local token_c = c.guard_tokens and "__SKX_GUARD_C" or "0"
  L[#L+1] = M(("local __MK=_x8(%.0f,__SKX_SEAL_A)%%4294967296 " ..
             "__MK=_x8(__MK,%s)%%4294967296 " ..
             "local __K1=_x8(%.0f,__SKX_SEAL_C)%%4294967296 " ..
             "__K1=_x8(__K1,%s)%%4294967296 " ..
             "local __IV=_x8(%.0f,__SKX_SEAL_B)%%4294967296 " ..
             "__IV=_x8(__IV,%s)%%4294967296"):format(
    c.wrapped_mask, token_a, c.wrapped_key, token_c, c.wrapped_iv, token_b))
  if c.guard_tokens then L[#L + 1] = "__skx_guard(true)" end

  -- Konstant-index whitening key split across two unrelated numbers.
  assert(c.kmask_a ~= nil and c.kmask_b ~= nil, "emit2: kmask split required")
  L[#L+1] = M(("local __KM=_x8(%d,%d)"):format(c.kmask_a, c.kmask_b))
  local blockSize = c.blockSize or 256
  L[#L+1] = M(("local __BLOCK=%d"):format(blockSize))

  local wp = assert(c.wire_profile, "emit2: wire profile required")
  L[#L+1] = M(("local __MAGIC=%s local __PROFILE_ID=%.0f " ..
             "local __TFI=%d local __TFS=%d local __TFT=%d local __TFY=%d local __TFN=%d " ..
             "local __TCI=%d local __TCN=%d local __TCS=%d local __TCY=%d local __TCF=%d"):format(
    quote_safe(wp.magic), wp.id,
    wp.field.integer, wp.field.string, wp.field.tuple, wp.field.yes, wp.field.no,
    wp.constant.integer, wp.constant.number, wp.constant.string,
    wp.constant.yes, wp.constant.no))
  L[#L+1] = M(("local __SALT_MAX=%d"):format(wp.salt_max))
  L[#L+1] = M(("local __PROFILE_BYTES=string.char(__TFI,__TFS,__TFT,__TFY,__TFN," ..
             "__TCI,__TCN,__TCS,__TCY,__TCF,__SALT_MAX) " ..
             "if _f5(__MAGIC..__PROFILE_BYTES..%s)%%4294967296~=__PROFILE_ID " ..
             "then __mock() end"):format(quote_safe(table.concat(wp.layout, ":"))))
  local tuple_reads = {
    op = "onum=_op()",
    fields = "nf=_vi()",
    salt = "_salt=_vi()",
  }
  local tuple_header = {}
  for _, field in ipairs(wp.layout) do
    tuple_header[#tuple_header + 1] = tuple_reads[field]
  end
  local valid_opcodes = {}
  for _, opcode in pairs(c.opmap) do valid_opcodes[#valid_opcodes + 1] = opcode end
  table.sort(valid_opcodes)
  local valid_parts = {}
  for _, opcode in ipairs(valid_opcodes) do
    valid_parts[#valid_parts + 1] = ("[%d]=true"):format(opcode)
  end
  L[#L+1] = M("local __VALID_OP={" .. table.concat(valid_parts, ",") .. "}")
  local arity = {
    NIL={0,0}, TRUE={0,0}, FALSE={0,0}, KON={1,1}, VARG={0,0},
    NAME={1,1}, IDX={2,2}, CALL={1,-1}, MCALL={2,-1}, FUNC={1,1},
    TBL={0,-1}, ANDJ={2,2}, ORJ={2,2}, BIN={3,3}, UN={2,2},
    TBLK={2,2}, TBLS={1,1}, TGTNM={1,1}, TGTIDX={2,2}, SEQ={0,-1},
    IFCL={2,2}, SETL={3,3}, LSET={2,2}, SETGFN={3,3}, ASN={2,2},
    CASN={3,3}, EX={1,1}, BLK={1,1}, WHILE={2,2}, REP={2,2},
    IF={2,2}, NFOR={5,5}, GFOR={3,3}, RET={1,1}, BRK={0,0}, CNT={0,0},
  }
  local arity_parts = {}
  for name, opcode in pairs(c.opmap) do
    local bounds = arity[name]
    if not bounds then bounds = {0,0} end -- fake bomb
    arity_parts[#arity_parts + 1] = ("[%d]={%d,%d}"):format(opcode, bounds[1], bounds[2])
  end
  table.sort(arity_parts)
  L[#L+1] = M("local __OP_ARITY={" .. table.concat(arity_parts, ",") .. "}")

  -- cascade decrypt + reader
  local reader = [=[
local __BJ=table.concat(__SKX_SEG)
do
  local _IV8,seen={},{}
  for j=1,256 do
    local sv=_SBF[j]
    if type(sv)~="number" or sv<0 or sv>255 or sv%1~=0 or seen[sv] then __mock() end
    seen[sv]=true
    _IV8[sv]=j-1
  end
  local BL=__BLOCK
  local nb=math.ceil(#__BJ/BL)
  local ob={}
  local pprev=nil
  for bk2=0,nb-1 do
    local ch=__BJ:sub(bk2*BL+1,bk2*BL+BL)
    local ks3
    if not pprev then ks3=_ks(__IV,BL)
    else ks3=_ks(_x8(_f5(pprev),__IV),BL) end
    local pl={}
    for i=1,#ch do pl[i]=string.char(_x8(_IV8[ch:byte(i)],ks3[i])) end
    pprev=table.concat(pl)
    for i=1,#pl do ob[bk2*BL+i]=pl[i] end
  end
  __BJ=table.concat(ob)
  pprev=nil
  do
    local wiped={}
    for j=1,#_IV8 do wiped[j]="\0" end
    _IV8=wiped
    -- P3 scrub: wipe S-box source after decrypt (keep __SKX_SEG for reseal)
    for j=1,#_SBF do _SBF[j]=0 end
    _SBF=nil
  end
  -- further scrub of working buffers (keep __SKX_SEG for reseal)
  ob=nil; ch=nil; ks3=nil; pl=nil
end
if __skx_guard then __skx_guard(true) end
__skx_reseal()
if __skx_log and __skx_log.set_phase then __skx_log.set_phase("decode") end
  if #__BJ<21 or __BJ:sub(1,4)~=__MAGIC then __mock() end
local function __u32(p)
  local a,b,c,d=__BJ:byte(p,p+3)
  if not d then __mock() end
  return a+b*256+c*65536+d*16777216
end
if __u32(5)~=__MK then __mock() end
if __u32(9)~=__PROFILE_ID then __mock() end
local __RAW_N=#__BJ-8
local __RAW_A=__u32(__RAW_N+1)
local __RAW_B=__u32(__RAW_N+5)
local __RAW=__BJ:sub(1,__RAW_N)
local __RAW_SEED=_x8(_x8(__MK,__K1),__PROFILE_ID)
local __RAW_FA=_f5("SKX3/RAW/F",__RAW_SEED)%4294967296
__RAW_FA=_f5(__RAW,__RAW_FA)%4294967296
local __RAW_RSEED=_x8(_x8(__IV,__RAW_FA),__PROFILE_ID)
local __RAW_FB=_f5("SKX3/RAW/R",__RAW_RSEED)%4294967296
__RAW_FB=_f5r(__RAW,__RAW_FB)%4294967296
if __RAW_FA~=__RAW_A or __RAW_FB~=__RAW_B then __mock() end
local __KS1=_ks(__K1,4096)
local __SC=0
local __P=13
local function _vi()
  local r,pw,steps=0,1,0
  while true do
    steps=steps+1
    if steps>10 then __mock() end
    local b=__RAW:byte(__P)
    if not b then __mock() end
    __P=__P+1
    r=r+(b%128)*pw
    if b<128 then break end
    pw=pw*128
  end
  return r
end
local __NT=_vi()
if __NT%1~=0 or __NT<1 or __NT>__RAW_N-__P+1 then __mock() end
local __TO=0
local __SALT_KEY=__RAW_SEED
local function __salt_expected(op,nf,ord)
  local v=_x8(__SALT_KEY,op)
  v=_x8(v,_l7(ord,11)); v=_x8(v,_r6(ord,3))
  v=_x8(v,_l7(nf,19)); v=_x8(v,nf)
  v=_x8(v,_l7(v,13)); v=_x8(v,_r6(v,17)); v=_x8(v,_l7(v,5))
  return (v%4294967296)%(__SALT_MAX+1)
end
local function _uz(n)
  local v
  if n%2==1 then v=-(n+1)/2 else v=n/2 end
  if math.tointeger then return math.tointeger(v) end
  return v
end
local function _op() return _x8(_uz(_vi())%4294967296,__MK)%4294967296 end
local function _str()
  local ln=_vi()
  if ln%1~=0 or ln<0 or ln>__RAW_N-__P+1 then __mock() end
  local t={}
  for i=1,ln do
    t[i]=string.char(_x8(__RAW:byte(__P),__KS1[__SC%4096+1]))
    __SC=__SC+1
    __P=__P+1
  end
  return table.concat(t)
end
local function _strref()
  local np=_vi()
  if np%1~=0 or np<1 or np>64 then __mock() end
  local ln=0
  local list={}
  for pi=1,np do
    local plen=_vi()
    if plen%1~=0 or plen<0 or plen>__RAW_N-__P+1 then __mock() end
    list[pi]={p=__P,o=__SC,n=plen}
    __P=__P+plen
    __SC=__SC+plen
    ln=ln+plen
  end
  return {np=np,list=list,n=ln}
end
local function _double_at(p)
  local b0,b1,b2,b3,b4,b5,b6,b7=__RAW:byte(p,p+7)
  if not b7 then __mock() end
  local sgn=(b7>=128) and -1 or 1
  local ex=(b7%128)*16+math.floor(b6/16)
  local mt=(b6%16)*2^48+b5*2^40+b4*2^32+b3*2^24+b2*2^16+b1*2^8+b0
  if ex==2047 then
    if mt==0 then return sgn*(1/0) end
    return 0/0
  elseif ex==0 then
    return sgn*mt*2^-1074
  end
  return sgn*(1+mt*2^-52)*2^(ex-1023)
end
local function _tup(depth)
  depth=(depth or 0)+1
  if depth>256 then __mock() end
  __TO=__TO+1
  if __TO>__NT then __mock() end
  local onum,nf,_salt
  __TUP_HEADER__
  local __bounds=__OP_ARITY[onum]
  if not __VALID_OP[onum] or not __bounds or nf<__bounds[1] or
     (__bounds[2]>=0 and nf>__bounds[2]) then __mock() end
  if _salt<0 or _salt>__SALT_MAX or _salt~=__salt_expected(onum,nf,__TO) then __mock() end
  if nf%1~=0 or nf<0 or nf>__RAW_N-__P+1 then __mock() end
  local t={onum}
  for _=1,nf do
    local tag=__RAW:byte(__P); __P=__P+1
    if tag==__TFI then t[#t+1]=_uz(_vi())
    elseif tag==__TFS then t[#t+1]=_str()
    elseif tag==__TFT then t[#t+1]=_tup(depth)
    elseif tag==__TFY then t[#t+1]=true
    elseif tag==__TFN then t[#t+1]=false
    else __mock() end
  end
  return t
end
local _NC=_vi()
if _NC%1~=0 or _NC<0 or _NC>__RAW_N-__P+1 then __mock() end
local K={}
for ci=1,_NC do
  local tg=__RAW:byte(__P); __P=__P+1
  if tg==__TCI then K[ci]={t=tg,v=_uz(_vi())}
  elseif tg==__TCN then
    if __P+7>__RAW_N then __mock() end
    K[ci]={t=tg,p=__P}
    __P=__P+8
  elseif tg==__TCS then
    local ref=_strref(); ref.t=tg; K[ci]=ref
  elseif tg==__TCY or tg==__TCF then K[ci]={t=tg}
  else __mock() end
end
local _NP=_vi()
if _NP%1~=0 or _NP<1 or _NP>__RAW_N-__P+1 then __mock() end
local PR={}
for pi=1,_NP do
  local np=_vi()
  if np%1~=0 or np<0 or np>__RAW_N-__P+1 then __mock() end
  local ps={}
  for ii=1,np do ps[ii]=_str() end
  local vab=__RAW:byte(__P)
  if vab~=0 and vab~=1 then __mock() end
  local va=vab==1; __P=__P+1
  PR[pi]={p=ps,va=va,b=_tup(0)}
end
if __TO~=__NT or __P~=__RAW_N+1 then __mock() end
__skx_reseal()
]=]
  reader = reader:gsub("__TUP_HEADER__", table.concat(tuple_header, " "))
  L[#L+1] = M(reader)

  -- opcode / operator maps (kept for B2/U2 building, __OP table not emitted to hide signatures)
  local bentries = {}
  for nm, idx in pairs(c.binmap) do
    local src = E2.BIN_SRC[nm]
      or error("emit2: no bin src for " .. tostring(nm), 0)
    bentries[#bentries + 1] = { idx = idx, src = src }
  end
  table.sort(bentries, function(a, b) return a.idx < b.idx end)
  local bparts = {}
  for _, entry in ipairs(bentries) do
    bparts[#bparts + 1] = ("_B2[%d]=%s"):format(entry.idx, entry.src)
  end

  local uentries = {}
  for nm, idx in pairs(c.unmap) do
    local src = E2.UN_SRC[nm]
      or error("emit2: no un src for " .. tostring(nm), 0)
    uentries[#uentries + 1] = { idx = idx, src = src }
  end
  table.sort(uentries, function(a, b) return a.idx < b.idx end)
  local uparts = {}
  for _, entry in ipairs(uentries) do
    uparts[#uparts + 1] = ("_U2[%d]=%s"):format(entry.idx, entry.src)
  end
  L[#L+1] = M("local _B2={}\n" .. table.concat(bparts, "\n"))
  L[#L+1] = M("local _U2={}\n" .. table.concat(uparts, "\n"))
  L[#L+1] = M([=[
local __bc=0
for k,v in pairs(_B2) do
  if type(k)~="number" or type(v)~="function" then __mock() end
  __bc=__bc+1
end
if __bc~=19 then __mock() end
local __uc=0
for k,v in pairs(_U2) do
  if type(k)~="number" or type(v)~="function" then __mock() end
  __uc=__uc+1
end
if __uc~=4 then __mock() end
]=])

  -- engine core (obscured: direct numeric opcodes, no __OP table left visible)
  local _engine_core = [=====[
  local _qA,_qB,_qN={},{},{}
local _G9=_G or _ENV
local unpack=unpack or table.unpack
local function _pack(...) return {n=select("#",...),...} end
local function _tZ(v) return not (v==nil or v==false) end
local function _sN(p) return {v={},p=p} end
local function _put(sc,n,val) sc.v[n]=(val==nil) and _qN or val end
local function _gL(sc,n)
  local cc=sc
  while cc do
    local value=rawget(cc.v,n)
    if value~=nil then
      if value==_qN then return nil end
      return value
    end
    cc=cc.p
  end
  return _G9[n]
end
local function _sG(sc,n,val)
  local cc=sc
  while cc do
    if rawget(cc.v,n)~=nil then _put(cc,n,val) return end
    cc=cc.p
  end
  _G9[n]=val
end
local function _set_path(sc,path,val)
  local parts={}
  for part in path:gmatch("[^\1]+") do parts[#parts+1]=part end
  if #parts==0 then __mock() end
  if #parts==1 then _sG(sc,parts[1],val) return end
  local target=_gL(sc,parts[1])
  for i=2,#parts-1 do target=target[parts[i]] end
  target[parts[#parts]]=val
end
local _EVF,_EXG
local KC={}
local KKREF=function(ix)
  local ki=_x8(ix,__KM)+1
  local cached=KC[ki]
  if cached~=nil then return cached end
  local d=K[ki]
  if type(d)~="table" then __mock() end
  local value
  if d.t==__TCI then value=d.v
  elseif d.t==__TCN then value=_double_at(d.p)
  elseif d.t==__TCS then
    local chars={}
    local cursor=0
    for pi=1,d.np do
      local part=d.list[pi]
      for i=1,part.n do
        cursor=cursor+1
        chars[cursor]=string.char(_x8(__BJ:byte(part.p+i-1),__KS1[(part.o+i-1)%4096+1]))
      end
    end
    if cursor~=d.n then __mock() end
    value=table.concat(chars)
  elseif d.t==__TCY then value=true
  elseif d.t==__TCF then value=false
  else __mock() end
  KC[ki]=value
  return value
end
local function _MV(x,sc)
  local op=x[1]
  if op==__OP.VARG then local va=sc.va or {n=0} return va,(va.n or #va) end
  if op==__OP.CALL or op==__OP.MCALL then
    local fna,args,st,argc
    if op==__OP.MCALL then
      local base=_EVF(x[2],sc)
      fna=base[KKREF(x[3])]
      args={base}
      st,argc=4,1
    else
      fna=_EVF(x[2],sc)
      args={}
      st,argc=3,0
    end
    for i=st,#x do
      local a=x[i]
      local last=i==#x
      if a[1]==__OP.VARG then
        local va=sc.va or {n=0} local cnt=va.n or #va
        if last then
          for kk=1,cnt do argc=argc+1 args[argc]=va[kk] end
        else
          argc=argc+1 args[argc]=va[1]
        end
      elseif a[1]==__OP.CALL or a[1]==__OP.MCALL then
        local values,count=_MV(a,sc)
        if last then
          for kk=1,count do argc=argc+1 args[argc]=values[kk] end
        else
          argc=argc+1 args[argc]=values[1]
        end
      else
        argc=argc+1 args[argc]=_EVF(a,sc)
      end
    end
    local rs=_pack(fna(unpack(args,1,argc)))
    return rs,rs.n
  end
  local rs=_pack(_EVF(x,sc))
  return rs,1
end
_EVF=function(x,sc)
  local op=x[1]
  if op==__OP.KON then return KKREF(x[2])
  elseif op==__OP.NIL then return nil
  elseif op==__OP.TRUE then return true
  elseif op==__OP.FALSE then return false
  elseif op==__OP.NAME then return _gL(sc,x[2])
  elseif op==__OP.IDX then return _EVF(x[2],sc)[_EVF(x[3],sc)]
  elseif op==__OP.VARG then local va=sc.va or {} return va[1]
  elseif op==__OP.CALL or op==__OP.MCALL then
    local tt=_MV(x,sc) return tt[1]
  elseif op==__OP.ANDJ then
    local aa=_EVF(x[2],sc)
    if _tZ(aa) then return _EVF(x[3],sc) end return aa
  elseif op==__OP.ORJ then
    local aa=_EVF(x[2],sc)
    if _tZ(aa) then return aa end return _EVF(x[3],sc)
  elseif op==__OP.BIN then
    local ff=_B2[x[2]]
    if ff then return ff(_EVF(x[3],sc),_EVF(x[4],sc)) end
    __mock()
  elseif op==__OP.UN then
    local ff=_U2[x[2]]
    if ff then return ff(_EVF(x[3],sc)) end
    __mock()
  elseif op==__OP.TBL then
    local t={} local ii=1
    for j=2,#x do
      local it=x[j]
      if it[1]==__OP.TBLS then
        local item=it[2]
        if j==#x and (item[1]==__OP.CALL or item[1]==__OP.MCALL or item[1]==__OP.VARG) then
          local values,count=_MV(item,sc)
          for k=1,count do t[ii]=values[k] ii=ii+1 end
        else
          t[ii]=_EVF(item,sc) ii=ii+1
        end
      else t[_EVF(it[2],sc)]=_EVF(it[3],sc) end
    end
    return t
  elseif op==__OP.FUNC then
    local id=x[2] local dsc=sc
    return function(...)
      local pr=PR[id]
      local ar=_pack(...) local nn=ar.n
      local nsc=_sN(dsc)
      for i=1,#pr.p do _put(nsc,pr.p[i],ar[i]) end
      if pr.va then
        local va={n=math.max(0,nn-#pr.p)}
        for i=#pr.p+1,nn do va[i-#pr.p]=ar[i] end
        nsc.va=va
      end
      return _XP(id,nsc)
    end
  end
  __mock()
end
local function _EL(stv,sc)
  local vals,n={},0
  for vi=2,#stv do
    local vx=stv[vi]
    if vi==#stv and (vx[1]==__OP.CALL or vx[1]==__OP.VARG or vx[1]==__OP.MCALL) then
      local expanded,count=_MV(vx,sc)
      for k=1,count do n=n+1 vals[n]=expanded[k] end
    else
      n=n+1 vals[n]=_EVF(vx,sc)
    end
  end
  return vals,n
end
local function _AV(tg,stv,sc)
  local vals=_EL(stv,sc)
  local refs={}
  for ti=2,#tg do
    local target=tg[ti]
    if target[1]==__OP.TGTNM then refs[ti-1]={name=target[2]}
    else refs[ti-1]={obj=_EVF(target[2],sc),key=_EVF(target[3],sc)} end
  end
  for index,ref in ipairs(refs) do
    if ref.name then _sG(sc,ref.name,vals[index])
    else ref.obj[ref.key]=vals[index] end
  end
end
local function _LV(names,stv,sc)
  local vals=_EL(stv,sc)
  for ni=2,#names do _put(sc,names[ni],vals[ni-1]) end
end
local function _CA(target,binid,rhs,sc)
  local fn=_B2[binid]
  if not fn then __mock() end
  if target[1]==__OP.TGTNM then
    local name=target[2]
    _sG(sc,name,fn(_gL(sc,name),_EVF(rhs,sc)))
  else
    local obj=_EVF(target[2],sc)
    local key=_EVF(target[3],sc)
    obj[key]=fn(obj[key],_EVF(rhs,sc))
  end
end
_EXG=function(sq,sc)
  for si=2,#sq do
    local st=sq[si]
    local op=st[1]
    if op==__OP.SETL then
      _put(sc,st[2],_EVF(st[3],sc))
    elseif op==__OP.LSET then _LV(st[2],st[3],sc)
    elseif op==__OP.SETGFN then _set_path(sc,KKREF(st[2]),_EVF(st[4],sc))
    elseif op==__OP.EX then _EVF(st[2],sc)
    elseif op==__OP.ASN then _AV(st[2],st[3],sc)
    elseif op==__OP.CASN then _CA(st[2],st[3],st[4],sc)
    elseif op==__OP.BLK then
      local r=_EXG(st[2],_sN(sc))
      if r then return r end
    elseif op==__OP.WHILE then
      while true do
        if not _tZ(_EVF(st[2],sc)) then break end
        local r=_EXG(st[3],_sN(sc))
        if r==_qA then break end
        if r~=nil and r~=_qB then return r end
      end
    elseif op==__OP.REP then
      while true do
        local nsc=_sN(sc)
        local r=_EXG(st[2],nsc)
        if r==_qA then break end
        if r~=nil and r~=_qB then return r end
        if _tZ(_EVF(st[3],nsc)) then break end
      end
    elseif op==__OP.IF then
      local dn=false
      for cj=2,#st[2] do
        local cl=st[2][cj]
        if _tZ(_EVF(cl[2],sc)) then
          dn=true
          local r=_EXG(cl[3],_sN(sc))
          if r then return r end
          break
        end
      end
      if not dn and type(st[3])=="table" then
        local r=_EXG(st[3],_sN(sc))
        if r then return r end
      end
    elseif op==__OP.NFOR then
      local s0=_EVF(st[3],sc) local e0=_EVF(st[4],sc)
      local sp=(st[5]~=false) and _EVF(st[5],sc) or 1
      if sp==0 then error("'for' step is zero") end
      local vv=st[2]
      local i=s0
      while (sp>0 and i<=e0) or (sp<0 and i>=e0) do
        local nsc=_sN(sc) _put(nsc,vv,i)
        local r=_EXG(st[6],nsc)
        if r==_qA then break end
        if r~=nil and r~=_qB then return r end
        i=i+sp
      end
    elseif op==__OP.GFOR then
      local init=_EL(st[3],sc)
      local ff,s2,c2=init[1],init[2],init[3]
      local vars={}
      for vnm in KKREF(st[2]):gmatch("[^\1]+") do vars[#vars+1]=vnm end
      while true do
        local rs=_pack(ff(s2,c2))
        if rs[1]==nil then break end
        c2=rs[1]
        local nsc=_sN(sc)
        for i=1,#vars do _put(nsc,vars[i],rs[i]) end
        local r=_EXG(st[4],nsc)
        if r==_qA then break end
        if r~=nil and r~=_qB then return r end
      end
    elseif op==__OP.RET then
      local res,nr=_EL(st[2],sc)
      return {list=res,n=nr}
    elseif op==__OP.BRK then return _qA
    elseif op==__OP.CNT then return _qB
    else __mock() end
  end
end
function _XP(id,nsc)
  local pr=PR[id]
  local r=_EXG(pr.b,nsc)
  if type(r)=="table" and r.list then return unpack(r.list,1,r.n) end
end
]=====]
  _engine_core = _engine_core:gsub("__OP%.([A-Z_]+)", function(n) return tostring(c.opmap[n]) end)
  if _engine_core:find("__OP", 1, true) then
    error("emit2: unresolved opcode placeholder", 0)
  end
  -- VM diagnostic logger: wrap _gL/_sG to observe global operations (only when enabled)
  if c.env_policy and c.env_policy.mode == "diagnostic" then
    _engine_core = _engine_core .. M([[
local _gL_orig=_gL
_gL=function(sc,n)
  local cc=sc
  while cc do
    local v=rawget(cc.v,n)
    if v~=nil then
      if not __skx_log.reentry then
        if v==_qN then __skx_log.emit("GLOBAL_READ","ok",{h=__skx_log.hash_name(n),hit="local_nil"})
        else __skx_log.emit("GLOBAL_READ","ok",{h=__skx_log.hash_name(n),hit="local"}) end
      end
      if v==_qN then return nil end
      return v
    end
    cc=cc.p
  end
  local gv=_G9[n]
  if not __skx_log.reentry then
    if gv==nil then __skx_log.emit("GLOBAL_MISS","ok",{h=__skx_log.hash_name(n)})
    else __skx_log.emit("GLOBAL_READ","ok",{h=__skx_log.hash_name(n),hit="global"}) end
  end
  return gv
end
local _sG_orig=_sG
_sG=function(sc,n,val)
  local cc=sc
  while cc do
    if rawget(cc.v,n)~=nil then
      if not __skx_log.reentry then __skx_log.emit("GLOBAL_WRITE","ok",{h=__skx_log.hash_name(n)}) end
      return _sG_orig(sc,n,val)
    end
    cc=cc.p
  end
  if not __skx_log.reentry then __skx_log.emit("GLOBAL_WRITE","ok",{h=__skx_log.hash_name(n),hit="global"}) end
  return _sG_orig(sc,n,val)
end
]])
  end
  L[#L+1] = M(_engine_core)
  -- boot glue: channel canary re-check + final watchdog re-seal.
  -- If no canary exists (protections stripped from build), degrade safely.
  L[#L+1] = M([[
do
  if __skx_canary_recheck then __skx_canary_recheck() end
  __skx_reseal()
end
_XP(1,_sN(nil))
]])

  return table.concat(L, "\n")
end

return E2
