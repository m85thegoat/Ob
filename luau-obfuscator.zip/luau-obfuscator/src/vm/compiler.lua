-- vm/compiler.lua :: AST -> tuple program
-- proto = { params={}, is_vararg=bool, body={stmt tuples...} }
-- expr  = { op=OPNAME, a={children...} } ; constants & protos live on ROOT
local unpack = unpack or table.unpack
local C = {}
local SQ -- forward

local function xt(op, ...) return { op = op, a = { ... } } end

local E, STMT, LST

E = function(R, e)
  local t = e.type
  if t == "Nil" then return xt("NIL")
  elseif t == "True" then return xt("TRUE")
  elseif t == "False" then return xt("FALSE")
  elseif t == "Number" or t == "String" then return xt("KON", C.konst(R, e.value))
  elseif t == "Vararg" then return xt("VARG")
  elseif t == "Name" then return xt("NAME", e.name)
  elseif t == "Paren" then return E(R, e.e)
  elseif t == "Index" then return xt("IDX", E(R, e.obj), E(R, e.key))
  elseif t == "Call" then
    local args = {}
    for i, a in ipairs(e.args) do args[i] = E(R, a) end
    return xt("CALL", E(R, e.fn), unpack(args))
  elseif t == "Method" then
    local args = {}
    for i, a in ipairs(e.args) do args[i] = E(R, a) end
    return xt("MCALL", E(R, e.obj), C.konst(R, e.name), unpack(args))
  elseif t == "Function" then
    local sub = {
      params = e.params, is_vararg = e.is_vararg,
      body = nil, id = nil,
    }
    R.protos[#R.protos + 1] = sub
    sub.id = #R.protos
    sub.body = SQ(R, e.body)
    return xt("FUNC", sub.id)
  elseif t == "Table" then
    local tup = { "TBL" }
    for _, en in ipairs(e.entries) do
      if en.kind == "keyed" then
        tup[#tup + 1] = xt("TBLK", E(R, en.key), E(R, en.val))
      else
        tup[#tup + 1] = xt("TBLS", E(R, en.val))
      end
    end
    return tup
  elseif t == "Binop" then
    if e.op == "and" then return xt("ANDJ", E(R, e.l), E(R, e.r)) end
    if e.op == "or" then return xt("ORJ", E(R, e.l), E(R, e.r)) end
    local bidx = R.binmap and R.binmap[e.op]
      or error("vm: no binmap for op " .. tostring(e.op), 0)
    -- raw numeric id as immediate operand (engine dispatches _B2[id])
    return xt("BIN", bidx, E(R, e.l), E(R, e.r))
  elseif t == "Unop" then
    local uidx = R.unmap and R.unmap[e.op]
      or error("vm: no unmap for op " .. tostring(e.op), 0)
    return xt("UN", uidx, E(R, e.e))
  end
  error("vm: bad expr " .. tostring(t), 0)
end

function C.konst(R, v)
  R.k[#R.k + 1] = v
  return #R.k - 1
end

STMT = function(R, out, s)
  local t = s.type
  if t == "Local" then
    local values = {}
    for i = 1, #s.exprs do values[i] = E(R, s.exprs[i]) end
    out[#out + 1] = { "LSET", LST(s.names), LST(values) }
  elseif t == "LocalFunction" then
    out[#out + 1] = { "SETL", s.name,
      E(R, { type = "Function", params = s.func.params,
             is_vararg = s.func.is_vararg, body = s.func.body }), true }
  elseif t == "FunctionDecl" then
    out[#out + 1] = { "SETGFN", C.konst(R, table.concat(s.path, "\1")), s.is_method,
      E(R, { type = "Function", params = s.func.params,
             is_vararg = s.func.is_vararg, body = s.func.body }) }
  elseif t == "Assign" then
    local tg, vl = {}, {}
    for i, x in ipairs(s.targets) do
      if x.type == "Index" then tg[i] = xt("TGTIDX", E(R, x.obj), E(R, x.key))
      else tg[i] = xt("TGTNM", x.name) end
    end
    for i, x in ipairs(s.exprs) do vl[i] = E(R, x) end
    out[#out + 1] = { "ASN", LST(tg), LST(vl) }
  elseif t == "CompoundAssign" then
    local target
    if s.target.type == "Index" then
      target = xt("TGTIDX", E(R, s.target.obj), E(R, s.target.key))
    else
      target = xt("TGTNM", s.target.name)
    end
    local bidx = R.binmap and R.binmap[s.op]
      or error("vm: no binmap for op " .. tostring(s.op), 0)
    out[#out + 1] = { "CASN", target, bidx, E(R, s.expr) }
  elseif t == "ExprStat" then
    out[#out + 1] = { "EX", E(R, s.expr) }
  elseif t == "Do" then
    out[#out + 1] = { "BLK", SQ(R, s.body) }
  elseif t == "While" then
    out[#out + 1] = { "WHILE", E(R, s.cond), SQ(R, s.body) }
  elseif t == "Repeat" then
    out[#out + 1] = { "REP", SQ(R, s.body), E(R, s.cond) }
  elseif t == "If" then
    local cls = {}
    for _, cl in ipairs(s.clauses) do
      cls[#cls + 1] = xt("IFCL", E(R, cl.cond), SQ(R, cl.body))
    end
    out[#out + 1] = { "IF", LST(cls), s.orelse and SQ(R, s.orelse) or false }
  elseif t == "NumericFor" then
    out[#out + 1] = { "NFOR", s.var, E(R, s.start), E(R, s.stop),
                      s.step and E(R, s.step) or false, SQ(R, s.body) }
  elseif t == "GenericFor" then
    local es = {}
    for i, ex in ipairs(s.exprs) do es[i] = E(R, ex) end
    out[#out + 1] = { "GFOR", C.konst(R, table.concat(s.vars, "\1")),
                      LST(es), SQ(R, s.body) }
  elseif t == "Return" then
    local es = {}
    for i, ex in ipairs(s.exprs) do es[i] = E(R, ex) end
    out[#out + 1] = { "RET", LST(es) }
  elseif t == "Break" then out[#out + 1] = { "BRK" }
  elseif t == "Continue" then out[#out + 1] = { "CNT" }
  elseif t == "Goto" or t == "Label" then
    error("vm mode: goto unsupported", 0)
  else
    error("vm: bad stmt " .. tostring(t), 0)
  end
end

function C.seq(R, out, stats)
  for _, s in ipairs(stats) do STMT(R, out, s) end
  return out
end

function C.lst(list)
  return LST(list)
end

LST = function(list)
  -- wrap ALREADY-COMPILED tuples into a flat SEQ-style tuple
  local t = { "SEQ" }
  for _, x in ipairs(list) do t[#t + 1] = x end
  return t
end

SQ = function(R, stats)
  -- statement-style tuple: { "SEQ", st1, st2, ... } (flat, no .a wrapper)
  local t = { "SEQ" }
  for _, st in ipairs(C.seq(R, {}, stats)) do t[#t + 1] = st end
  return t
end


-- API: C.compile(chunk_ast[, maps]) -> root proto
function C.compile(chunk_ast, maps)
  maps = maps or {}
  local R = { k = {}, protos = {}, binmap = maps.binmap, unmap = maps.unmap }
  local root = { params = {}, is_vararg = true, body = {}, id = 1 }
  R.protos[1] = root
  root.body = SQ(R, chunk_ast.body)
  root.k = R.k
  root.allprotos = R.protos
  return root
end

return C
