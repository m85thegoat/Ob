-- printer.lua :: AST -> Lua/Luau source
local Printer = {}

local BINPREC = {
  ["or"]=1, ["and"]=2,
  ["<"]=3,[">"]=3,["<="]=3,[">="]=3,["~="]=3,["=="]=3,
  ["|"]=4, ["~"]=5, ["&"]=6, ["<<"]=7,[">>"]=7,
  [".."]=9, ["+"]=10,["-"]=10,
  ["*"]=11,["/"]=11,["//"]=11,["%"]=11,
  ["^"]=14,
}
local RIGHTASSOC = { [".."]=true, ["^"]=true }
local UNARYPREC = 12

function Printer.escape_string(s)
  local out = {}
  for i = 1, #s do
    local b = s:byte(i)
    local c = s:sub(i, i)
    if c == '"' then out[#out+1] = '\\"'
    elseif c == "\\" then out[#out+1] = "\\\\"
    elseif c == "\n" then out[#out+1] = "\\n"
    elseif c == "\r" then out[#out+1] = "\\r"
    elseif c == "\t" then out[#out+1] = "\\t"
    elseif b >= 32 and b <= 126 then out[#out+1] = c
    else out[#out+1] = string.format("\\x%02x", b) end
  end
  return table.concat(out)
end

local function numstr(n)
  if math.type and math.type(n) == "integer" then return tostring(n) end
  local s = string.format("%.17g", n)
  if s == "-0" then s = "0" end
  return s
end

local P = {}

local function prec_of(e)
  if e.type == "Binop" then return BINPREC[e.op]
  elseif e.type == "Unop" then return e.op == "^" and 14 or UNARYPREC
  end
  return 100
end

P.expr = function(self, e)
  local t = e.type
  if t == "Nil" then return "nil"
  elseif t == "True" then return "true"
  elseif t == "False" then return "false"
  elseif t == "Vararg" then return "..."
  elseif t == "Number" then return numstr(e.value)
  elseif t == "String" then return '"' .. Printer.escape_string(e.value) .. '"'
  elseif t == "Name" then return e.name
  elseif t == "Paren" then return "(" .. P.expr(self, e.e) .. ")"
  elseif t == "Index" then
    local o = P.sub(self, e.obj, 100)
    return o .. "[" .. P.expr(self, e.key) .. "]"
  elseif t == "Call" then
    local args = {}
    for i, a in ipairs(e.args) do args[i] = P.expr(self, a) end
    return P.sub(self, e.fn, 100) .. "(" .. table.concat(args, ",") .. ")"
  elseif t == "Method" then
    local args = {}
    for i, a in ipairs(e.args) do args[i] = P.expr(self, a) end
    return P.sub(self, e.obj, 100) .. ":" .. e.name .. "(" .. table.concat(args, ",") .. ")"
  elseif t == "Function" then
    local params = {}
    for i, p in ipairs(e.params) do params[i] = p end
    if e.is_vararg then params[#params + 1] = "..." end
    return "function(" .. table.concat(params, ",") .. ")" .. P.block(self, e.body) .. "end"
  elseif t == "Table" then
    local parts = {}
    for _, en in ipairs(e.entries) do
      if en.kind == "item" then parts[#parts + 1] = P.expr(self, en.val)
      else parts[#parts + 1] = "[" .. P.expr(self, en.key) .. "]" .. "=" .. P.expr(self, en.val) end
    end
    return "{" .. table.concat(parts, ";") .. "}"
  elseif t == "Binop" then
    local myp = BINPREC[e.op]
    local l = P.sub(self, e.l, RIGHTASSOC[e.op] and (myp + 1) or myp)
    local r = P.sub(self, e.r, RIGHTASSOC[e.op] and myp or (myp + 1))
    -- token-fusion guards:
    --  'x - -y' would lex as comment; '3 ..s' would be a malformed number
    local sl = (e.op == ".." and l:match("%d$")) and " " or ""
    local sr = (e.op == "-" and r:sub(1, 1) == "-") and " " or ""
    return l .. sl .. e.op .. sr .. r
  elseif t == "Unop" then
    local inner = P.sub(self, e.e, UNARYPREC)
    -- token-fusion guard: '-' over an operand printing '-' would lex as a
    -- comment ('--x'); separate the tokens with a space.
    if e.op == "-" and inner:sub(1, 1) == "-" then inner = " " .. inner end
    return e.op .. inner
  end
  error("printer: unknown expr type " .. tostring(t), 0)
end

-- print child with parens if its precedence is below required
P.sub = function(self, e, minprec)
  local s = P.expr(self, e)
  if prec_of(e) < minprec then return "(" .. s .. ")" end
  -- unary minus followed by numeric needs no help; but `-x^2` handled by prec
  return s
end

P.stmt = function(self, s, ind)
  local pad = string.rep(self.indent, ind)
  local t = s.type
  if t == "Local" then
    local names = table.concat(s.names, ",")
    if #s.exprs == 0 then return pad .. "local " .. names end
    local vals = {}
    for i, v in ipairs(s.exprs) do vals[i] = P.expr(self, v) end
    return pad .. "local " .. names .. "=" .. table.concat(vals, ",")
  elseif t == "LocalFunction" then
    return pad .. "local function " .. s.name .. P.fnhead(self, s.func) ..
           P.block(self, s.func.body, ind + 1) .. pad .. "end "
  elseif t == "FunctionDecl" then
    local sep = s.is_method and ":" or "."
    local headparts = {}
    for i = 1, #s.path - 1 do headparts[#headparts + 1] = s.path[i] end
    local lhs = table.concat(headparts, ".")
    if #lhs > 0 then lhs = lhs .. sep end
    lhs = lhs .. s.path[#s.path]
    return pad .. "function " .. lhs .. P.fnhead(self, s.func, s.is_method) ..
           P.block(self, s.func.body, ind + 1) .. pad .. "end "
  elseif t == "Assign" then
    local tg, vl = {}, {}
    for i, x in ipairs(s.targets) do tg[i] = P.expr(self, x) end
    for i, x in ipairs(s.exprs) do vl[i] = P.expr(self, x) end
    return pad .. table.concat(tg, ",") .. "=" .. table.concat(vl, ",")
  elseif t == "CompoundAssign" then
    -- desugar Luau compound assignment -> portable plain assignment
    return pad .. P.expr(self, s.target) .. "=" ..
           P.expr(self, { type = "Binop", op = s.op, l = s.target, r = s.expr })
  elseif t == "ExprStat" then
    return pad .. P.expr(self, s.expr)
  elseif t == "Do" then
    return pad .. "do " .. P.block(self, s.body, ind + 1) .. pad .. "end "
  elseif t == "While" then
    return pad .. "while " .. P.expr(self, s.cond) .. " do " ..
           P.block(self, s.body, ind + 1) .. pad .. "end "
  elseif t == "Repeat" then
    return pad .. "repeat " .. P.block(self, s.body, ind + 1) ..
           pad .. "until " .. P.expr(self, s.cond)
  elseif t == "If" then
    local out = {}
    for i, cl in ipairs(s.clauses) do
      if i == 1 then out[#out + 1] = pad .. "if " .. P.expr(self, cl.cond) .. " then "
      else out[#out + 1] = pad .. "elseif " .. P.expr(self, cl.cond) .. " then " end
      out[#out + 1] = P.block(self, cl.body, ind + 1)
    end
    if s.orelse then
      out[#out + 1] = pad .. "else "
      out[#out + 1] = P.block(self, s.orelse, ind + 1)
    end
    out[#out + 1] = pad .. "end "
    return table.concat(out)
  elseif t == "NumericFor" then
    local hdr = "for " .. s.var .. "=" .. P.expr(self, s.start) .. "," .. P.expr(self, s.stop)
    if s.step then hdr = hdr .. "," .. P.expr(self, s.step) end
    return pad .. hdr .. " do " .. P.block(self, s.body, ind + 1) .. pad .. "end "
  elseif t == "GenericFor" then
    local vs, es = {}, {}
    for i, v in ipairs(s.vars) do vs[i] = v end
    for i, v in ipairs(s.exprs) do es[i] = P.expr(self, v) end
    return pad .. "for " .. table.concat(vs, ",") .. " in " .. table.concat(es, ",") ..
           " do " .. P.block(self, s.body, ind + 1) .. pad .. "end "
  elseif t == "Return" then
    local vals = {}
    for i, v in ipairs(s.exprs) do vals[i] = P.expr(self, v) end
    return pad .. "return " .. table.concat(vals, ",")
  elseif t == "Break" then return pad .. "break"
  elseif t == "Continue" then return pad .. "continue"
  elseif t == "Goto" then return pad .. "goto " .. s.label
  elseif t == "Label" then return pad .. "::" .. s.name .. "::"
  end
  error("printer: unknown stmt type " .. tostring(t), 0)
end

P.fnhead = function(self, f, skip_first)
  local params = {}
  local start = skip_first and 2 or 1
  for i = start, #f.params do params[#params + 1] = f.params[i] end
  if f.is_vararg then params[#params + 1] = "..." end
  return "(" .. table.concat(params, ",") .. ")"
end

P.block = function(self, stats, ind)
  ind = ind or 0
  local out = {}
  for _, s in ipairs(stats) do out[#out + 1] = P.stmt(self, s, ind) .. ";" end
  return table.concat(out)
end

--- API ---
-- Printer.print(ast, opts) -> source string
function Printer.print(chunk, opts)
  opts = opts or {}
  local self = { indent = opts.indent or "\t" }
  return P.block(self, chunk.body, 0)
end

return Printer
