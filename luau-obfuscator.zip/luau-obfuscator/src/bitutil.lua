-- bitutil.lua :: portable bitwise ops, RNG, hashing (pure Lua, 5.1..5.4 / LuaJIT)
local M = {}

local floor = math.floor
local band_m, bxor_m

-- detect native bit ops at load: prefer arithmetic fallbacks for portability
-- all ops operate on signed 32-bit domain, inputs normalized to unsigned
local function norm(x) x = x % 4294967296; if x >= 2147483648 then x = x - 4294967296 end return x end

function M.band(a, b)
  a = floor(a) % 4294967296; b = floor(b) % 4294967296
  local r, p = 0, 1
  for _ = 1, 32 do
    local ab, bb = a % 2, b % 2
    if ab == 1 and bb == 1 then r = r + p end
    a = (a - ab) / 2; b = (b - bb) / 2; p = p * 2
  end
  return norm(r)
end

function M.bor(a, b)
  a = floor(a) % 4294967296; b = floor(b) % 4294967296
  local r, p = 0, 1
  for _ = 1, 32 do
    local ab, bb = a % 2, b % 2
    if ab == 1 or bb == 1 then r = r + p end
    a = (a - ab) / 2; b = (b - bb) / 2; p = p * 2
  end
  return norm(r)
end

function M.bxor(a, b)
  a = floor(a) % 4294967296; b = floor(b) % 4294967296
  local r, p = 0, 1
  for _ = 1, 32 do
    local ab, bb = a % 2, b % 2
    if ab ~= bb then r = r + p end
    a = (a - ab) / 2; b = (b - bb) / 2; p = p * 2
  end
  return norm(r)
end

function M.bnot(a) return norm(M.bxor(floor(a), -1)) end

function M.lshift(a, n)
  n = n % 32
  if n == 0 then return norm(floor(a)) end
  return norm((floor(a) % 4294967296) * 2 ^ n)
end

function M.rshift(a, n)
  n = n % 32
  local ua = floor(a) % 4294967296
  if n == 0 then return norm(ua) end
  return norm(floor(ua / 2 ^ n))
end

function M.arshift(a, n)
  n = n % 32
  if n == 0 then return norm(floor(a)) end
  local ua = floor(a) % 4294967296
  local r = floor(ua / 2 ^ n)
  -- sign-extend: fill the vacated high bits with the sign bit
  if ua >= 2147483648 and n > 0 then
    r = M.bor(r % 4294967296, M.bxor(2 ^ (32 - n) - 1, 4294967295))
  end
  return norm(r)
end

-- xorshift32 RNG
local function rng_next(state)
  local x = state.v
  x = M.bxor(x, M.lshift(x, 13))
  x = M.bxor(x, M.rshift(x, 17))
  x = M.bxor(x, M.lshift(x, 5))
  state.v = norm(x)
  return norm(x)
end

function M.newrng(seed)
  seed = seed or os.time()
  seed = norm(floor(seed))
  if seed == 0 then seed = 0x9E3779B9 end
  local s = { v = seed }
  -- warmup 16 for better diffusion
  for _ = 1, 16 do rng_next(s) end
  local o = {}
  o.next = function() return rng_next(s) end
  o.int = function(lo, hi) return lo + rng_next(s) % (hi - lo + 1) end
  o.pick = function(t) return t[1 + rng_next(s) % #t] end
  o.float = function() return rng_next(s) / 4294967296 end
  return o
end

-- FNV-1a 32-bit
function M.fnv1a(str)
  local h = 2166136261
  for i = 1, #str do
    h = M.bxor(h, str:byte(i))
    h = h * 16777619
    h = h % 4294967296
  end
  return norm(h)
end

-- CRC32 (IEEE)
local crc_table
local function make_crc_table()
  crc_table = {}
  for n = 0, 255 do
    local c = n
    for _ = 1, 8 do
      if c % 2 == 1 then c = M.bxor(c, 0xEDB88320) end
      c = floor(c / 2)
    end
    crc_table[n] = c
  end
end

function M.crc32(str)
  if not crc_table then make_crc_table() end
  local c = 4294967295
  for i = 1, #str do
    c = M.bxor(floor(c / 256), crc_table[M.bxor(c % 256, str:byte(i))])
    c = c % 4294967296
  end
  return norm(M.bxor(c, 4294967295))
end

function M.tohex(n) return string.format("%08x", norm(n) % 4294967296) end

return M
