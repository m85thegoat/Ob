-- parser.lua :: recursive descent parser -> AST (Lua 5.4 + Luau-friendly)
local Lexer = require("lexer")

local Parser = {}
Parser.__index = Parser

local COMPOUND_OPS = {
  ["+="]="+",["-="]="-",["*="]="*",["/="]="/",["//="]="//",["%="]="%",["^="]="^",["..="]="..",
}
Parser.COMPOUND_OPS = COMPOUND_OPS

-- binary operator precedence (Lua reference manual); right = right-assoc
local BINPREC = {
  ["or"]=1, ["and"]=2,
  ["<"]=3,[">"]=3,["<="]=3,[">="]=3,["~="]=3,["=="]=3,
  ["|"]=4, ["~"]=5, ["&"]=6, ["<<"]=7,[">>"]=7,
  [".."]=9, ["+"]=10,["-"]=10,
  ["*"]=11,["/"]=11,["//"]=11,["%"]=11,
  ["^"]=14,
}
local RIGHTASSOC = { [".."]=true, ["^"]=true }
local UNARYPREC = 12
local TYPE_STOP_KW = {
  ["return"]=true,["do"]=true,["end"]=true,["then"]=true,["else"]=true,["elseif"]=true,
  ["local"]=true,["function"]=true,["if"]=true,["while"]=true,["for"]=true,
  ["repeat"]=true,["break"]=true,["continue"]=true,["goto"]=true,["in"]=true,
}

function Parser.new(src)
  local toks = Lexer.new(src):tokenize()
  return setmetatable({ toks = toks, i = 1 }, Parser)
end

function Parser:_peek(o) o = o or 0; return self.toks[self.i + o] end
function Parser:_t() return self.toks[self.i] end
function Parser:_advance() local t = self.toks[self.i]; self.i = self.i + 1; return t end

function Parser:_check(type_, v)
  local t = self.toks[self.i]
  return t.type == type_ and (v == nil or t.value == v)
end

function Parser:_accept(type_, v)
  if self:_check(type_, v) then return self:_advance() end
  return nil
end

function Parser:_expect(type_, v)
  local t = self.toks[self.i]
  if t.type ~= type_ or (v ~= nil and t.value ~= v) then
    error(string.format("parse error @ line %d: expected %s%s, got %s(%s)",
      t.line, type_, v and "(" .. tostring(v) .. ")" or "", t.type, tostring(t.value)), 0)
  end
  return self:_advance()
end

function Parser:_err(msg)
  local t = self.toks[self.i]
  error(string.format("parse error @ line %d: %s (got %s=%s)", t.line, msg, t.type, tostring(t.value)), 0)
end

--------------------------------------------------------------------- types
-- skip a balanced type annotation span starting AT current token
function Parser:_skip_type()
  local depth = 0
  while true do
    local t = self.toks[self.i]
    if t.type == "eof" then return end
    if depth == 0 then
      if t.type == "=" or t.type == "," or t.type == ";" or t.type == ")"
         or t.type == "]" or t.type == "}" or TYPE_STOP_KW[t.type]
         or (t.type == "name") then
        -- a bare name at depth0 only terminates if we already consumed something;
        -- handled below by tracking consumed count
      end
    end
    -- consume logic with depth tracking
    local tt = t.type
    if tt == "(" or tt == "{" or tt == "[" or tt == "<" then
      depth = depth + 1; self:_advance()
    elseif tt == ")" or tt == "}" or tt == "]" or tt == ">" then
      if depth == 0 then return end
      depth = depth - 1; self:_advance()
      if depth == 0 then
        -- after closing a group the type may continue with -> | ? . etc; peek ahead
        local nx = self:_peek()
        if not (nx.type == "->" or nx.type == "|" or nx.type == "&" or nx.type == "?"
                or nx.type == "." or nx.type == "<" or nx.type == "(" or nx.type == "["
                or nx.type == "string" or nx.type == "number") then
          return
        end
      end
    elseif depth == 0 and (tt == "=" or tt == "," or tt == ";" or TYPE_STOP_KW[tt]) then
      return
    elseif depth == 0 and tt == "name" then
      -- identifier: consume it, then decide whether more type follows
      self:_advance()
      local nx = self:_peek()
      if not (nx.type == "." or nx.type == "<" or nx.type == "?" or nx.type == "|"
              or nx.type == "&" or nx.type == "->" or nx.type == "(" or nx.type == "["
              or nx.type == "string" or nx.type == "number") then
        return
      end
    elseif depth == 0 and tt == "string" then
      self:_advance() -- singleton type "foo"
      local nx = self:_peek()
      if not (nx.type == "|" or nx.type == "?" or nx.type == "->") then return end
    else
      self:_advance()
    end
  end
end

--------------------------------------------------------------------- expressions
local function binnode(op, l, r) return { type = "Binop", op = op, l = l, r = r } end

function Parser:parse_expr(limit)
  limit = limit or 0
  local left
  local t = self.toks[self.i]
  if UNARYPREC > limit and (t.type == "not" or (t.type == "-" ) or (t.type == "#")
      or (t.type == "~")) then
    self:_advance()
    local operand = self:parse_expr(UNARYPREC)
    left = { type = "Unop", op = t.type, e = operand }
  else
    left = self:parse_simple()
  end
  while true do
    local op = self.toks[self.i].type
    local prec = BINPREC[op]
    if prec and prec > limit then
      self:_advance()
      local nextlimit = RIGHTASSOC[op] and (prec - 1) or prec
      local right = self:parse_expr(nextlimit)
      left = binnode(op, left, right)
    else
      break
    end
  end
  return left
end

function Parser:parse_simple()
  local t = self.toks[self.i]
  local prim
  if t.type == "nil" then self:_advance(); prim = { type = "Nil" }
  elseif t.type == "true" then self:_advance(); prim = { type = "True" }
  elseif t.type == "false" then self:_advance(); prim = { type = "False" }
  elseif t.type == "..." then self:_advance(); prim = { type = "Vararg" }
  elseif t.type == "number" then self:_advance(); prim = { type = "Number", value = t.value }
  elseif t.type == "string" then self:_advance(); prim = { type = "String", value = t.value }
  elseif t.type == "istring" then
    self:_advance()
    prim = self:istring_to_concat(t.value)
  elseif t.type == "{" then
    prim = self:parse_table()
  elseif t.type == "function" then
    self:_advance()
    prim = self:parse_funcbody(false)
  elseif t.type == "name" then
    self:_advance()
    prim = { type = "Name", name = t.value }
  elseif t.type == "(" then
    self:_advance()
    local e = self:parse_expr(0)
    self:_expect(")")
    prim = { type = "Paren", e = e }
  else
    self:_err("unexpected symbol in expression")
  end
  return self:parse_suffix(prim)
end

function Parser:istring_to_concat(parts)
  -- lexer format: sequence of strings; `{` emits {expr_start=true} then the raw expr text
  local acc
  local i = 1
  while i <= #parts do
    local p = parts[i]
    local piece
    if type(p) == "table" and p.expr_start then
      local text = parts[i + 1]
      i = i + 2
      local sub = Parser.new(tostring(text or ""))
      piece = sub:parse_expr(0)
    else
      piece = { type = "String", value = tostring(p) }
      i = i + 1
    end
    if acc then acc = binnode("..", acc, piece) else acc = piece end
  end
  return acc or { type = "String", value = "" }
end

function Parser:parse_table()
  self:_expect("{")
  local entries = {}
  while not self:_check("}") do
    if self:_check("[") then
      self:_advance()
      local k = self:parse_expr(0)
      self:_expect("]")
      self:_expect("=")
      entries[#entries + 1] = { kind = "keyed", key = k, val = self:parse_expr(0) }
    elseif self:_check("name") and self:_peek(1).type == "=" then
      local kn = self:_advance().value
      self:_expect("=")
      entries[#entries + 1] = { kind = "keyed", key = { type = "String", value = kn },
                                val = self:parse_expr(0) }
    else
      entries[#entries + 1] = { kind = "item", val = self:parse_expr(0) }
    end
    if not (self:_accept(",") or self:_accept(";")) then break end
  end
  self:_expect("}")
  return { type = "Table", entries = entries }
end

function Parser:parse_funcbody(is_method, namehint)
  self:_expect("(")
  local params, is_vararg = {}, false
  if is_method then params[1] = "self" end
  while not self:_check(")") do
    if self:_check("...") then self:_advance(); is_vararg = true; break end
    local pn = self:_expect("name").value
    if self:_accept(":") then self:_skip_type() end -- param type
    params[#params + 1] = pn
    if not self:_accept(",") then break end
  end
  self:_expect(")")
  if self:_accept(":") then self:_skip_type() end -- return type
  local body = self:parse_block()
  self:_expect("end")
  return { type = "Function", params = params, is_vararg = is_vararg,
           body = body, namehint = namehint }
end

function Parser:parse_suffix(prim)
  while true do
    local t = self.toks[self.i]
    if t.type == "." then
      self:_advance()
      local nm = self:_expect("name").value
      prim = { type = "Index", obj = prim, key = { type = "String", value = nm } }
    elseif t.type == "[" then
      self:_advance()
      local k = self:parse_expr(0)
      self:_expect("]")
      prim = { type = "Index", obj = prim, key = k }
    elseif t.type == ":" then
      self:_advance()
      local nm = self:_expect("name").value
      prim = { type = "Method", obj = prim, name = nm, args = self:parse_callargs() }
    elseif t.type == "(" then
      prim = { type = "Call", fn = prim, args = self:parse_callargs() }
    elseif t.type == "string" then
      prim = { type = "Call", fn = prim, args = { { type = "String", value = t.value } } }
      self:_advance()
    elseif t.type == "{" then
      prim = { type = "Call", fn = prim, args = { self:parse_table() } }
    else
      break
    end
  end
  return prim
end

function Parser:parse_callargs()
  self:_expect("(")
  local args = {}
  while not self:_check(")") do
    args[#args + 1] = self:parse_expr(0)
    if not self:_accept(",") then break end
  end
  self:_expect(")")
  return args
end

--------------------------------------------------------------------- statements
function Parser:parse_block()
  local stats = {}
  while true do
    local t = self.toks[self.i].type
    if t == "end" or t == "else" or t == "elseif" or t == "until" or t == "eof" then break end
    local s = self:parse_statement()
    if s then
      stats[#stats + 1] = s
      -- return must close block
      if s.type == "Return" then break end
    end
  end
  return stats
end

-- returns nil for statements fully consumed inline (labels etc.)
function Parser:parse_statement()
  local t = self.toks[self.i]

  if t.type == ";" then self:_advance(); return nil end
  if t.type == "::" then
    self:_advance()
    local nm = self:_expect("name").value
    self:_expect("::")
    return { type = "Label", name = nm }
  end
  if t.type == "goto" then
    self:_advance()
    return { type = "Goto", label = self:_expect("name").value }
  end
  if t.type == "break" then self:_advance(); return { type = "Break" } end
  if t.type == "continue" then self:_advance(); return { type = "Continue" } end
  if t.type == "do" then
    self:_advance()
    local b = self:parse_block()
    self:_expect("end")
    return { type = "Do", body = b }
  end
  if t.type == "while" then
    self:_advance()
    local cond = self:parse_expr(0)
    self:_expect("do")
    local b = self:parse_block()
    self:_expect("end")
    return { type = "While", cond = cond, body = b }
  end
  if t.type == "repeat" then
    self:_advance()
    local b = self:parse_block()
    self:_expect("until")
    return { type = "Repeat", body = b, cond = self:parse_expr(0) }
  end
  if t.type == "if" then
    self:_advance()
    local clauses = {}
    local cond = self:parse_expr(0)
    self:_expect("then")
    clauses[#clauses + 1] = { cond = cond, body = self:parse_block() }
    local orelse
    while true do
      if self:_accept("elseif") then
        local c2 = self:parse_expr(0)
        self:_expect("then")
        clauses[#clauses + 1] = { cond = c2, body = self:parse_block() }
      elseif self:_accept("else") then
        orelse = self:parse_block()
        self:_expect("end")
        break
      else
        self:_expect("end")
        break
      end
    end
    return { type = "If", clauses = clauses, orelse = orelse }
  end
  if t.type == "for" then
    self:_advance()
    local n1 = self:_expect("name").value
    if self:_accept(":") then self:_skip_type() end
    if self:_accept("=") then
      local st = self:parse_expr(0)
      self:_expect(",")
      local en = self:parse_expr(0)
      local step
      if self:_accept(",") then step = self:parse_expr(0) end
      self:_expect("do")
      local b = self:parse_block()
      self:_expect("end")
      return { type = "NumericFor", var = n1, start = st, stop = en, step = step, body = b }
    else
      local names = { n1 }
      while self:_accept(",") do
        local nn = self:_expect("name").value
        if self:_accept(":") then self:_skip_type() end
        names[#names + 1] = nn
      end
      self:_expect("in")
      local exprs = { self:parse_expr(0) }
      while self:_accept(",") do exprs[#exprs + 1] = self:parse_expr(0) end
      self:_expect("do")
      local b = self:parse_block()
      self:_expect("end")
      return { type = "GenericFor", vars = names, exprs = exprs, body = b }
    end
  end
  -- contextual Luau: `export type X = ...` / `type X = ...`
  if (t.type == "name" and t.value == "export" and self:_peek(1).type == "name"
      and self:_peek(1).value == "type" and self:_peek(2).type == "name") then
    self:_advance(); self:_advance(); self:_advance()
    if self:_accept("<") then
      local d = 1
      while d > 0 do
        local tk = self:_advance()
        if tk.type == "<" then d = d + 1 elseif tk.type == ">" then d = d - 1 end
      end
    end
    self:_expect("=")
    self:_skip_type()
    return nil
  end
  if (t.type == "name" and t.value == "type" and self:_peek(1).type == "name"
      and (self:_peek(2).type == "=" or self:_peek(2).type == "<")) then
    self:_advance()
    self:_advance()
    if self:_accept("<") then
      local d = 1
      while d > 0 do
        local tk = self:_advance()
        if tk.type == "<" then d = d + 1 elseif tk.type == ">" then d = d - 1 end
      end
    end
    self:_expect("=")
    self:_skip_type()
    return nil
  end
  -- contextual `continue`
  if t.type == "name" and t.value == "continue" then
    local nx = self:_peek(1).type
    if nx == "eof" or nx == "end" or nx == "else" or nx == "elseif" or nx == "until"
       or nx == ";" or nx == "local" or nx == "return" or nx == "if" or nx == "for"
       or nx == "while" or nx == "repeat" or nx == "do" or nx == "break"
       or (nx == "name") or (nx == "(" and false) then
      -- ambiguous only vs call `continue(...)`; treat statement-starters as continue
      self:_advance()
      return { type = "Continue" }
    end
  end
  if t.type == "function" then
    self:_advance()
    local first = self:_expect("name").value
    local path = { first }
    local is_method = false
    while self:_accept(".") do path[#path + 1] = self:_expect("name").value end
    if self:_accept(":") then path[#path + 1] = self:_expect("name").value; is_method = true end
    local fn = self:parse_funcbody(is_method, path[#path])
    return { type = "FunctionDecl", path = path, is_method = is_method, func = fn }
  end
  if t.type == "local" then
    self:_advance()
    if self:_accept("function") then
      local nm = self:_expect("name").value
      local fn = self:parse_funcbody(false, nm)
      return { type = "LocalFunction", name = nm, func = fn }
    end
    if self:_check("type") and self:_peek(1).type == "name" then
      -- local type Alias = <type>
      self:_advance()
      self:_advance()
      self:_expect("=")
      self:_skip_type()
      return nil
    end
    local names = { self:_expect("name").value }
    if self:_accept(":") then self:_skip_type() end -- Luau annotation
    while self:_accept(",") do
      names[#names + 1] = self:_expect("name").value
      if self:_accept(":") then self:_skip_type() end
    end
    local exprs = {}
    if self:_accept("=") then
      exprs[#exprs + 1] = self:parse_expr(0)
      while self:_accept(",") do exprs[#exprs + 1] = self:parse_expr(0) end
    end
    return { type = "Local", names = names, exprs = exprs }
  end
  if t.type == "return" then
    self:_advance()
    local exprs = {}
    local nx = self.toks[self.i]
    if not (nx.type == "eof" or nx.type == "end" or nx.type == "else"
            or nx.type == "elseif" or nx.type == "until" or nx.type == ";") then
      exprs[#exprs + 1] = self:parse_expr(0)
      while self:_accept(",") do exprs[#exprs + 1] = self:parse_expr(0) end
    end
    self:_accept(";")
    return { type = "Return", exprs = exprs }
  end
  if (t.type == "type") and self:_peek(1).type == "name" then
    -- export type X = ...   |   type X = ...
    if self:_peek(1).value == "export" or true then
      self:_advance() -- 'type'
      self:_advance() -- alias name
      if self:_accept("<") then -- generic params <T>
        local d = 1
        while d > 0 do
          local tk = self:_advance()
          if tk.type == "<" then d = d + 1 elseif tk.type == ">" then d = d - 1 end
        end
      end
      self:_expect("=")
      self:_skip_type()
      return nil
    end
  end

  -- expression-statement: assignment / call
  local e = self:parse_suffixedonly()
  local nt = self.toks[self.i]
  if nt.type == "=" or nt.type == "," then
    local targets = { e }
    while self:_accept(",") do targets[#targets + 1] = self:parse_suffixedonly() end
    self:_expect("=")
    local vals = { self:parse_expr(0) }
    while self:_accept(",") do vals[#vals + 1] = self:parse_expr(0) end
    for _, tg in ipairs(targets) do
      if not (tg.type == "Name" or tg.type == "Index") then self:_err("cannot assign to this expression") end
    end
    return { type = "Assign", targets = targets, exprs = vals }
  end
  if COMPOUND_OPS[nt.type] then
    if e.type ~= "Name" and e.type ~= "Index" then self:_err("bad compound assignment target") end
    self:_advance()
    local rhs = self:parse_expr(0)
    return { type = "CompoundAssign", target = e, op = COMPOUND_OPS[nt.type], expr = rhs }
  end
  if e.type == "Call" or e.type == "Method" then
    return { type = "ExprStat", expr = e }
  end
  self:_err("unexpected expression statement")
end

-- like parse_simple but restricted to suffixed names for assignment targets
function Parser:parse_suffixedonly()
  local t = self:_expect("name")
  local prim = { type = "Name", name = t.value }
  return self:parse_suffix(prim)
end

function Parser:parse_chunk()
  local body = self:parse_block()
  if self.toks[self.i].type ~= "eof" then self:_err("trailing tokens after chunk") end
  return { type = "Chunk", body = body }
end

return Parser
