-- lower.lua :: semantics-preserving lowering for portable output
local L = {}

local function collect_names(value, used, seen)
  if type(value) ~= "table" or seen[value] then return end
  seen[value] = true
  if value.type == "Name" then used[value.name] = true end
  if value.names then
    for _, name in ipairs(value.names) do used[name] = true end
  end
  if value.params then
    for _, name in ipairs(value.params) do used[name] = true end
  end
  if value.var then used[value.var] = true end
  if value.vars then
    for _, name in ipairs(value.vars) do used[name] = true end
  end
  if value.name and (value.type == "LocalFunction" or value.type == "Label") then
    used[value.name] = true
  end
  for _, child in pairs(value) do collect_names(child, used, seen) end
end

local function fresh(state)
  while true do
    state.next = state.next + 1
    local name = "__skx_lower_" .. state.next
    if not state.used[name] then
      state.used[name] = true
      return name
    end
  end
end

local lower_block

local function lower_function(func, state)
  func.body = lower_block(func.body, state)
end

local function lower_nested(statement, state)
  local kind = statement.type
  if kind == "Do" or kind == "While" or kind == "Repeat" or
     kind == "NumericFor" or kind == "GenericFor" then
    statement.body = lower_block(statement.body, state)
  elseif kind == "If" then
    for _, clause in ipairs(statement.clauses) do
      clause.body = lower_block(clause.body, state)
    end
    if statement.orelse then statement.orelse = lower_block(statement.orelse, state) end
  elseif kind == "LocalFunction" or kind == "FunctionDecl" then
    lower_function(statement.func, state)
  end
end

local function lower_compound(statement, state)
  local target = statement.target
  if target.type == "Name" then
    return {
      type = "Assign",
      targets = { target },
      exprs = { { type = "Binop", op = statement.op,
        l = { type = "Name", name = target.name }, r = statement.expr } },
    }
  end

  local object_name, key_name = fresh(state), fresh(state)
  local object_ref = { type = "Name", name = object_name }
  local key_ref = { type = "Name", name = key_name }
  local function indexed()
    return {
      type = "Index",
      obj = { type = "Name", name = object_name },
      key = { type = "Name", name = key_name },
    }
  end

  return {
    type = "Do",
    body = {
      { type = "Local", names = { object_name, key_name },
        exprs = { target.obj, target.key } },
      { type = "Assign", targets = { indexed() },
        exprs = { { type = "Binop", op = statement.op,
          l = indexed(), r = statement.expr } } },
    },
  }
end

lower_block = function(statements, state)
  local out = {}
  for _, statement in ipairs(statements) do
    lower_nested(statement, state)
    if statement.type == "CompoundAssign" then
      out[#out + 1] = lower_compound(statement, state)
    else
      out[#out + 1] = statement
    end
  end
  return out
end

function L.run(chunk)
  local used = {}
  collect_names(chunk, used, {})
  chunk.body = lower_block(chunk.body, { used = used, next = 0 })
  return chunk
end

return L
