-- strenc.lua :: string literal encryption (XOR + rolling key)
local bitutil = require("bitutil")
local S = {}

local function gen_marker(rng)
  return "_" .. tostring(rng.int(1000000, 999999999)) .. "x"
end

-- mirrors the runtime decoder exactly
local function encode(plain, key)
  local outbytes = {}
  local k = key
  for i = 1, #plain do
    local b = plain:byte(i)
    -- 8-bit xor
    local r, p, a, bb = 0, 1, b % 256, k % 256
    for _ = 1, 8 do
      local x, y = a % 2, bb % 2
      if x ~= y then r = r + p end
      a = (a - x) / 2; bb = (bb - y) / 2; p = p * 2
    end
    outbytes[#outbytes + 1] = string.char(r)
    k = (k * 1103515245 + 12345 + i * 7919) % 4294967296
  end
  return table.concat(outbytes)
end

-- API: S.run(chunk_ast, seed, opts) mutates AST; returns metadata
function S.run(chunk, seed, opts)
  opts = opts or {}
  local rng = bitutil.newrng((seed or os.time()) + 7777)
  local walkmod = require("astwalk")
  local count = 0
  local markers = {}
  local last_marker = nil
  walkmod.map_stmt_exprs(chunk.body, function(e)
    if e.type ~= "String" then return nil end
    local v = e.value
    if v == "" then return nil end
    local key = rng.int(11, 4294967295)
    if key == 0 then key = 0x5A5A5A5A end
    local cipher = encode(v, key)
    count = count + 1
    -- per-string marker to avoid single point failure (still reuse if many strings to limit header size)
    local D_MARKER
    if count % 3 == 1 or not last_marker then
      D_MARKER = gen_marker(rng)
      markers[#markers+1] = D_MARKER
      last_marker = D_MARKER
    else
      D_MARKER = last_marker
    end
    return {
      type = "Call",
      fn = { type = "Name", name = D_MARKER },
      args = { { type = "String", value = cipher }, { type = "Number", value = key } },
    }
  end, true)

  return { count = count, dmarker = markers[1], markers = markers }
end

-- runtime header source (multiple markers, same decoder)
function S.header(meta, bxname)
  local markers = meta.markers or {meta.dmarker}
  local parts = {}
  for _, d in ipairs(markers) do
    parts[#parts+1] = d .. "=function(s,k) local t={} for i=1,#s do local b=s:byte(i)" ..
      " local r,p,a,c=0,1,b,k%256 for j=1,8 do local x,y=a%2,c%2 if x~=y then r=r+p end " ..
      " a=(a-x)/2 c=(c-y)/2 p=p*2 end t[i]=string.char(r) k=(k*1103515245+12345+i*7919)%4294967296 end " ..
      " return table.concat(t) end"
  end
  return table.concat(parts, "\n")
end

return S
