-- cfflatten.lua :: strong control-flow flattening via shuffled state dispatcher (CFFv2)
local C = {}

local function has_top_sensitive(stats)
  for _, s in ipairs(stats) do
    local t = s.type
    if t == "Break" or t == "Continue" or t == "Goto" or t == "Label" then return true end
    if t == "Return" then return true end
  end
  return false
end

local function deep_has_continue(stats)
  local found = false
  local function w(blk)
    for _, s in ipairs(blk) do
      local t = s.type
      if t == "Continue" then found = true end
      if t == "While" then w(s.body)
      elseif t == "Repeat" then w(s.body)
      elseif t == "If" then
        for _, cl in ipairs(s.clauses) do w(cl.body) end
        if s.orelse then w(s.orelse) end
      elseif t == "NumericFor" or t == "GenericFor" then w(s.body)
      elseif t == "Do" then w(s.body)
      elseif t == "LocalFunction" then w(s.func.body)
      elseif t == "FunctionDecl" then w(s.func.body)
      end
    end
  end
  w(stats)
  return found
end

local function shuffle(t, rng)
  for i=#t,2,-1 do
    local j=rng.int(1,i)
    t[i],t[j]=t[j],t[i]
  end
  return t
end

local function flatten_block(stats, varname, rng)
  local n = #stats
  if n < 3 then return stats end
  if has_top_sensitive(stats) then return stats end
  if deep_has_continue(stats) then return stats end

  -- generate random states
  local states = {}
  local used = {}
  for i=1,n do
    local s
    repeat s=rng.int(1,1000000) until not used[s]
    used[s]=true
    states[i]=s
  end
  local sentinel = rng.int(1000000, 9000000)*2+1
  while used[sentinel] do sentinel=rng.int(1000000,9000000)*2+1 end

  -- build clauses with shuffled order
  local clauses = {}
  for i, s in ipairs(stats) do
    local cur = states[i]
    local nxt = (i < n) and states[i+1] or sentinel
    local body = { s }
    body[#body+1] = { type = "Assign",
                      targets = { { type = "Name", name = varname } },
                      exprs = { { type = "Number", value = nxt } } }
    clauses[#clauses+1] = {
      state = cur,
      cond = { type = "Binop", op = "==",
               l = { type = "Name", name = varname },
               r = { type = "Number", value = cur } },
      body = body,
    }
  end
  shuffle(clauses, rng)
  -- convert to If chain
  local if_clauses = {}
  for _, c in ipairs(clauses) do
    if_clauses[#if_clauses+1] = { cond = c.cond, body = c.body }
  end
  local dispatcher = {
    type = "Local", names = { varname }, exprs = { { type = "Number", value = states[1] } },
  }
  local loop = {
    type = "While",
    cond = { type = "Binop", op = "~=",
             l = { type = "Name", name = varname },
             r = { type = "Number", value = sentinel } },
    body = { { type = "If", clauses = if_clauses } },
  }
  return { dispatcher, loop }
end

-- API: C.run(chunk_ast, seed, opts) mutates
function C.run(chunk, seed, opts)
  opts = opts or {}
  if opts.mode == "vm" then return { flattened = 0, note = "superseded by vm" } end
  local bitutil = require("bitutil")
  local rng = bitutil.newrng((seed or os.time()) + 4242)
  local count = 0

  local function walk(stats)
    local varname = "_cf" .. tostring(math.floor(rng.int(10 ^ 5, 10 ^ 9))) .. "_" .. tostring(rng.int(10,99))
    local flat = flatten_block(stats, varname, rng)
    if #flat ~= #stats then count = count + 1 end
    local function rec(blk)
      for _, s in ipairs(blk) do
        local t = s.type
        if t == "While" then rec(s.body)
        elseif t == "Repeat" then rec(s.body)
        elseif t == "If" then
          for _, cl in ipairs(s.clauses) do rec(cl.body) end
          if s.orelse then rec(s.orelse) end
        elseif t == "NumericFor" or t == "GenericFor" then rec(s.body)
        elseif t == "Do" then rec(s.body)
        elseif t == "LocalFunction" then
          -- also flatten inner function bodies
          s.func.body = flatten_block(s.func.body, varname .. "_f" .. rng.int(1,999), rng)
          if #s.func.body ~= 1 then count = count + 1 end
          rec(s.func.body)
        elseif t == "FunctionDecl" then
          s.func.body = flatten_block(s.func.body, varname .. "_f" .. rng.int(1,999), rng)
          if #s.func.body ~= 1 then count = count + 1 end
          rec(s.func.body)
        end
      end
    end
    rec(flat)
    return flat
  end

  chunk.body = walk(chunk.body)
  return { flattened = count }
end

return C
