-- numenc.lua :: numeric literal -> arithmetic expression chains
local bitutil = require("bitutil")
local N = {}

local function is_int(n) if math.type then return math.type(n)=="integer" else return n==math.floor(n) and math.abs(n)<9007199254740992 end end
local function mkbin(op, l, r) return { type = "Binop", op = op, l = l, r = r } end
local function num(n) return { type = "Number", value = n } end

local function gen_marker(rng)
  return "_" .. tostring(rng.int(100000, 999999999)) .. tostring(rng.int(10, 99))
end

-- power-of-two identities are exact until overflow; cap magnitude conservatively
local IDENTITY_MAX = 2 ^ 250
local SAFE_INT = 2 ^ 31

-- per-run marker; F.piece reads this upvalue (assigned at run() entry)
local current_marker = "OBF_X9Z"

local F = {}

F.piece = function(n, rng, depth)
  if depth <= 0 then return num(n) end
  local roll = rng.int(1, 10)
  if is_int(n) then
    if roll <= 4 and math.abs(n) < SAFE_INT then return F.add_split(n, rng, depth) end
    if roll <= 7 then return F.sub_split(n, rng, depth) end
    if roll <= 9 and n ~= 0 and math.abs(n) < 2 ^ 31 then
      local mask = rng.int(1, 2147483647)
      local raw = bitutil.bxor(n % 4294967296, mask)
      if raw < 0 then raw = raw + 4294967296 end -- keep runtime math unsigned-safe
      return { type = "Call", fn = { type = "Name", name = current_marker },
               args = { num(raw), num(mask) } }
    end
    return mkbin("/", mkbin("*", num(n), num(65536)), num(65536))
  else
    if roll <= 3 and math.abs(n) < IDENTITY_MAX then
      -- exact power-of-two identity
      local k = rng.int(1,0xFFFF)* (2 ^ rng.int(0,12))
      return mkbin("/", mkbin("*", num(n), num(k)), num(k))
    elseif math.abs(n) < 2 ^ 900 then
      return F.float_exact(n, rng, depth, roll)
    else
      return mkbin("/", mkbin("*", num(n), num(1024)), num(1024))
    end
  end
end

-- Error-free floating split helper: pick a Veltkamp constant that cannot
-- overflow for this magnitude.
local function safe_cvt(n)
  -- pick a Veltkamp constant that cannot overflow for this magnitude:
  -- exponent of |n| plus log2(c) must stay below 1023 comfortably.
  local e = 0
  local a = math.abs(n)
  while a >= 1 do a = a / 2; e = e + 1 end
  while a > 0 and a < 0.5 do a = a * 2; e = e - 1 end
  local room = 1010 - e
  if room >= 28 then return 2 ^ 27 + 1
  elseif room >= 21 then return 2 ^ 20 + 1
  elseif room >= 14 then return 2 ^ 13 + 1
  else return nil end
end

F.float_exact = function(n, rng, depth, roll)
  local cvt = safe_cvt(n)
  if not cvt then
    local k = ({1024, 4096})[rng.int(1, 2)]
    return mkbin("/", mkbin("*", num(n), num(k)), num(k))
  end
  local x = n * cvt
  local hi = x - (x - n)      -- exact roundoff trick: hi has zeroed low half
  local lo = n - hi           -- Sterbenz-exact difference
  if lo == 0 then
    local k = rng.int(1,0xFFFF)* (2 ^ rng.int(0,12))
    return mkbin("/", mkbin("*", num(hi), num(k)), num(k))
  end
  if roll % 2 == 0 then
    return mkbin("+", F.piece(hi, rng, depth - 1), F.piece(lo, rng, depth - 1))
  else
    -- subtraction form: a - b where b encodes -lo (recombines via IEEE add)
    return mkbin("-", F.piece(hi, rng, depth - 1),
                     F.piece(-lo, rng, depth - 1))
  end
end

F.add_split = function(n, rng, depth)
  -- integer-only (floats route through the exact Veltkamp path)
  local lo = (n > 0) and 0 or n
  local hi = (n > 0) and n or 0
  local a = rng.int(lo, hi)
  return mkbin("+", F.piece(a, rng, depth - 1), F.piece(n - a, rng, depth - 1))
end

F.sub_split = function(n, rng, depth)
  -- keep both operands sign-consistent so XOR/round-trips stay exact
  local b
  if is_int(n) then
    if n >= 0 then b = rng.int(0, 1000000) else b = -rng.int(0, 1000000) end
  else
    -- float: encode via exact negation pair only (no fractional addends)
    return F.float_exact(n, rng, depth, rng.int(1, 10))
  end
  local a = n + b
  return mkbin("-", F.piece(a, rng, depth - 1), F.piece(b, rng, depth - 1))
end

-- API: N.run(chunk_ast, seed, opts) mutates AST; returns {needs_bxor=bool}
function N.run(chunk, seed, opts)
  opts = opts or {}
  local rng = bitutil.newrng(seed or os.time())
  current_marker = gen_marker(rng)
  local BXOR_MARKER = current_marker
  local walkmod = require("astwalk")
  local intensity = opts.intensity or "medium"
  local maxdepth = intensity == "light" and 1 or (intensity == "medium" and 2 or 3)

  walkmod.map_stmt_exprs(chunk.body, function(e)
    if e.type ~= "Number" then return nil end
    -- keep tiny structural numbers readable-safe? encode all
    return F.piece(e.value, rng, maxdepth)
  end, true)

  -- detect bxor marker usage anywhere
  local needs_bxor = false
  local function scan(e)
    if needs_bxor then return end
    if type(e) ~= "table" then return end
    if e.type == "Name" and e.name == BXOR_MARKER then needs_bxor = true end
    for _, v in pairs(e) do
      if type(v) == "table" then
        if v.type then scan(v) end
        for _, vv in ipairs(v) do
          if type(vv) == "table" and vv.type then scan(vv) end
        end
      end
    end
  end
  scan(chunk)
  return { needs_bxor = needs_bxor, bxor_marker = BXOR_MARKER }
end

return N
