-- deadcode.lua :: injects opaque-predicate-guarded junk blocks
local bitutil = require("bitutil")
local D = {}

local function num(n) return { type = "Number", value = n } end

-- opaque false families: 0: (2a+1)^2 %2==0, 1: (a*4+2)%4==0, 2: floor(a/3)*3 != a when a%3!=0
local function opaque_false(rng)
  local fam = rng.int(0,2)
  if fam == 0 then
    local a = rng.int(1000, 999999)
    return {
      type = "Binop", op = "==",
      l = { type = "Binop", op = "%",
            l = { type = "Binop", op = "*",
                  l = { type = "Number", value = 2 * a + 1 },
                  r = { type = "Number", value = 2 * a + 1 } },
            r = num(2) },
      r = num(0),
    }
  elseif fam == 1 then
    local a = rng.int(1000, 999999)
    -- (a*2+1) is odd => (a*2+1)%2==1, so ==0 is false; use (a*4+2)%4==0? (4a+2)%4==2 never 0
    return {
      type = "Binop", op = "==",
      l = { type = "Binop", op = "%",
            l = { type = "Binop", op = "+",
                  l = { type = "Binop", op = "*", l = num(a), r = num(4) },
                  r = num(2) },
            r = num(4) },
      r = num(0),
    }
  else
    local a = rng.int(10, 999999)
    a = a - (a % 3) + 1 -- ensure a%3==1
    return {
      type = "Binop", op = "==",
      l = { type = "Binop", op = "%", l = num(a), r = num(3) },
      r = num(0),
    }
  end
end

-- Multi-Layered Garbage: 3 layers of decoy
local JUNK_STRINGS_L1 = {
  "\1decoy_dump_bait\2", "\1env_logger_trap\3", "\1fake_payload_segment\4",
}
local JUNK_STRINGS_L2 = {
  "\2garbage_loop\2", "\2dead_code\3", "\2fake_branch\4", "\2junk_data\5",
}
local JUNK_STRINGS_L3 = {
  "\3vm_decoy\3", "\3control_flow\4", "\3opaque_pred\5", "\3bait_string\6",
}
local JUNK_STRINGS = JUNK_STRINGS_L1 -- fallback

-- API: D.run(chunk_ast, seed, opts)
function D.run(chunk, seed, opts)
  opts = opts or {}
  local rng = bitutil.newrng((seed or os.time()) + 31337)
  local count = rng.int(2, 5)

  for i = 1, count do
    local junkname = "_dc" .. tostring(math.floor(rng.int(10 ^ 6, 10 ^ 9)))
    local bait = {
      type = "Local",
      names = { junkname },
      exprs = {
        { type = "String", value = JUNK_STRINGS[rng.int(1, #JUNK_STRINGS)] },
      },
    }
    local branch = {
      type = "If",
      clauses = { { cond = opaque_false(rng), body = {
        { type = "ExprStat", expr =
          { type = "Call", fn = { type = "Name", name = junkname }, args = {} } },
      } } },
    }
    local pos = rng.int(1, math.max(1, #chunk.body))
    table.insert(chunk.body, pos, bait)
    table.insert(chunk.body, pos + 1, branch)
  end
  return { injected = count }
end

return D
