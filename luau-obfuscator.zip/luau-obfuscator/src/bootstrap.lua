-- bootstrap.lua :: sets package.path relative to this file's dir
local src_dir = ((debug and debug.getinfo and debug.getinfo(1).source or ""):match("@?(.*)/") or ".")
package.path = src_dir .. "/?.lua;" .. src_dir .. "/?/init.lua;" .. package.path
return src_dir
