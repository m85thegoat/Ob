-- astwalk.lua :: generic AST traversal helpers
local A = {}

-- iterate expression children of an expression node (no statement recursion)
local function sub_exprs(e, fn)
  local t = e.type
  if t == "Binop" then fn(e, "l", true); fn(e, "r", true)
  elseif t == "Unop" then fn(e, "e", true)
  elseif t == "Paren" then fn(e, "e", true)
  elseif t == "Index" then fn(e, "obj", true); fn(e, "key", true)
  elseif t == "Call" then
    fn(e, "fn", true)
    for i = 1, #e.args do fn(e, "args", i) end
  elseif t == "Method" then
    fn(e, "obj", true)
    for i = 1, #e.args do fn(e, "args", i) end
  elseif t == "Function" then
    -- body is statements; handled by stmt walkers
  elseif t == "Table" then
    for i = 1, #e.entries do
      local en = e.entries[i]
      if en.kind == "keyed" then fn(en, "key", true) end
      fn(en, "val", true)
    end
  end
end

-- apply fn(expr)->expr replacement over every expression slot reachable from
-- a statement list. Does NOT descend into Function bodies unless descend_fn.
-- visit(stmtlist) manages scoping for callers that need it.
function A.map_stmt_exprs(stats, fn, descend_fn)
  local function me(e)
    -- depth-first: transform children first
    local function child(container, key, idx)
      if idx then
        local v = container[key][idx]
        if type(v) == "table" and v.type then container[key][idx] = me(v) end
      else
        local v = container[key]
        if type(v) == "table" and v.type then container[key] = me(v) end
      end
    end
    if e.type == "Function" then
      if descend_fn then
        A.map_stmt_exprs(e.body, fn, descend_fn)
      end
      return fn(e) or e
    end
    sub_exprs(e, child)
    return fn(e) or e
  end
  for _, s in ipairs(stats) do A.stmt_walk(s, me, descend_fn) end
end

-- statement-level walker: calls me() on each contained expression
function A.stmt_walk(s, me, descend_fn)
  local t = s.type
  if t == "Local" then
    for i = 1, #s.exprs do s.exprs[i] = me(s.exprs[i]) end
  elseif t == "LocalFunction" then
    if descend_fn then A.map_stmt_exprs(s.func.body, me, descend_fn) end
  elseif t == "FunctionDecl" then
    if descend_fn then A.map_stmt_exprs(s.func.body, me, descend_fn) end
  elseif t == "Assign" then
    for i = 1, #s.targets do s.targets[i] = me(s.targets[i]) end
    for i = 1, #s.exprs do s.exprs[i] = me(s.exprs[i]) end
  elseif t == "CompoundAssign" then
    s.target = me(s.target)
    s.expr = me(s.expr)
  elseif t == "ExprStat" then
    s.expr = me(s.expr)
  elseif t == "Do" then
    A.map_stmt_exprs(s.body, me, descend_fn)
  elseif t == "While" then
    s.cond = me(s.cond)
    A.map_stmt_exprs(s.body, me, descend_fn)
  elseif t == "Repeat" then
    -- note: cond scoped with body in Lua; treat as plain expr here
    A.map_stmt_exprs(s.body, me, descend_fn)
    s.cond = me(s.cond)
  elseif t == "If" then
    for _, cl in ipairs(s.clauses) do
      cl.cond = me(cl.cond)
      A.map_stmt_exprs(cl.body, me, descend_fn)
    end
    if s.orelse then A.map_stmt_exprs(s.orelse, me, descend_fn) end
  elseif t == "NumericFor" then
    s.start = me(s.start); s.stop = me(s.stop)
    if s.step then s.step = me(s.step) end
    A.map_stmt_exprs(s.body, me, descend_fn)
  elseif t == "GenericFor" then
    for i = 1, #s.exprs do s.exprs[i] = me(s.exprs[i]) end
    A.map_stmt_exprs(s.body, me, descend_fn)
  elseif t == "Return" then
    for i = 1, #s.exprs do s.exprs[i] = me(s.exprs[i]) end
  end
end

return A
