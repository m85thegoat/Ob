-- protection.lua :: Anti-Tamper V1.1 runtime guard generation
local bitutil = require("bitutil")
local Integrity = require("integrity")

local P = {}
P.VERSION = "Anti-Tamper V1.1"

-- Executor/introspection entry points are fingerprinted at build time so the
-- emitted guard does not advertise a plaintext checklist to simple scanners.
local ENV_SIGNATURES = {
  "checkcaller", "cloneref", "decompile", "dumpstring", "fluxus", "krnl", "oxygen", "sentinel", "electron", "synapse", "wearedevs", "fluxteam", "delta", "codex", "trigon", "evon", "wave", "vegax", "arceus", "hydrogen",
  "getconnections", "getcallstack", "getstack", "getconstants", "getconstant", "getexecutorname", "getgc", "getgenv", "getgenv", "getinstances", "getloadedmodules", "getnilinstances", "getproto", "getprotos", "getrawmetatable", "getrenv", "getscripts", "getscriptbytecode", "getscriptclosure", "getsenv", "getupvalue", "getupvalues", "hookfunction", "hookmetamethod", "identifyexecutor", "iscclosure", "isexecutorclosure", "islclosure", "isreadonly", "newcclosure", "saveinstance", "setconstant", "setreadonly", "setupvalue", "syn", "gethui", "gethiddenproperty", "sethiddenproperty", "fireclickdetector", "firesignal", "getreg", "httplog", "rconsole", "setfpscap", "queue_on_teleport", "is_synapse_function", "is_executor_closure",

}

local function number_list(entries)
  local out = {}
  for index, entry in ipairs(entries) do
    out[index] = ("{%d,%.0f,%.0f}"):format(entry[1], entry[2], entry[3])
  end
  return table.concat(out, ",")
end

local function profile_tokens(seed, env_digest, strict)
  local a = Integrity.hash("SKX/AT11/A",
    Integrity.hash_number(seed, 2166136261), false)
  for _, value in ipairs({ 83, 75, 88, 11, 42, 255, 2, 19 }) do
    a = Integrity.hash_number(value, a)
  end
  a = Integrity.hash_number(env_digest, a)
  a = Integrity.hash_number(strict and 1 or 0, a)

  local b = Integrity.hash("SKX/AT11/B",
    Integrity.hash_number(a, 2246822519), true)
  for _, value in ipairs({ 3, 17, 64, 127, 1024, 65535 }) do
    b = Integrity.hash_number(value, b)
  end

  local c = Integrity.hash_number(env_digest,
    Integrity.hash_number(b,
      Integrity.hash_number(a, 3266489917)))
  return a, b, c
end

function P.create(seed, opts)
  seed = math.floor(tonumber(seed) or 0) % 4294967296
  local strict = opts and opts.strict == true or false
  local scan_seed_a = Integrity.hash("SKX/AT11/ENV/A",
    Integrity.hash_number(seed, 374761393), false)
  local scan_seed_b = Integrity.hash("SKX/AT11/ENV/B",
    Integrity.hash_number(seed, 668265263), true)

  local entries = {}
  for index, name in ipairs(ENV_SIGNATURES) do
    entries[index] = {
      #name,
      Integrity.hash(name, scan_seed_a, false),
      Integrity.hash(name, scan_seed_b, true),
    }
  end

  local env_digest = Integrity.hash("SKX/AT11/ENV/M",
    Integrity.hash_number(seed, 2166136261), false)
  for _, entry in ipairs(entries) do
    env_digest = Integrity.hash_number(entry[1], env_digest)
    env_digest = Integrity.hash_number(entry[2], env_digest)
    env_digest = Integrity.hash_number(entry[3], env_digest)
  end

  local token_a, token_b, token_c = profile_tokens(seed, env_digest, strict)
  return {
    version = P.VERSION,
    seed = seed,
    strict = strict,
    scan_seed_a = scan_seed_a,
    scan_seed_b = scan_seed_b,
    entries = entries,
    env_digest = env_digest,
    token_a = token_a,
    token_b = token_b,
    token_c = token_c,
  }
end

-- Emits the common fail-closed runtime and pins every primitive used by the
-- decoders. The named fail function and guard symbols are consumed by both
-- source and VM output.
function P.runtime(profile, fail_name, message)
  fail_name = fail_name or "__skx_fail"
  message = message or "protection failure"
  -- obfuscate mockery string: per-build XOR-ish encoding to avoid plaintext & byte signatures
  local function obfuscate_msg(s, seed)
    seed = seed or 0
    local key = (seed % 200) + 13 -- 13..212, per-build
    local enc = {}
    for i = 1, #s do enc[i] = tostring((s:byte(i) + key) % 256) end
    -- split encoded bytes into chunks for table
    local parts = {}
    for i = 1, #enc, 16 do
      local slice = {}
      for j = i, math.min(i+15, #enc) do slice[#slice+1] = enc[j] end
      parts[#parts+1] = table.concat(slice, ",")
    end
    local enc_table = "{" .. table.concat(parts, ",") .. "}"
    return "local __skx_msg_key=" .. key .. "\nlocal __skx_msg_enc=" .. enc_table ..
           "\nlocal __skx_message=(function() local t={} for i=1,#__skx_msg_enc do t[i]=string.char((__skx_msg_enc[i]-__skx_msg_key)%256) end return table.concat(t) end)()"
  end
  local lines = {
    -- watermark comment removed (no --)
    obfuscate_msg(message, profile.seed),
    "local __skx_guard_seed=" .. string.format("%.0f", profile.seed),
    "local __skx_scan_a=" .. string.format("%.0f", profile.scan_seed_a),
    "local __skx_scan_b=" .. string.format("%.0f", profile.scan_seed_b),
    "local __skx_env_digest=" .. string.format("%.0f", profile.env_digest),
    "local __skx_env_signatures={" .. number_list(profile.entries) .. "}",
    [==[
local __skx_type0=type
local __skx_pcall0=pcall
local __skx_error0=error
local __skx_print0=print
local __skx_rawget0=rawget
local __skx_next0=next
local __skx_pairs0=pairs
local __skx_ipairs0=ipairs
local __skx_select0=select
local __skx_tostring0=tostring
local __skx_tonumber0=tonumber
local __skx_rawequal0=rawequal
local __skx_getmetatable0=getmetatable
local __skx_setmetatable0=setmetatable
local __skx_getfenv0=getfenv
local __skx_string0=string
local __skx_math0=math
local __skx_table0=table
local __skx_byte0=__skx_string0 and __skx_string0.byte
local __skx_char0=__skx_string0 and __skx_string0.char
local __skx_sub0=__skx_string0 and __skx_string0.sub
local __skx_gmatch0=__skx_string0 and __skx_string0.gmatch
local __skx_format0=__skx_string0 and __skx_string0.format
local __skx_concat0=__skx_table0 and __skx_table0.concat
local __skx_unpack0=(unpack or (__skx_table0 and __skx_table0.unpack))
local __skx_floor0=__skx_math0 and __skx_math0.floor
local __skx_ceil0=__skx_math0 and __skx_math0.ceil
local __skx_max0=__skx_math0 and __skx_math0.max
local __skx_tointeger0=__skx_math0 and __skx_math0.tointeger
local __skx_load0=load
local __skx_loadstring0=loadstring
local __skx_debug0=debug
local __skx_gethook0=__skx_debug0 and __skx_debug0.gethook
local __skx_getinfo0=__skx_debug0 and __skx_debug0.getinfo
-- P2 fix: restore original getfenv before env determination to avoid _fake_env pollution
do
  local _reg0 = __skx_debug0 and __skx_debug0.getregistry and __skx_debug0.getregistry()
  if _reg0 then
    local orig = rawget(_reg0, "__skx_leaker_orig_getfenv")
    if __skx_type0(orig)=="function" then __skx_getfenv0 = orig end
    local dbg0 = rawget(_reg0, "__skx_leaker_orig_debug")
    if __skx_type0(dbg0)=="table" then __skx_debug0 = dbg0 end
  end
end
local __skx_env
if __skx_type0(__skx_getfenv0)=="function" then
  local ok,value=__skx_pcall0(__skx_getfenv0,0)
  if ok and __skx_type0(value)=="table" then
    -- if value is _fake_env (has _G = {}), use real _G
    if rawget(value,"_G") and __skx_type0(rawget(value,"_G"))=="table" and next(value)==nil then
      -- _fake_env is empty except _G, use real _G
      __skx_env=_G
    else
      __skx_env=value
    end
  end
end
if __skx_type0(__skx_env)~="table" and __skx_type0(_ENV)=="table" then
  __skx_env=_ENV
end
if __skx_type0(__skx_env)~="table" then __skx_env=_G end
-- fallback: if _G is available and __skx_env is _fake_env, use _G
if __skx_env~=nil and __skx_env~= _G and rawget(_G,"__SKX_LEAKER_GUARD_ACTIVE") then
  if __skx_type0(rawget(__skx_env,"_G"))=="table" then __skx_env=_G end
end
-- ── Anti Leaker: 9-0-9-9/env-leakers-leak (11 vectors) ──
do
  rawset(_G, "__SKX_LEAKER_GUARD_ACTIVE", true)
  -- For repeated loads in same state (tests), retrieve originals from registry if already wrapped
  local _reg = debug and debug.getregistry and debug.getregistry()
  if _reg and rawget(_reg, "__skx_leaker_orig_getfenv") and __skx_type0(rawget(_reg, "__skx_leaker_orig_getfenv"))=="function" then
    __skx_getfenv0 = rawget(_reg, "__skx_leaker_orig_getfenv")
  end
  -- Capture originals via pinned aliases before leaker can hook
  -- For repeated loads (tests), restore originals from registry if already wrapped
  if _reg then
    local function _restore(key, cur)
      local orig = rawget(_reg, "__skx_leaker_orig_"..key)
      if orig and __skx_type0(orig)=="function" and cur ~= orig then
        -- if current is already wrapped (Lua func), restore original for capture
        local ok,info=__skx_pcall0(__skx_getinfo0 or debug.getinfo, cur, "S")
        if ok and info and info.what=="Lua" then return orig end
      end
      return cur
    end
    -- stash current as original if not yet stashed (hidden key per-build)
    local _hid1 = "__skx_hid_" .. tostring(__skx_guard_seed % 1000000) .. "_getfenv"
    local _hid2 = "__skx_hid_" .. tostring((__skx_guard_seed+1) % 1000000) .. "_debug"
    if __skx_type0(__skx_getfenv0)=="function" and not rawget(_reg, _hid1) then
      rawset(_reg, _hid1, __skx_getfenv0)
      rawset(_reg, "__skx_leaker_orig_getfenv", __skx_getfenv0)
    end
    if __skx_debug0 and not rawget(_reg, _hid2) then
      rawset(_reg, _hid2, __skx_debug0)
      rawset(_reg, "__skx_leaker_orig_debug", __skx_debug0)
    end
  end
  local _gf = __skx_getfenv0
  if _reg and rawget(_reg, "__skx_leaker_orig_getfenv") then
    local orig = rawget(_reg, "__skx_leaker_orig_getfenv")
    if __skx_type0(orig)=="function" then _gf = orig end
  end
  local _dbg = __skx_debug0
  if _reg and rawget(_reg, "__skx_leaker_orig_debug") then
    local orig_dbg = rawget(_reg, "__skx_leaker_orig_debug")
    if type(orig_dbg)=="table" then _dbg = orig_dbg end
  end
  local _gup = _dbg and rawget(_dbg, "getupvalue")
  local _ginfo = _dbg and rawget(_dbg, "getinfo")
  local _greg = _dbg and rawget(_dbg, "getregistry")
  local _sdump = rawget(__skx_string0 or {}, "dump")
  local _io = rawget(__skx_env, "io")
  local _os = rawget(__skx_env, "os")
  local _gh = rawget(__skx_env, "gethostenv") or rawget(_G, "gethostenv")
  -- stash originals for next load
  if _reg then
    if __skx_type0(_gup)=="function" and not rawget(_reg, "__skx_leaker_orig_getupvalue") then rawset(_reg, "__skx_leaker_orig_getupvalue", _gup) end
    if __skx_type0(_ginfo)=="function" and not rawget(_reg, "__skx_leaker_orig_getinfo") then rawset(_reg, "__skx_leaker_orig_getinfo", _ginfo) end
  end
  -- Fake env without _G/io for getfenv(print) and getfenv(0)
  local _fake_env = { _G = {}, io = nil, os = nil, debug = nil, string = {dump=nil} }
  setmetatable(_fake_env, {__index=function(_,k) return nil end})
  if __skx_type0(_gf)=="function" then
    local _orig_gf = _gf
    local function _wrapped_gf(a)
      -- leaker pattern: getfenv(print) or getfenv(0) or getfenv(1)
      if a==__skx_print0 or a==0 or a==1 then
        return _fake_env
      end
      local ok,res=__skx_pcall0(_orig_gf, a)
      if ok and type(res)=="table" and rawget(res,"_G") then
        return _fake_env
      end
      return ok and res or nil
    end
    -- replace both global and captured alias
    rawset(__skx_env, "getfenv", _wrapped_gf)
    if _G then rawset(_G, "getfenv", _wrapped_gf) end
    __skx_getfenv0 = _wrapped_gf
  end
  -- Hide real_G from debug.getupvalue(print)
  if __skx_type0(_gup)=="function" and __skx_type0(__skx_print0)=="function" then
    local _orig_gup = _gup
    local function _wrapped_gup(f, idx)
      local n,v = _orig_gup(f, idx)
      if type(v)=="table" and rawget(v,"_G") then return nil,nil end
      if type(v)=="string" and #v>30 then return n, nil end
      return n,v
    end
    rawset(_dbg, "getupvalue", _wrapped_gup)
    _gup = _wrapped_gup
  end
  -- Sanitize debug.getinfo source to hide file paths
  if __skx_type0(_ginfo)=="function" then
    local _orig_ginfo = _ginfo
    local function _wrapped_ginfo(a,b)
      local ok,info=__skx_pcall0(_orig_ginfo, a,b)
      if ok and type(info)=="table" and type(info.source)=="string" and info.source:sub(1,1)=="@" then
        info.source="=(skynox)"
        info.linedefined=0
        info.currentline=0
      end
      return ok and info or _orig_ginfo(a,b)
    end
    rawset(_dbg, "getinfo", _wrapped_ginfo)
    -- also replace pcall-wrapped version used by leaker's xpcall loop
    _ginfo = _wrapped_ginfo
  end
  -- Block string.dump exfiltration
  if __skx_type0(_sdump)=="function" then
    rawset(__skx_string0, "dump", function() return nil end)
  end
  -- Block io.open for the hardcoded leaker bases/names
  if type(_io)=="table" and __skx_type0(rawget(_io,"open"))=="function" then
    local _orig_open = rawget(_io,"open")
    local function _wrapped_open(path, mode)
      if type(path)=="string" then
        local lp=path:lower()
        if lp:find("dumper",1,true) or lp:find("c:\\users",1,true) or lp:find("timothy",1,true) or lp:find("%.lua",1,true) then
          return nil, "blocked"
        end
      end
      return _orig_open(path, mode)
    end
    rawset(_io, "open", _wrapped_open)
  end
  -- Block debug.getregistry scanning
  if __skx_type0(_greg)=="function" then
    rawset(_dbg, "getregistry", function() return {} end)
  end
  -- Block Lune host access
  if __skx_type0(_gh)=="function" then
    rawset(__skx_env, "gethostenv", function() return nil end)
    if _G then rawset(_G, "gethostenv", function() return nil end) end
  end
  -- Block os.execute('dir ...') traversal (10.lua)
  if type(_os)=="table" and __skx_type0(rawget(_os,"execute"))=="function" then
    local _orig_exec = rawget(_os,"execute")
    rawset(_os, "execute", function(cmd)
      if type(cmd)=="string" and (cmd:find("dir",1,true) or cmd:find("llllllll",1,true)) then return nil end
      return _orig_exec(cmd)
    end)
  end
end
local __skx_failed=false
local __skx_fake_loaded=false
local function __skx_try_fake()
  if __skx_fake_loaded then return end
  __skx_fake_loaded=true
  local ok, fake_src = __skx_pcall0(function()
    if __skx_type0(__SKX_FAKE)=="string" and __skx_type0(__SKX_FAKE_KEY)=="number" then
      local v=__SKX_FAKE_KEY%4294967296
      if v==0 then v=222222229 end
      local out={}
      -- local xor helpers (self-contained, no outer dependency)
      local function _xor32(a,b) local r,p=0,1 a=a%4294967296 b=b%4294967296 for i=1,32 do local u,w=a%2,b%2 if u~=w then r=r+p end a=(a-u)/2 b=(b-w)/2 p=p*2 end return r end
      local function _lshift(a,n) n=n%32 if n==0 then return a%4294967296 end return (a%4294967296)*(2^n)%4294967296 end
      local function _rshift(a,n) n=n%32 if n==0 then return a%4294967296 end return math.floor((a%4294967296)/(2^n)) end
      for i=1,#__SKX_FAKE do
        v=_xor32(v,_lshift(v,13))%4294967296
        v=_xor32(v,_rshift(v,17))%4294967296
        v=_xor32(v,_lshift(v,5))%4294967296
        local a,b=__SKX_FAKE:byte(i), v%256
        local r,p=0,1
        for _=1,8 do local x,y=a%2,b%2 if x~=y then r=r+p end a=(a-x)/2 b=(b-y)/2 p=p*2 end
        out[i]=string.char(r)
      end
      return table.concat(out)
    end
  end)
  if ok and __skx_type0(fake_src)=="string" and #fake_src>0 then
    local lf=load or loadstring
    if __skx_type0(lf)=="function" then
      local ok2, fn = __skx_pcall0(lf, fake_src, "=decoy")
      if ok2 and __skx_type0(fn)=="function" then __skx_pcall0(fn) end
    end
  end
end
local function __SKX_FAIL_PLACEHOLDER__()
  if __skx_failed then
    __skx_try_fake()
    if __skx_type0(__skx_error0)=="function" then
      return __skx_error0(__skx_message or "integrity failure",2)
    end
    local impossible=nil
    return impossible[1]
  end
  __skx_failed=true
  if __skx_type0(__skx_print0)=="function" and
     __skx_type0(__skx_pcall0)=="function" then
    __skx_pcall0(__skx_print0,__skx_message)
  end
  __skx_try_fake()
  if __skx_type0(__skx_error0)=="function" then
    return __skx_error0(__skx_message or "integrity failure",2)
  end
  local impossible=nil
  return impossible[1]
end
local function __skx_xor8_guard(a,b)
  local r,p=0,1
  a,b=a%256,b%256
  for _=1,8 do
    local x,y=a%2,b%2
    if x~=y then r=r+p end
    a=(a-x)/2 b=(b-y)/2 p=p*2
  end
  return r
end
local function __skx_hb_guard(h,b)
  local low=h%256
  h=h-low+__skx_xor8_guard(low,b)
  return ((h%256)*16777216+h*403)%4294967296
end
local function __skx_hn_guard(n,h)
  n=__skx_floor0(n)%4294967296
  for _=1,4 do
    local b=n%256
    h=__skx_hb_guard(h,b)
    n=(n-b)/256
  end
  return h
end
local function __skx_hs_guard(s,h,rev)
  if rev then
    for i=#s,1,-1 do h=__skx_hb_guard(h,__skx_byte0(s,i)) end
  else
    for i=1,#s do h=__skx_hb_guard(h,__skx_byte0(s,i)) end
  end
  return h
end
local function __skx_primitives_ok(check_globals)
  if __skx_type0(__skx_env)~="table" or
     __skx_type0(__skx_type0)~="function" or
     __skx_type0(__skx_pcall0)~="function" or
     __skx_type0(__skx_error0)~="function" or
     __skx_type0(__skx_rawget0)~="function" or
     __skx_type0(__skx_next0)~="function" or
     __skx_type0(__skx_pairs0)~="function" or
     __skx_type0(__skx_ipairs0)~="function" or
     __skx_type0(__skx_select0)~="function" or
     __skx_type0(__skx_tostring0)~="function" or
     __skx_type0(__skx_tonumber0)~="function" or
     __skx_type0(__skx_rawequal0)~="function" or
     __skx_type0(__skx_getmetatable0)~="function" or
     __skx_type0(__skx_setmetatable0)~="function" or
     __skx_type0(__skx_byte0)~="function" or
     __skx_type0(__skx_char0)~="function" or
     __skx_type0(__skx_sub0)~="function" or
     __skx_type0(__skx_gmatch0)~="function" or
     __skx_type0(__skx_concat0)~="function" or
     __skx_type0(__skx_floor0)~="function" or
     __skx_type0(__skx_ceil0)~="function" or
     __skx_type0(__skx_max0)~="function" or
     __skx_type0(__skx_unpack0)~="function" then return false end
  if check_globals then
    -- If leaker guard already wrapped getfenv etc., don't flag its wrappers as tampering
    local _leaker_active = rawget(_G, "__SKX_LEAKER_GUARD_ACTIVE")
    local globals={{"type",__skx_type0},{"pcall",__skx_pcall0},
      {"error",__skx_error0},{"rawget",__skx_rawget0},{"next",__skx_next0},
      {"pairs",__skx_pairs0},{"ipairs",__skx_ipairs0},
      {"select",__skx_select0},{"tostring",__skx_tostring0},
      {"tonumber",__skx_tonumber0},{"rawequal",__skx_rawequal0},
      {"getmetatable",__skx_getmetatable0},{"setmetatable",__skx_setmetatable0},
      {"string",__skx_string0},{"math",__skx_math0},{"table",__skx_table0}}
    for i=1,#globals do
      local current=__skx_rawget0(__skx_env,globals[i][1])
      if current~=nil and current~=globals[i][2] then
        -- allow leaker guard's wrappers (they set this flag) - string/io/os/debug are tainted by leaker guard
        if _leaker_active and (globals[i][1]=="getfenv" or globals[i][1]=="debug" or globals[i][1]=="string" or globals[i][1]=="io" or globals[i][1]=="os") then
          -- skip: leaker guard legitimately wraps these
        else
          return false
        end
      end
    end
    local current_load=__skx_rawget0(__skx_env,"load")
    if current_load~=nil and current_load~=__skx_load0 then return false end
    local current_loadstring=__skx_rawget0(__skx_env,"loadstring")
    if current_loadstring~=nil and current_loadstring~=__skx_loadstring0 then
      return false
    end
  end
  if __skx_rawget0(__skx_string0,"byte")~=__skx_byte0 or
     __skx_rawget0(__skx_string0,"char")~=__skx_char0 or
     __skx_rawget0(__skx_string0,"sub")~=__skx_sub0 or
     __skx_rawget0(__skx_string0,"gmatch")~=__skx_gmatch0 or
     __skx_rawget0(__skx_table0,"concat")~=__skx_concat0 or
     __skx_rawget0(__skx_math0,"floor")~=__skx_floor0 or
     __skx_rawget0(__skx_math0,"ceil")~=__skx_ceil0 or
     __skx_rawget0(__skx_math0,"max")~=__skx_max0 then return false end
  return true
end
local function __skx_debug_hooked()
  if __skx_debug0~=nil then
    local current=__skx_rawget0(__skx_env,"debug")
    if current~=nil and current~=__skx_debug0 then return true end
  end
  if __skx_type0(__skx_gethook0)~="function" then return false end
  if __skx_rawget0(__skx_debug0,"gethook")~=__skx_gethook0 then return true end
  local ok,hook=__skx_pcall0(__skx_gethook0)
  return not ok or hook~=nil
end
]==],
  }

  if profile.strict then
    lines[#lines + 1] = [==[
local function __skx_native_primitives_ok()
  local version=__skx_rawget0(__skx_env,"_VERSION")
  if __skx_type0(version)~="string" or __skx_sub0(version,1,6)~="Lua 5." then
    return true
  end
  if __skx_type0(__skx_getinfo0)~="function" then return true end
  local funcs={__skx_type0,__skx_pcall0,__skx_error0,__skx_rawget0,
    __skx_next0,__skx_select0,__skx_byte0,__skx_char0,__skx_sub0,
    __skx_concat0,__skx_floor0,__skx_load0,__skx_loadstring0}
  for i=1,#funcs do
    if funcs[i]~=nil then
      local ok,info=__skx_pcall0(__skx_getinfo0,funcs[i],"S")
      if not ok or __skx_type0(info)~="table" or info.what~="C" then
        return false
      end
    end
  end
  return true
end
local function __skx_environment_clean()
  for key in __skx_next0,__skx_env do
    if __skx_type0(key)=="string" then
      local n=#key
      local a=__skx_hs_guard(key,__skx_scan_a,false)
      local b=__skx_hs_guard(key,__skx_scan_b,true)
      for i=1,#__skx_env_signatures do
        local sig=__skx_env_signatures[i]
        if n==sig[1] and a==sig[2] and b==sig[3] then return false end
      end
    end
  end
  return true
end
]==]
  else
    lines[#lines + 1] = [==[
local function __skx_native_primitives_ok() return true end
local function __skx_environment_clean() return true end
]==]
  end

  lines[#lines + 1] = [==[
local function __skx_guard_tokens()
  if not __skx_primitives_ok(true) then __SKX_FAIL_PLACEHOLDER__() end
  if __skx_sub0("SKX/1.1",2,6)~="KX/1." or
     __skx_byte0("SKX",1)~=83 or __skx_byte0("SKX",3)~=88 or
     __skx_char0(83,75,88)~="SKX" or
     __skx_concat0({"S","K","X"})~="SKX" or
     __skx_floor0(2.9)~=2 or __skx_floor0(-2.1)~=-3 or
     __skx_ceil0(2.1)~=3 or __skx_max0(3,9,4)~=9 or
     __skx_select0("#",nil,1)~=2 or __skx_tonumber0("19")~=19 or
     -7%2~=1 or 2^10~=1024 or not ((0/0)~=(0/0)) then
    __SKX_FAIL_PLACEHOLDER__()
  end
  local probe={x=17}
  if __skx_rawget0(probe,"x")~=17 then __SKX_FAIL_PLACEHOLDER__() end
  local meta={__index=function(_,key) if key=="v" then return 23 end end}
  local object=__skx_setmetatable0({},meta)
  if object.v~=23 or __skx_getmetatable0(object)~=meta or
     not __skx_rawequal0(object,object) then __SKX_FAIL_PLACEHOLDER__() end
   local ok,value=__skx_pcall0(function() return 6*7 end)
   if not ok or value~=42 then __SKX_FAIL_PLACEHOLDER__() end
   local failed=__skx_pcall0(function() __skx_error0("",0) end)
   if failed then __SKX_FAIL_PLACEHOLDER__() end
   -- anti env logger: httplog/sandbox hook trap (strings obfuscated)
   do
     local _, s = __skx_pcall0(function(...) __skx_byte0("a", function(...) return; end, 9999, 38); end)
     if s and (s:find(__skx_char0(104,116,116,112,108,111,103)) or s:find(__skx_char0(115,97,110,100,98,111,120))) then while true do end end
   end
   local env_hash=__skx_hs_guard("SKX/AT11/ENV/M",
    __skx_hn_guard(__skx_guard_seed,2166136261),false)
  for i=1,#__skx_env_signatures do
    local sig=__skx_env_signatures[i]
    env_hash=__skx_hn_guard(sig[1],env_hash)
    env_hash=__skx_hn_guard(sig[2],env_hash)
    env_hash=__skx_hn_guard(sig[3],env_hash)
  end
  if env_hash~=__skx_env_digest or not __skx_native_primitives_ok() or
     not __skx_environment_clean() or __skx_debug_hooked() then
    __SKX_FAIL_PLACEHOLDER__()
  end
  local a=__skx_hs_guard("SKX/AT11/A",
    __skx_hn_guard(__skx_guard_seed,2166136261),false)
  local av={83,75,88,11,42,255,2,19}
  for i=1,#av do a=__skx_hn_guard(av[i],a) end
  a=__skx_hn_guard(env_hash,a)
  a=__skx_hn_guard(__SKX_STRICT_PLACEHOLDER__,a)
  local b=__skx_hs_guard("SKX/AT11/B",__skx_hn_guard(a,2246822519),true)
  local bv={3,17,64,127,1024,65535}
  for i=1,#bv do b=__skx_hn_guard(bv[i],b) end
  local c=__skx_hn_guard(env_hash,
    __skx_hn_guard(b,__skx_hn_guard(a,3266489917)))
  return a,b,c
end
local __SKX_GUARD_A,__SKX_GUARD_B,__SKX_GUARD_C=__skx_guard_tokens()
local __skx_guard_ticks=0
local function __skx_guard(force)
  __skx_guard_ticks=__skx_guard_ticks+1
  if force or __skx_guard_ticks%97==0 then
    if not __skx_primitives_ok(false) or __skx_debug_hooked() then
      __SKX_FAIL_PLACEHOLDER__()
    end
    local a,b,c=__skx_guard_tokens()
    if a~=__SKX_GUARD_A or b~=__SKX_GUARD_B or c~=__SKX_GUARD_C then
      __SKX_FAIL_PLACEHOLDER__()
    end
  end
end

-- All decoder/interpreter references below resolve to these captured values.
local type=__skx_type0
local pcall=__skx_pcall0
local error=__skx_error0
local rawget=__skx_rawget0
local next=__skx_next0
local pairs=__skx_pairs0
local ipairs=__skx_ipairs0
local select=__skx_select0
local tostring=__skx_tostring0
local tonumber=__skx_tonumber0
local rawequal=__skx_rawequal0
local getmetatable=__skx_getmetatable0
local setmetatable=__skx_setmetatable0
local print=__skx_print0
local unpack=__skx_unpack0
local load=__skx_load0
local loadstring=__skx_loadstring0
local string={byte=__skx_byte0,char=__skx_char0,sub=__skx_sub0,
  gmatch=__skx_gmatch0,format=__skx_format0}
local math={floor=__skx_floor0,ceil=__skx_ceil0,max=__skx_max0,
  tointeger=__skx_tointeger0}
local table={concat=__skx_concat0,unpack=__skx_unpack0}
]==]

  local output = table.concat(lines, "\n")
  output = output:gsub("__SKX_FAIL_PLACEHOLDER__", fail_name)
  output = output:gsub("__SKX_STRICT_PLACEHOLDER__", profile.strict and "1" or "0")
  return output
end

function P.mix(value, token)
  return bitutil.bxor(value % 4294967296, token % 4294967296) % 4294967296
end

return P
