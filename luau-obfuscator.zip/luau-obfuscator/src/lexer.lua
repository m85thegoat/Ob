-- lexer.lua :: Lua 5.4 / Luau tokenizer
local Lexer = {}
Lexer.__index = Lexer

local KEYWORDS = {
  ["and"]=true,["break"]=true,["do"]=true,["else"]=true,["elseif"]=true,["end"]=true,
  ["false"]=true,["for"]=true,["function"]=true,["if"]=true,["in"]=true,["local"]=true,
  ["nil"]=true,["not"]=true,["or"]=true,["repeat"]=true,["return"]=true,["then"]=true,
  ["true"]=true,["until"]=true,["while"]=true,
  -- Lua 5.4 / Luau extensions we accept
  ["goto"]=true,
}

local COMPOUND = {
  ["+="]="+",["-="]="-",["*="]="*",["/="]="/",["//="]="//",["%="]="%",["^="]="^",["..="]="..",
}

local function is_digit(c) return c >= "0" and c <= "9" end
local function is_hexdigit(c) return is_digit(c) or (c >= "a" and c <= "f") or (c >= "A" and c <= "F") end
local function is_alpha(c) return (c >= "a" and c <= "z") or (c >= "A" and c <= "Z") or c == "_" end
local function is_alnum(c) return is_alpha(c) or is_digit(c) end

function Lexer.new(src)
  return setmetatable({ src = src, pos = 1, line = 1, toks = {}, i = 0 }, Lexer)
end

function Lexer:_errc(msg)
  error(string.format("lex error @ line %d: %s", self.line, msg), 0)
end

function Lexer:peekc(o) o = o or 0; return self.src:sub(self.pos + o, self.pos + o) end

function Lexer:nextc()
  local c = self.src:sub(self.pos, self.pos)
  if c == "" then return nil end
  if c == "\n" then self.line = self.line + 1 end
  self.pos = self.pos + 1
  return c
end

function Lexer:emit(type_, value)
  self.toks[#self.toks + 1] = { type = type_, value = value, line = self.line }
end

function Lexer:read_escape(q) -- after backslash, returns decoded char(s)
  local c = self:nextc()
  if not c then self:_errc("unterminated string") end
  if c == "n" then return "\n"
  elseif c == "t" then return "\t"
  elseif c == "r" then return "\r"
  elseif c == "a" then return "\a"
  elseif c == "b" then return "\b"
  elseif c == "f" then return "\f"
  elseif c == "v" then return "\v"
  elseif c == "\\" then return "\\"
  elseif c == '"' then return '"'
  elseif c == "'" then return "'"
  elseif c == "\n" then return "\n"
  elseif c == "x" then
    local h1, h2 = self:nextc(), self:nextc()
    if not h1 or not h2 or not is_hexdigit(h1) or not is_hexdigit(h2) then self:_errc("bad \\x escape") end
    return string.char(tonumber(h1 .. h2, 16))
  elseif c == "z" then
    while self:peekc() and self:peekc():match("^%s") do self:nextc() end
    return ""
  elseif c == "u" then
    if self:peekc() ~= "{" then self:_errc("expected { after \\u") end
    self:nextc()
    local hex = ""
    while self:peekc() and self:peekc() ~= "}" do hex = hex .. self:nextc() end
    self:nextc() -- }
    local cp = tonumber(hex, 16)
    if not cp then self:_errc("bad \\u codepoint") end
    return utf8 and utf8.char(cp) or string.pack and string.pack("<I4", cp):gsub("%z+$", "") or "?"
  elseif is_digit(c) then
    local num = c
    for _ = 1, 2 do
      if is_digit(self:peekc()) then num = num .. self:nextc() else break end
    end
    return string.char(tonumber(num))
  else
    self:_errc("invalid escape '\\" .. tostring(c) .. "'")
  end
end

function Lexer:read_string(quote)
  local out = {}
  while true do
    local c = self:nextc()
    if not c then self:_errc("unterminated string") end
    if c == quote then break end
    if c == "\\" then out[#out + 1] = self:read_escape(quote)
    else out[#out + 1] = c end
  end
  return table.concat(out)
end

function Lexer:read_long_bracket(level)
  -- consume up to closing ]=...]
  local closer = "]" .. string.rep("=", level) .. "]"
  local s, e = self.src:find(closer, self.pos, true)
  if not s then self:_errc("unterminated long bracket") end
  local content = self.src:sub(self.pos, s - 1)
  -- count newlines for line tracking
  local _, nl = content:gsub("\n", "")
  self.line = self.line + nl
  self.pos = e + 1
  -- strip leading newline immediately after opening bracket
  if content:sub(1, 1) == "\n" then content = content:sub(2)
  elseif content:sub(1, 2) == "\r\n" then content = content:sub(3) end
  return content
end

function Lexer:skip_shebang()
  if self.src:sub(1, 1) == "#" then
    local s, e = self.src:find("\n", 1, true)
    if s then self.pos = s + 1; self.line = 2 else self.pos = #self.src + 1 end
  end
end

function Lexer:tokenize()
  self:skip_shebang()
  while true do
    local c = self:peekc()
    if not c or c == "" then break end
    -- whitespace
    if c:match("^%s") then self:nextc()
    -- comments
    elseif c == "-" and self:peekc(1) == "-" then
      self:nextc(); self:nextc()
      if self:peekc() == "[" then
        local lvl = 0
        local j = 1
        while self:peekc(j) == "=" do lvl = lvl + 1; j = j + 1 end
        if self:peekc(j) == "[" then
          for _ = 0, j do self:nextc() end
          self:read_long_bracket(lvl)
        else
          local s, e = self.src:find("[\n\r]", self.pos)
          if s then while self.pos < s do self:nextc() end else self.pos = #self.src + 1 end
        end
      else
        local s, e = self.src:find("[\n\r]", self.pos)
        if s then while self.pos < s do self:nextc() end else self.pos = #self.src + 1 end
      end
    -- long strings
    elseif c == "[" and (self:peekc(1) == "[" or self:peekc(1) == "=") then
      local save_pos, save_line = self.pos, self.line
      local lvl = 0
      local j = 1
      while self:peekc(j) == "=" do lvl = lvl + 1; j = j + 1 end
      if self:peekc(j) == "[" then
        for _ = 0, j do self:nextc() end
        self:emit("string", self:read_long_bracket(lvl))
      else -- just a [
        self:nextc(); self:emit("[", "[")
      end
    -- quoted strings
    elseif c == '"' or c == "'" then
      self:nextc()
      self:emit("string", self:read_string(c))
    -- interpolated strings (Luau backticks)
    elseif c == "`" then
      self:nextc()
      local out = {}
      while true do
        local ch = self:nextc()
        if not ch then self:_errc("unterminated interpolated string") end
        if ch == "`" then break end
        if ch == "\\" then out[#out + 1] = self:read_escape("`")
        elseif ch == "{" then
          out[#out + 1] = { expr_start = true }
          local depth = 1
          local buf = {}
          while depth > 0 do
            ch = self:nextc()
            if not ch then self:_errc("unterminated interpolation expr") end
            if ch == "{" then depth = depth + 1
            elseif ch == "}" then depth = depth - 1
            elseif ch == '"' or ch == "'" then -- nested plain string
              buf[#buf + 1] = ch
              local q = ch
              while true do
                local sc = self:nextc()
                if sc == q then break end
                if sc == "\\" then buf[#buf + 1] = sc; sc = self:nextc() end
                buf[#buf + 1] = sc
              end
            end
            if depth > 0 then buf[#buf + 1] = ch end
          end
          out[#out + 1] = table.concat(buf)
        else out[#out + 1] = ch end
      end
      self:emit("istring", out)
    -- numbers
    elseif is_digit(c) or (c == "." and is_digit(self:peekc(1))) then
      local start = self.pos
      if c == "0" and (self:peekc(1) == "x" or self:peekc(1) == "X") then
        self:nextc(); self:nextc()
        while is_hexdigit(self:peekc()) or self:peekc() == "." or self:peekc():lower() == "p" do
          if self:peekc():lower() == "p" and not (self:peekc(1) == "+" or self:peekc(1) == "-" or is_digit(self:peekc(1)) or is_hexdigit(self:peekc(1))) then break end
          self:nextc()
        end
      elseif c == "0" and (self:peekc(1) == "b" or self:peekc(1) == "B") then
        self:nextc(); self:nextc()
        while self:peekc() == "0" or self:peekc() == "1" or self:peekc() == "_" do self:nextc() end
      else
        while is_digit(self:peekc()) or self:peekc() == "." do self:nextc() end
        if self:peekc():lower() == "e" then
          local n1 = self:peekc(1)
          if is_digit(n1) or ((n1 == "+" or n1 == "-") and is_digit(self:peekc(2))) then
            self:nextc()
            if self:peekc() == "+" or self:peekc() == "-" then self:nextc() end
            while is_digit(self:peekc()) do self:nextc() end
          end
        end
      end
      local txt = self.src:sub(start, self.pos - 1):gsub("_", "")
      local n
      if txt:sub(1, 2):lower() == "0x" then n = tonumber(txt:sub(3), 16)
      elseif txt:sub(1, 2):lower() == "0b" then n = tonumber(txt:sub(3), 2)
      else n = tonumber(txt) end
      if n == nil then self:_errc("malformed number '" .. txt .. "'") end
      self:emit("number", n)
    -- names / keywords
    elseif is_alpha(c) then
      local start = self.pos
      while is_alnum(self:peekc()) do self:nextc() end
      local word = self.src:sub(start, self.pos - 1)
      if KEYWORDS[word] then self:emit(word, word) else self:emit("name", word) end
    -- operators
    else
      local three = c .. (self:peekc(1) or "") .. (self:peekc(2) or "")
      if three == "//=" or three == "..=" or three == "..." then
        self:nextc(); self:nextc(); self:nextc(); self:emit(three, three)
      else
        local two = c .. (self:peekc(1) or "")
        if two == "==" or two == "~=" or two == "<=" or two == ">=" or two == ".."
           or two == "<<" or two == ">>" or two == "//" or two == "::" or two == "->"
           or COMPOUND[two] then
          self:nextc(); self:nextc(); self:emit(two, two)
        else
          local singles = "+-*/^%#&~|<>=(){}[];:,."
          if singles:find(c, 1, true) then self:nextc(); self:emit(c, c)
          else self:_errc("unexpected character '" .. c .. "'") end
        end
      end
    end
  end
  self:emit("eof", "eof")
  return self.toks
end

return Lexer
