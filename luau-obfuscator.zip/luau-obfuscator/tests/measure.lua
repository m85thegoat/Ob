-- measure.lua :: automated attack simulation against Skynox output
-- Tries to recover constants, opcodes, control flow via simple pattern matching
-- and reports % recovered (lower is better for obfuscator)
package.path = arg[0]:match("^(.*)[/\\]") and
  arg[0]:match("^(.*)[/\\]") .. "/../src/?.lua;" ..
  arg[0]:match("^(.*)[/\\]") .. "/../src/vm/?.lua;" ..
  arg[0]:match("^(.*)[/\\]") .. "/../src/passes/?.lua;" .. package.path
  or "src/?.lua;src/vm/?.lua;src/passes/?.lua;" .. package.path

local function measure(file)
  local s = io.open(file):read("*a")
  local total = {}
  local recovered = {}

  -- Try to find plaintext strings (attack: grep for quoted strings)
  local plain_strings = {}
  for str in s:gmatch('"([^"]-)"') do
    if #str > 2 and not str:match("^%-%-") and not str:match("^__") then
      plain_strings[#plain_strings+1] = str
    end
  end
  -- Try to find opcode names (old VM had LOADK etc.)
  local opcodes = {"KON","NIL","TRUE","FALSE","NAME","IDX","CALL","BIN","RET"}
  local found_ops = 0
  for _, op in ipairs(opcodes) do
    if s:find(op) then found_ops = found_ops + 1 end
  end
  -- Try to find hook checks (old signature)
  local hook_sigs = {"hookfunction","getgc","newcclosure"}
  local found_hooks = 0
  for _, sig in ipairs(hook_sigs) do
    if s:find(sig) then found_hooks = found_hooks + 1 end
  end
  -- Check for watermark (should be present)
  local has_watermark = s:find("Skynox") and 1 or 0
  -- Check for binary blob marker/profile machinery without assuming a fixed magic.
  local has_blob = (s:find("__PROFILE_ID") and s:find("__SKX_SEAL_A") and 1 or 0)

  print(string.format("File: %s", file))
  print(string.format("  Plaintext strings found: %d", #plain_strings))
  if #plain_strings > 0 then
    for i=1,math.min(3,#plain_strings) do print("    -", plain_strings[i]:sub(1,40)) end
  end
  print(string.format("  Opcode names visible: %d/%d", found_ops, #opcodes))
  print(string.format("  Hook signatures visible: %d/%d", found_hooks, #hook_sigs))
  print(string.format("  Watermark present: %s", has_watermark==1 and "yes" or "no"))
  print(string.format("  Binary blob present: %s", has_blob==1 and "yes (good)" or "no"))
  local score = ( #plain_strings==0 and found_ops==0 and found_hooks==0 ) and "HARD" or "WEAK"
  print(string.format("  Verdict: %s", score))
  return score
end

local files = {
  "/tmp/final_hard.lua",
  "/tmp/opencode/final_demo.lua",
}
for _, f in ipairs(files) do
  local ok, err = pcall(measure, f)
  if not ok then print("Error measuring", f, err) end
  print("")
end
