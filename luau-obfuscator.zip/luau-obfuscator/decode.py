# decode_script.py
import zlib
import base64
import struct

# The binary data from your output
data = b"""
\x13\x08\x0b\xf7\x00\x93\xd0@\xdd\xd5\xb8i\x15'\xf8UI\x13\x84\xe2\x10\xb7\x90Ie\x0e]\xcb\xda~D\x9fi\xbdy\xbb\xfc\x1f\x83.\xd3^\xcc/\xc12\x8cW\x90S\x0bo\xce\x93vm\x7f\x89\x05\xa0u\xbb\x95\x84\x05\xd7oE\x18\xf5vO\xf5\xee\xba\xe4\x84R\x9dun\x0b\x97\n\x8dc`\x91b\xcd\x84kn\xf2\x99>\r*\x0e\xceP\xd1\xb8^,\x15!\x1d\xed\xb3\xc4\xa8\x0f\xd4\x10\xc65\xf1\xea\xef@)Q\x18\x89\xd3l\x8c\n\n\xe3s\x89\xc6\xf6P\x03}#4v\rX\xbf\xf9\xc5\xd2e9\x84\x99\x19\x91\xa5\x84\xa5\xca`\x8b\xfdh\x9c\xc4\x8e\xe3\xe8P\x06h\xa7\xad\xd68tX\x88\xe1\x82c\xe5\xcd9'\x82\xf3\x9d\xe7\xadZ\x80Oy\xbf\x0b\xadRNb\xb2\xf3\x1a\xe2\x86\xb0*n\xff\x88\xb5@\xb6\xf3\x8e\xf8\x15\x89f-q\nO\xce\x8e\xae\xebe\xeb\xe0\xcc\xf6\xdf\xba\xeeG h\x7f\x88R\x1f\xf9\x13\xeb\xae\x00\xbc\x95\x1b\x10\xd1\x01\x875\xaa\xbf\xc3\xd4u\x1b\x02\xd2,_\x90\xe9\x1e\xd2\x9c\xd9\xc7\xad\xccS\xa6\xee\xfc\xa6\xbe\xb4v[\x8d\xc3\xc0\x1f\xc8\xc8-X\x16\xbd\x0c\x7f\x90\xf1\xc4y\rY\xb8\xe9Fx\xa9\xc7\xc9\xedf\xcd\xdd8\xfb\xf3\x96%DJV\xf0\xb2'F\xc7\xec\x90x^\xee\xe0\xcc\x87v\xcd\xf2\xaa\xfb\xae\x1f\x8f\x83q\x0e\x1b\xbc\xf7\x89\xda\x19\x160\xf7\xbe\x88\x12\xbbR>U\x16\x0c\x9e\xe1\xa2\xacl\r\x8c\x88\xe5\xdb\xd8ZBK\xa5Z\x86\xfd\xb6\xf6\xc1V\x90\n+\xff\x1b\xac\xdc_\x9a\xf0\x1c*\x9dX\xa7\x90j<\xec\xb89w\x16\x9c\xee\xb6[\x98>\xef\xd2\xa4\xad\xbf\xb1h\xae)\x98\xa9/>\xa9\xc8N\x85\xbcQ]4V\xa7]r\xd2Q&3ae\xc6K\xd7^\x0c\xbf4\xf0\x97P\xe8\x06\x9e\x10'\xfb\x1f]\x14y\x89\xbd\x7fn\x83\xe0\xd9\xe3.K\xc7\xdcz\x91X\x7fV\xc5RJC\xcap\xef\xb6s\xb5\xd3\xbe\xaak\xb6hQ
""".strip()

def try_decrypt(data):
    print(f"Data length: {len(data)} bytes")
    
    # Check if it's compressed
    try:
        # Try zlib
        decompressed = zlib.decompress(data)
        print("✓ Successfully decompressed with zlib!")
        return decompressed
    except:
        pass
    
    # Try XOR with common keys
    common_keys = ["luau", "obfuscator", "key", "12345", "secret", "lua", "spray", "pc", "roblox"]
    
    for key in common_keys:
        result = bytearray()
        for i, byte in enumerate(data):
            result.append(byte ^ ord(key[i % len(key)]))
        
        # Check if result looks like Lua code
        try:
            text = result.decode('utf-8', errors='ignore')
            if any(keyword in text for keyword in ["function", "local", "if", "then", "print"]):
                print(f"✓ Found XOR key: '{key}'")
                return bytes(result)
        except:
            pass
    
    # Try base64
    try:
        decoded = base64.b64decode(data)
        print("✓ Successfully decoded base64!")
        return decoded
    except:
        pass
    
    # Try as bytecode (Lua 5.1/5.2/5.3)
    try:
        # Lua bytecode starts with 0x1B 0x4C 0x75 0x61 (ESC L u a)
        if data[:4] == b'\x1B\x4C\x75\x61':
            print("✓ Identified as Lua bytecode!")
            return data
    except:
        pass
    
    return None

def extract_strings(data):
    """Extract readable strings from binary"""
    strings = []
    current = []
    for byte in data:
        if 32 <= byte <= 126:  # Printable ASCII
            current.append(chr(byte))
        else:
            if len(current) > 4:
                strings.append(''.join(current))
            current = []
    return strings

# Try to decode
result = try_decrypt(data)

if result:
    print("\n" + "="*50)
    print("DECODED DATA:")
    print("="*50)
    
    # Try to show as text
    try:
        text = result.decode('utf-8', errors='ignore')
        print(text[:2000])  # Show first 2000 chars
    except:
        print("Binary data that couldn't be decoded as text")
    
    # Extract readable strings
    strings = extract_strings(result)
    if strings:
        print("\n" + "="*50)
        print("EXTRACTED STRINGS:")
        print("="*50)
        for s in strings:
            print(s)
    
    # Save to file
    with open("decoded_output.bin", "wb") as f:
        f.write(result)
    print("\n✓ Saved to decoded_output.bin")
else:
    print("❌ Could not decode with standard methods")
    print("This might be encrypted with a custom algorithm")
    
    # Show hex dump for analysis
    print("\nFirst 100 bytes (hex):")
    hex_str = ' '.join(f'{b:02x}' for b in data[:100])
    print(hex_str)
    
    # Try to identify if it's Lua bytecode by checking the header
    if data[:4] == b'\x1B\x4C\x75\x61':
        print("\n✓ This IS Lua bytecode!")
        print("Format: Lua 5.x bytecode")
        # Parse the version
        version = data[4]
        print(f"Version: {version}")
    elif data[:3] == b'\xEF\xBB\xBF':
        print("\n✓ UTF-8 BOM detected - this is text")
    else:
        print("\n❌ Unknown format")
