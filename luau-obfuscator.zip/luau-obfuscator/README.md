# ------[Skynox Obfuscator]

Pure-Lua obfuscator for Lua 5.4 / Luau(Roblox)-targeted source. Runs under **lua5.4** and **luajit**, zero dependencies.

## Usage

```bash
lua5.4 Obfuscator.lua input.lua -o out.lua --maximum
luajit Obfuscator.lua input.lua -o out.lua --mode vm --seed 1234
```

| Flag | Meaning |
|---|---|
| `-o, --output FILE` | output path (defaults to `<input>.obf.lua`) |
| `--maximum` | VM engine + all protections + paranoid intensity |
| `--mode source\|vm` | `source`: transformed source; `vm`: compiled to custom bytecode + interpreter |
| `--intensity light\|medium\|paranoid` | encoding depth for number/string passes |
| `--seed N` | reproducible builds (opcode maps & keys are seed-derived) |
| `--no-rename`, `--no-deadcode`, `--protections on or off` | pass toggles |
| `--cfflatten on or off` | opt-in source-mode control-flow flattening |
| `-h, --help` | show CLI help |

## Pipeline

1. **Lexer/Parser/Printer** — full Lua 5.4 syntax + Luau extensions (type annotations skipped verbatim, compound assignment desugared, interpolated strings lowered to concat). Lexer correctly handles all compound forms (`-=`, `/=`, `..=` etc.); printer guards token-fusion for unary minus and `..`.
2. **Passes**
   - local identifier renaming (scope-correct, seed-random names)
   - string encryption (per-string XOR + rolling key + runtime decoder)
   - number encoding (sign-safe arithmetic splits, XOR chains, float-exact Veltkamp identities)
   - dead-code injection behind opaque predicates (decoy "bait" strings for dumpers/loggers)
3. **VM mode** — AST compiled to seed-shuffled numeric-opcode tuple programs with a build-specific wire profile: randomized magic, field/constant tags, tuple-header order, salt range, opcode numbering, and ciphertext segment topology. Constants are decoded lazily on first access by an embedded tree-coded interpreter with scope-chain environments and live closures/upvalues. Additional hardening per build:
   - **Konstant-index whitening**: every `KON` / `MCALL` / `SETGFN` / `GFOR` konst slot is XORed with a build mask and unwrapped lazily inside `KKREF`
   - **Chunked string constants**: each constant string is shattered into 1-5 length-varied chunks across the keystream cursor
   - **Per-build identifier mangling**: the entire crypto/reader/engine region is deterministically renamed (every replacement contains `_` and a digit, so literals cannot collide)
   - **Decoder scrubbing**: the inverse S-box is wiped once cascade decryption finishes
   - **Fail-closed bombs**: any unknown opcode, bad arity, or structural anomaly routes directly to the integrity failure path
4. **Protections wrapper**
   - **Layered integrity manifest**: exact segment count/length checks, per-segment hashes, independent forward/reverse payload seals, and a linked final seal. The manifest verifier is emitted as a re-sealable `__skx_reseal()` closure callable at every phase boundary.
   - **Seal-bound decoding**: source and VM decoder keys are wrapped with verified seals; VM output also validates its embedded opcode-mask header before tuple decoding. VM unwrapping mixes in the Anti-Tamper guard tokens.
   - **Anti-Tamper guard (V1.1)**: pristine primitive capture, execution-oracle probes, hostile-global fingerprinting (configurable strict env-signature scan), debug-hook detection, and periodic `__skx_guard(true)` revalidation. Source and VM both drive `__skx_guard(true)` before and after sensitive phases.
   - **Supplementary hardening layer** (`protections.lua`): expanded oracle, tooling tripwire, anti-envlog channel canary (`print`/`warn`/`error` snapshot + `__skx_canary_recheck()` at boot), and decoy bait constants that waste dumper time.
   - **Fail-closed reader**: malformed varints, tags, lengths, S-boxes, nesting, trailing bytes, and runtime primitive anomalies stop before user code runs. The strict reader also validates per-tuple arity and salt.
   - **Anti-dump aids**: encrypted local payload segments, chunked constants, index whitening, identifier mangling, decoder scrubbing, and segment plaintext wipe (source mode nils `__SKX_SEG`/`__skx_src` after `load`).
5. On detection: prints the mockery message and crashes:

```
Lol trying to Deobfuscate or Env Log try better luck next time
```

Every output file is watermarked:

```
------[Skynox Obfuscator]
```

## Honest limitations

- No obfuscation is unbreakable; this raises reversing cost substantially but a determined attacker with enough time can devirtualize.
- Protected source mode requires `load`/`loadstring` at runtime. Plain Roblox LocalScripts don't have it — use **`--mode vm`** there (the interpreter needs no `load`).
- VM mode does not support `goto`/labels. Standard generic-for iteration, varargs, multi-return assignment, call/table expansion, repeat-until scope, method declarations, and compound assignment are supported.
- Statement-level control-flow flattening is opt-in (`--cfflatten on`) and unsafe for cross-state locals; the VM layer supersedes it structurally.

## Tests

```bash
cd tests && lua5.4 run_tests.lua   # also runs under luajit
```

The suite covers both runtimes and output modes, CLI failures, plaintext leakage,
payload/manifest/wrapped-key mutations, hostile-global tripwire (strict profile),
and regression cases for compound assignment and float-exactness.

## Recent hardening notes

- Fixed VM wire check `__TO~=__NT` typo, lexer `COMPOUND` keys for `-=`/`/=`, printer unary-minus fusion, `bitutil.arshift`, `varint` neg handling, removed `SKYNOX_DEBUG` plaintext dump, stripped dead `vm/gen.lua` legacy engine, and corrected float splitting to error-free Veltkamp identities.
- Default seed now mixes wall time, high-resolution clock fraction, and input length when `--seed` is omitted.
