local discordia = require('discordia')
local http = require('coro-http')
local client = discordia.Client()

local function check_obfuscation(content)
    local signatures = {"Luraph", "IronBrew", "Prometheus", "Moonsec", "Syn_Load", "Aztup"}
    for _, sig in ipairs(signatures) do
        if content:find(sig) then
            return true, sig:lower()
        end
    end
    
    local hex_count = select(2, content:gsub("\\x", ""))
    if hex_count > 20 then
        return true, "heavy hex encoding"
    end
    
    return false, "clean"
end

client:on('messageCreate', function(msg)
    if msg.author.bot then return end
    
    if msg.content:sub(1, 5) == ".get " then
        local url = msg.content:sub(6)
        
        if not url:match("^https?://") then
            msg:reply("please provide a valid link.")
            return
        end
        
        local headers = {
            {"User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"}
        }
        
        local success, _, body = pcall(http.request, "GET", url, headers)
        if not success or not body then
            msg:reply("error fetching the url.")
            return
        end
        
        local filename = "script_" .. os.time() .. ".txt"
        local f = io.open(filename, "w")
        if not f then
            msg:reply("failed to create file.")
            return
        end
        f:write(body)
        f:close()
        
        local is_obf, detail = check_obfuscation(body)
        local status = is_obf and ("obfuscated [" .. detail .. "]") or "not obfuscated"
        
        msg:reply({
            content = "status: " .. status,
            file = filename
        })
        
        os.remove(filename)
    end
end)

client:run("Bot " .. (os.getenv("discord_token") or "token_here"))
