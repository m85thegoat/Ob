return {
  name = "skynox-discordia-bot",
  version = "1.0.0",
  description = "Skynox .get bot",
  tags = {"discordia"},
  license = "MIT",
  author = { name = "Skynox" },
  dependencies = {
    "SinisterRectus/discordia@2.13.0",
    "luvit/secure-socket@1.2.3",
    "creationix/coro-http@3.2.0"
  }
}
