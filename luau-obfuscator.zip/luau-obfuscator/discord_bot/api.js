// api.js - REST API for Skynox Luau-Obfuscator
// POST /obfuscate   body: { source, preset?, seed? }
// GET  /health
// Auth: header "x-hercules-token" must equal HERCULES_API_TOKEN env.

const http = require("http");
const { execFile } = require("child_process");
const path = require("path");
const fs = require("fs");
const os = require("os");

const PORT = parseInt(process.env.PORT || "8080", 10);
const TOKEN = process.env.HERCULES_API_TOKEN || "";
if (!TOKEN) console.warn("[WARN] HERCULES_API_TOKEN not set - API will be disabled");
const MAX_BODY = 1024 * 1024;
const TIMEOUT_MS = 60000;

const ROOT = path.resolve(__dirname, "..");
// SECURITY: use per-request temp dir to avoid race
function makeWorkDir() {
    return fs.mkdtempSync(path.join(os.tmpdir(), "skynox-api-"));
}

const PRESETS = new Set(["maximum","free"]);

function presetToArgs(preset) {
    if (preset === "free") return ['--mode','vm','--intensity','medium'];
    return ['--maximum'];
}

function runSkynox(source, preset, seed) {
    return new Promise((resolve) => {
        const WORKDIR = makeWorkDir();
        const inFile = path.join(WORKDIR, `in-${Date.now()}-${require('crypto').randomBytes(4).toString('hex')}.lua`);
        const outFile = inFile.replace(/\.lua$/, ".obf.lua");
        const outFile2 = inFile.replace(/\.lua$/, "_obfuscated.lua");
        fs.writeFileSync(inFile, source);
        const args = [inFile, ...presetToArgs(preset)];
        // validate seed is safe integer
        if (seed !== undefined && seed !== null) {
            const n = Number(seed);
            if (!Number.isSafeInteger(n) || Math.abs(n) > 9007199254740991) {
                try { fs.rmSync(WORKDIR, {recursive:true, force:true}); } catch(_){}
                return resolve({ ok: false, error: "invalid seed" });
            }
            args.push('--seed', String(n));
        }

        // Resolve Obfuscator.lua robustly (handles both /luau-obfuscator and /home/ubuntu/luau-obfuscator)
    let obfuscatorFile = "Obfuscator.lua";
    const apiCandidates = [
        require("path").join(ROOT, "Obfuscator.lua"),
        "/home/ubuntu/luau-obfuscator/Obfuscator.lua",
        "/luau-obfuscator/Obfuscator.lua",
    ];
    for (const cand of apiCandidates) { try { if (require("fs").existsSync(cand)) { obfuscatorFile = cand; break; } } catch(_){} }
    execFile("lua5.4", [obfuscatorFile, ...args], {
            cwd: ROOT,
            timeout: TIMEOUT_MS,
            maxBuffer: 64 * 1024 * 1024,
        }, (err) => {
            try {
                if (err) return resolve({ ok: false, error: "obfuscation failed: " + String(err.message || err).slice(0, 300) });
                let result = null;
                for (const cand of [outFile, outFile2, inFile + ".obf.lua"]) {
                    if (fs.existsSync(cand)) { result = fs.readFileSync(cand, "utf8"); try{fs.unlinkSync(cand);}catch(_){} break; }
                }
                if (!result) {
                    const files = fs.readdirSync(WORKDIR).filter(f=>f.includes('.obf')||f.includes('_obfuscated'));
                    if (files.length) { result = fs.readFileSync(path.join(WORKDIR, files[0]), "utf8"); }
                }
                if (!result) return resolve({ ok: false, error: "no output produced" });
                resolve({ ok: true, result });
            } finally {
                try { fs.unlinkSync(inFile); } catch (_) {}
                try { fs.rmSync(WORKDIR, {recursive:true, force:true}); } catch(_){}
            }
        });
    });
}

function send(res, code, obj) {
    const body = JSON.stringify(obj);
    res.writeHead(code, { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(body) });
    res.end(body);
}

const server = http.createServer((req, res) => {
    if (req.method === "GET" && req.url === "/health") {
        return send(res, 200, { ok: true, service: "skynox-api", uptime_s: Math.floor(process.uptime()) });
    }
    if (req.method !== "POST" || req.url !== "/obfuscate") return send(res, 404, { ok: false, error: "not found" });
    if (!TOKEN) return send(res, 503, { ok: false, error: "server missing HERCULES_API_TOKEN" });
    if ((req.headers["x-hercules-token"] || "") !== TOKEN) return send(res, 401, { ok: false, error: "unauthorized" });

    let size = 0; const chunks = []; let aborted = false;
    req.on("data", (c) => { size += c.length; if (size > MAX_BODY) { aborted = true; return send(res, 413, { ok: false, error: "body exceeds 1MB" }); } chunks.push(c); });
    req.on("end", () => {
        if (aborted) return;
        let parsed; try { parsed = JSON.parse(Buffer.concat(chunks).toString("utf8")); } catch(_) { return send(res, 400, { ok: false, error: "invalid JSON" }); }
        const source = typeof parsed.source === "string" ? parsed.source : null;
        if (!source) return send(res, 400, { ok: false, error: "missing 'source' string" });
        if (source.length > MAX_BODY) return send(res, 413, { ok: false, error: "source exceeds 1MB" });
        const preset = PRESETS.has(parsed.preset) ? parsed.preset : "maximum";
        runSkynox(source, preset, parsed.seed).then((r) => {
            if (r.ok) send(res, 200, { ok: true, preset, bytes: r.result.length, result: r.result });
            else send(res, 422, r);
        });
    });
});

server.on('error', (e) => {
    console.error('[api] failed to start:', e.code === 'EADDRINUSE' ? ('port ' + PORT + ' in use') : e.message);
});

server.listen(PORT, () => {
    console.log(`[api] Skynox REST API on :${PORT} (token ${TOKEN ? "set" : "MISSING"})`);
});

module.exports = { server };
