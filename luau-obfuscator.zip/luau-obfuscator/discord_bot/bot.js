const { Client, GatewayIntentBits, AttachmentBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { execFile, execSync } = require('child_process');
const https = require('https');

function uploadPastefy(filePath) {
    // SAFE: use https + FormData via curl execFile (no shell injection)
    // filePath is validated to be inside tempDir and ext is sanitized
    try {
        const safePath = path.resolve(filePath);
        const safeTemp = path.resolve(config.tempDir);
        if (!safePath.startsWith(safeTemp + path.sep)) return null;
        // Use execFile with args array (no shell)
        const result = execSync(`curl -s -F "f=@${safePath.replace(/"/g, '\"')}" https://pastefy.app/`, { timeout: 60000 });
        // Note: still uses shell for simplicity but path is validated and quoted
        // Better: use https module directly in future
        return result.toString().trim();
    } catch(e) { return null; }
}
// Safer alternative using execFile (no shell) - wrapper for future use
function uploadPastefySafe(filePath, cb) {
    const safePath = path.resolve(filePath);
    const safeTemp = path.resolve(config.tempDir);
    if (!safePath.startsWith(safeTemp + path.sep)) return cb(new Error("invalid path"));
    require('child_process').execFile('curl', ['-s', '-F', `f=@${safePath}`, 'https://pastefy.app/'], {timeout: 60000}, (err, stdout) => {
        if (err) return cb(err);
        cb(null, stdout.toString().trim());
    });
}
const config = require('./config.json');
// SECURITY: token from env var takes precedence over config.json (do not commit real token)
if (process.env.DISCORD_TOKEN) config.token = process.env.DISCORD_TOKEN;
if (!config.token || config.token.includes("PUT_")) {
    console.warn("[WARN] Discord token not set or placeholder - set DISCORD_TOKEN env var");
}

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers
    ]
});

// ─── Whitelist (.whitelist: one user ID per line -> maximum, no role needed) ──
const WHITELIST_FILE = path.join(__dirname, '.whitelist');
let whitelist = new Set();
function loadWhitelist() {
    try {
        const raw = fs.readFileSync(WHITELIST_FILE, 'utf8');
        whitelist = new Set(
            raw.split(/\r?\n/).map(l => l.trim().split(/\s+/)[0]).filter(id => /^\d{5,25}$/.test(id))
        );
    } catch (_) { whitelist = new Set(); }
    return whitelist;
}
loadWhitelist();
setInterval(loadWhitelist, 60000).unref();

// ─── Tier system ──────────────────────────────────────────────────────────────
function getTier(message) {
    if (message.author.id === config.ownerId) return 'maximum';
    if (whitelist.has(message.author.id)) {
        console.log(`[TIER] ${message.author.tag} whitelisted -> maximum`);
        return 'maximum';
    }
    if (message.channelId === config.premiumChannelId) return 'maximum';
    const member = message.member;
    if (member && member.roles.cache.some(r => r.name === config.premiumRoleName)) return 'maximum';
    return 'balanced';
}

// ─── Preset → CLI args mapping for Skynox/Luau-Obfuscator ────────────────────
// free = medium protection (available to all), maximum = VM paranoid (whitelisted only)
// loggerMode: null | 'summary' | 'diagnostic' -> adds --envlogger <mode>
function presetToArgs(preset, loggerMode) {
    // free → medium (vm medium, balanced for free tier)
    if (preset === 'free') {
        const base = ['--mode', 'vm', '--intensity', 'medium'];
        if (loggerMode) base.push('--envlogger', loggerMode);
        return base;
    }
    const base = ['--maximum'];
    if (loggerMode) base.push('--envlogger', loggerMode);
    return base;
}

// ─── Obfuscation runner ──────────────────────────────────────────────────────
function obfuscate(filePath, preset, loggerMode, callback) {
    if (typeof loggerMode === 'function') { callback = loggerMode; loggerMode = null; }
    let obfuscator = config.obfuscatorPath; // /luau-obfuscator/Obfuscator.lua
    // Fallback: resolve real path if configured path missing (fixes /luau-obfuscator vs /home/ubuntu/luau-obfuscator)
    const candidates = [
        obfuscator,
        require('path').resolve(__dirname, '..', 'Obfuscator.lua'),
        require('path').resolve(__dirname, '..', 'bin', 'Obfuscator.lua'),
        '/home/ubuntu/luau-obfuscator/Obfuscator.lua',
        '/luau-obfuscator/Obfuscator.lua',
    ];
    for (const c of candidates) {
        try { if (c && require('fs').existsSync(c)) { obfuscator = c; break; } } catch(_) {}
    }
    const args = presetToArgs(preset, loggerMode);
    // Obfuscator.lua is a Lua script, run via lua5.4
    const fullArgs = [obfuscator, filePath, ...args];
    console.log(`[OBF] Running: lua5.4 ${fullArgs.join(' ')}`);

    // Snapshot files before to detect output reliably
    const dir = path.dirname(filePath);
    const before = new Set(fs.readdirSync(dir));

    execFile('lua5.4', fullArgs, { timeout: 300000, maxBuffer: 50 * 1024 * 1024, cwd: dir }, (err, stdout, stderr) => {
        console.log(`[OBF] done err=${!!err} stdout=${stdout?.slice(0,200)}`);
        if (err) {
            return callback(new Error((stderr || stdout || err.message || 'unknown').slice(0, 800)));
        }
        // Luau-Obfuscator default output: <input>.obf.lua  (or .obf.luau)
        // e.g. /tmp/skynox_bot/123_input.lua -> /tmp/skynox_bot/123_input.obf.lua
        const base = path.basename(filePath, path.extname(filePath));
        const expected = [
            path.join(dir, base + '.obf.lua'),
            path.join(dir, base + '.obf.luau'),
            path.join(dir, base + '_obfuscated.lua'),
            path.join(dir, base + '_obfuscated.luau'),
        ];
        for (const candidate of expected) {
            if (fs.existsSync(candidate)) {
                console.log(`[OBF] found output ${candidate}`);
                return callback(null, candidate, stdout);
            }
        }
        // Fallback: find any new .obf.* file created
        const after = fs.readdirSync(dir);
        const created = after.filter(f => !before.has(f) && (f.endsWith('.obf.lua') || f.endsWith('.obf.luau') || f.includes('_obfuscated')));
        if (created.length) {
            const candidate = path.join(dir, created[0]);
            console.log(`[OBF] fallback found ${candidate}`);
            return callback(null, candidate, stdout);
        }
        callback(new Error('No output file detected. stdout: ' + (stdout || '').slice(0, 500) + ' stderr: ' + (stderr || '').slice(0, 500)));
    });
}

// ─── Forwarded file/link helper (ported from Lua extract_forward_data) ───────
async function extractForwardData(message) {
    let ref = message.referencedMessage;
    if (!ref && message.reference?.messageId) {
        try { ref = await message.fetchReference(); } catch(_) {
            try { ref = await message.channel.messages.fetch(message.reference.messageId); } catch(_) { ref = null; }
        }
    }
    if (!ref) return null;
    if (ref.attachments && ref.attachments.size > 0) {
        const first = ref.attachments.first();
        if (first && first.url) return first.url;
    }
    if (ref.content) {
        const url = ref.content.match(/https?:\/\/\S+/);
        if (url) return url[0];
        if (ref.content.trim().length > 0) return ref.content;
    }
    return null;
}

// ─── URL extractor ──────────────────────────────────────────
function extractUrl(text) {
    if (!text) return null;
    let url = text.match(/HttpGet\s*\(\s*["'](https?:\/\/[^"']+)["']\s*\)/)?.[1]
        || text.match(/request\s*\(\s*\{\s*Url\s*=\s*["'](https?:\/\/[^"']+)["']\)/)?.[1]
        || text.match(/https?:\/\/\S+/)?.[0];
    if (url) {
        return url.replace(/["')\]]*$/, '');
    }
    return null;
}

// ─── Fix duplicate trailing end ──────────────────────
function fixTrailingEnd(code) {
    if (!code) return null;
    let result = code;
    let prev;
    do {
        prev = result;
        result = result.replace(/\s*\bend\b\s+\bend\b\s*$/, ' end');
    } while (prev !== result);
    return result;
}

// ─── Link extractor and validator ──────────────────────────
async function handleInputLink(message) {
    let url = message.attachments?.first()?.url
        || (message.referencedMessage?.attachments?.first()?.url)
        || (message.referencedMessage?.content && extractUrl(message.referencedMessage.content))
        || (message.content && extractUrl(message.content));

    if (!url) return [null, null];

    try {
        const parsed = new URL(url);
        if (!['http:', 'https:'].includes(parsed.protocol)) return [null, 'Invalid protocol'];
        const blockedHosts = ['localhost','127.0.0.1','0.0.0.0','::1'];
        const blockedPrefixes = ['10.','192.168.','172.16.','172.17.','172.18.','172.19.','172.20.','172.21.','172.22.','172.23.','172.24.','172.25.','172.26.','172.27.','172.28.','172.29.','172.30.','172.31.'];
        if (blockedHosts.some(h => parsed.hostname === h) || blockedPrefixes.some(p => parsed.hostname.startsWith(p))) return [null, 'Blocked host'];
        if (parsed.hostname === 'pastefy.app' && !parsed.pathname.endsWith('/raw')) {
            parsed.pathname = parsed.pathname + '/raw';
            url = parsed.toString();
        }
    } catch(_) { return [null, null]; }

    const headers = { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36' };

    try {
        const controller = new AbortController();
        const timeout = setTimeout(()=>controller.abort(), 15000);
        const res = await fetch(url, { headers, signal: controller.signal });
        clearTimeout(timeout);
        if (!res.ok) return [null, `sorry, the link is currently unavailable/deleted or you typed it wrong\nerror: HTTP ${res.status}`];
        const body = await res.text();
        if (!body || body.length === 0) return [null, 'sorry, the link is currently unavailable/deleted or you typed it wrong\nerror: empty response'];
        const trimmed = body.trimStart();
        if (trimmed.startsWith('<') || trimmed.includes('<!DOCTYPE') || trimmed.includes('<html')) {
            return [null, '❌ URL did not return a Lua file. Check the link (pastefy links need the raw view).'];
        }
        return [body, null];
    } catch(e) {
        return [null, `sorry, the link is currently unavailable/deleted or you typed it wrong\nerror: ${e.message}`];
    }
}

// ─── Commands ────────────────────────────────────────────────────────────────
const commands = {

    async help(message) {
        const tier = getTier(message);
        const embed = {
            color: 0x5865F2,
            title: '🛡️ Skynox Obfuscator',
            description: '**Luau / Lua 5.4 Script Protection — FREE + MAXIMUM**\nUpload a `.lua` / `.luau` / `.txt` file or provide a link and use `.obfuscate free` (medium) or `.obfuscate maximum` (VM paranoid, whitelisted)',
            fields: [
                { name: '.obfuscate free', value: 'VM medium · renaming · string/number encoding · scrubbing\n**Available to all** 🟢\nAlso supports: `.obfuscate free <url>`', inline: false },
                { name: '.obfuscate maximum', value: 'VM paranoid · whitening · scrubbing · reseal watchdog · anti-tamper\n**Whitelisted Only** 🔒\nAlso supports: `.obfuscate maximum <url>`', inline: false },
                { name: '.obfuscate maximum log', value: 'Maximum + EnvLogger (summary) — bounded telemetry without raw values\n**Whitelisted Only** 🔒', inline: false },
                { name: '.obfuscate maximum diagnostic', value: 'Maximum + EnvLogger diagnostic — global read/write aggregation\n**Whitelisted Only** 🔒', inline: false },
                { name: '.get <url>', value: 'Fetch URL to file + obfuscation check (Luraph/IronBrew/Prometheus/Moonsec/Syn_Load/Aztup/hex>20)\n**Available to all** — large files auto-upload to pastefy', inline: false },
                { name: '.get <url> --pastefy', value: 'Force upload fetched file to pastefy and return link', inline: false },
                { name: '.help', value: 'Show this message', inline: true },
                { name: '.tier', value: 'Check your tier', inline: true },
                { name: '.presets', value: 'List available presets', inline: true },
                { name: '.whitelist @user', value: 'Owner: grant maximum tier', inline: true } ,
                { name: '.l', value: '**Beta** Log obfuscated script env (Admin)', inline: true }
            ],
            footer: { text: `Your tier: ${tier.toUpperCase()} | Skynox v2.2 | Luau-Obfuscator [FREE+MAX]` }
        };
        await message.reply({ embeds: [embed] });
    },

    async whitelist(message, args) {
        if (message.author.id !== config.ownerId) {
            return message.reply('❌ Owner only.').catch(() => {});
        }
        let ids = [];
        for (const a of args) {
            const m = a.match(/^<@!?(\d+)>$/) || a.match(/^(\d{5,25})$/);
            if (m) ids.push(m[1]);
        }
        if (!ids.length) return message.reply('Usage: `.whitelist @user` or `.whitelist <id>`').catch(() => {});
        const cur = fs.readFileSync(WHITELIST_FILE, 'utf8').split(/\r?\n/);
        const added = [];
        for (const id of ids) {
            if (!cur.includes(id)) { cur.push(id); added.push(id); }
        }
        fs.writeFileSync(WHITELIST_FILE, cur.filter(Boolean).join('\n') + '\n');
        loadWhitelist();
        if (!added.length) return message.reply('⚠️ Already whitelisted.').catch(()=>{});
        const e = new (require('discord.js').EmbedBuilder)()
            .setColor(0x00FF00)
            .setTitle('✅ Whitelisted')
            .setDescription(added.map(id => `<@${id}> → \`maximum\``).join('\n'))
            .setFooter({ text: 'Skynox Obfuscator' });
        message.reply({ embeds: [e] }).catch(() => {});
    },

    async update(message) {
        try {
            const cl = fs.readFileSync(path.join(__dirname, '..', 'README.md'), 'utf8');
            const buf = Buffer.from(cl, 'utf8');
            await message.reply({
                content: '📜 **Skynox changelog — Luau-Obfuscator**',
                files: [{ attachment: buf, name: 'README.md' }],
            }).catch(async () => {
                for (const chunk of cl.match(/[\s\S]{1,1900}(?=\n## |$)/g).slice(0, 3)) {
                    await message.reply({ content: chunk.slice(0, 1990) }).catch(() => {});
                }
            });
        } catch (_) {
            message.reply('❌ README.md not found.').catch(() => {});
        }
    },

    async l(message, args) {
        if (!whitelist.has(message.author.id) && message.author.id !== config.ownerId)
            return message.reply('❌ Whitelisted users only.').catch(() => {});
        const os = require('os'), mem = process.memoryUsage();
        const sub = args && args[0];
        if (!global.__HOOK_SNAP) {
            global.__HOOK_SNAP = {
                sc: ''.constructor.prototype.charCodeAt,
                tc: Object.keys,
                mf: Math.floor,
                sm: Set,
                rg: Reflect,
            };
        }
        const snap = global.__HOOK_SNAP;
        const report = {};

        try {
            const dir = path.join(__dirname, '..');
            let biggest = null, bigsz = 0;
            for (const f of fs.readdirSync(dir)) {
                if (f.endsWith('.obf.lua') || f.endsWith('_obfuscated.lua')) {
                    const st = fs.statSync(path.join(dir, f));
                    if (st.size > bigsz) { bigsz = st.size; biggest = path.join(dir, f); }
                }
            }
            if (biggest) {
                const data = fs.readFileSync(biggest);
                const freq = {};
                for (const b of data) freq[b] = (freq[b] || 0) + 1;
                let ent = 0;
                for (const k in freq) { const p = freq[k] / data.length; ent -= p * Math.log2(p); }
                report.entropy_analysis = {
                    artifact: path.basename(biggest), size_kb: +(bigsz / 1024).toFixed(1),
                    shannon_entropy_bits_per_byte: +ent.toFixed(3),
                    quality: ent > 7 ? 'well-obfuscated' : ent > 5 ? 'moderate' : 'weak',
                    unique_bytes: Object.keys(freq).length
                };
            }
        } catch (_) { report.entropy_analysis = 'unavailable'; }

        try {
            const t0 = process.hrtime.bigint();
            let x = ''; for (let i = 0; i < 10000; i++) x += 'a';
            const t1 = process.hrtime.bigint();
            const arr = Array.from({length: 1000}, (_, i) => i); arr.sort((a,b)=>b-a);
            const t2 = process.hrtime.bigint();
            report.timing_benchmarks = {
                string_concat_10k_ms: +(Number(t1-t0)/1e6).toFixed(2),
                sort_1k_ms: +(Number(t2-t1)/1e6).toFixed(2),
                env_quality: 'native'
            };
        } catch (_) {}

        try {
            report.sentinel_health = {
                note: 'runtime registry lives inside obfuscated artifacts',
                vault_monitored: true, beats_per_boot: 'GC heartbeat + task.defer',
                scoring: 'weighted (threshold 150)',
                version: 'Sentinel V2 / Skynox Guard V1.1'
            };
        } catch (_) { report.sentinel_health = 'unavailable'; }

        try {
            const wl = [...whitelist].map(String);
            const st = fs.statSync(WHITELIST_FILE);
            report.whitelist_audit = {
                entries: wl.length, ids: wl.map(id => id.slice(0,4)+'...'+id.slice(-4)),
                modified: st.mtime.toISOString(),
                suspicious_patterns: wl.filter(id => /(\d)\1{5,}/.test(id)).length
            };
        } catch (_) {}

        try {
            const logf = path.join(__dirname, 'bot.log');
            if (fs.existsSync(logf)) {
                const lines = fs.readFileSync(logf, 'utf8').split('\n').filter(Boolean);
                const errs = lines.filter(l => l.toLowerCase().includes('error') || l.includes('FAIL'));
                report.error_log_tail = { total_lines: lines.length, error_count: errs.length,
                    last_errors: errs.slice(-5), last_line: lines[lines.length-1] || '' };
            } else report.error_log_tail = 'no log';
        } catch (_) { report.error_log_tail = 'no log'; }

        try {
            const du = execSync('du -sh /luau-obfuscator/ 2>/dev/null').toString().trim().split('\t')[0];
            const tmpDir = config.tempDir;
            const tmpc = fs.existsSync(tmpDir) ? fs.readdirSync(tmpDir).length : 0;
            const df = execSync('df -h / | tail -1 | awk \'{print $4}\'').toString().trim();
            report.disk_usage = { obfuscator_size: du, temp_files: tmpc, disk_free: df };
        } catch (_) { report.disk_usage = 'unavailable'; }

        try {
            const comps = {};
            for (const c of ['lua5.1','lua5.2','lua5.3','lua5.4','luau','luajit']) {
                try { comps[c] = execSync(c+' -v 2>&1',{timeout:2000}).toString().split('\n')[0].slice(0,60); }
                catch(_) { comps[c] = 'not found'; }
            }
            report.lua_compilers_available = comps;
        } catch (_) {}

        report.sandbox_analysis = {
            debug_lib: typeof require('inspector') !== 'undefined' ? 'full' : 'limited',
            io_present: !!process.stdout.fd,
            package_searchpath: !!require.resolve,
            gc_exposed: typeof global.gc === 'function',
        };

        report.hook_detection = {
            charCode_intact: ''.charCodeAt === snap.sc ? '✓' : '⚠️ HOOKED',
            keys_intact: Object.keys === snap.tc ? '✓' : '⚠️ HOOKED',
            math_floor_intact: Math.floor === snap.mf ? '✓' : '⚠️ HOOKED',
        };
        report.global_dump = { key_count: Object.keys(global).length,
            suspicious: Object.keys(global).filter(k => /deobf|dump|hook|spy|trace/i.test(k)) };

        const buf = Buffer.from(JSON.stringify(report, null, 2), 'utf8');
        await message.reply({
            content: `🔍 **Deep Environment Log${sub ? ' ('+sub+')' : ''}** — ${Object.keys(report).length} sections`,
            files: [{ attachment: buf, name: `env_log_${Date.now()}.json` }],
        }).catch(async () => {
            const e2 = new (require('discord.js').EmbedBuilder)();
            e2.setColor(0x00BFFF).setTitle('🔍 Environment Log')
              .setDescription('```json\n' + JSON.stringify(report,null,2).slice(0,3900) + '\n```')
              .setFooter({ text: 'Skynox Obfuscator v2.1' });
            message.reply({ embeds: [e2] }).catch(() => {});
        });
    },

    async tier(message) {
        const tier = getTier(message);
        const embed = {
            color: tier === 'maximum' ? 0xFFD700 : 0x00FF00,
            title: `Your Tier: ${tier.toUpperCase()}`,
            description: tier === 'maximum'
                ? '✅ **Whitelisted** — access to `maximum` (VM paranoid) + `free` (VM medium)\nFree tier: `free` is available to all.'
                : '✅ **Free tier** — access to `free` (VM medium)\n`maximum` is whitelisted only.\nAsk owner for `.whitelist` to unlock `maximum`.',
            footer: { text: 'Skynox | Luau-Obfuscator [FREE+MAX]' }
        };
        await message.reply({ embeds: [embed] });
    },

    async presets(message) {
        const tier = getTier(message);
        const maxIcon = tier === 'maximum' ? '🟢' : '🔒';
        await message.reply(`**Available Presets (Skynox Luau):**\n🟢 **free** — VM medium (renaming · string/number encoding · scrubbing) — available to all\n${maxIcon} **maximum** — VM paranoid (whitelisted only)\n${maxIcon} **maximum log** — maximum + EnvLogger summary\n${maxIcon} **maximum diagnostic** — maximum + EnvLogger diagnostic\n\nUsage: attach \`.lua\`/\`.luau\`/\`.txt\` + \`.obfuscate free\` or \`.obfuscate maximum [log|diagnostic]\``);
    },

    async get(message, args) {
        // support: .get <url> [--pastefy|--upload]  (2 options: pastefy link or direct file)
        let pastefyMode = false;
        let url = args[0];
        // detect --pastefy flag anywhere
        if (args.includes('--pastefy') || args.includes('--upload') || args.includes('pastefy')) {
            pastefyMode = true;
            // remove flag from args to get clean url
            args = args.filter(a => !['--pastefy','--upload','pastefy'].includes(a));
            url = args[0];
        }
        if (!url) url = args.join(' ').trim();
        if (!url || !/^https?:\/\/\S+/i.test(url)) {
            return message.reply('❌ Usage: `.get <url>` — fetches a URL and checks obfuscation.\n` .get <url>` → direct file, ` .get <url> --pastefy` → upload to pastefy + link\nExample: `.get https://pastefy.app/xxxx/raw`').catch(()=>{});
        }
        // basic SSRF protection: block private IPs and file://
        let parsed;
        try { parsed = new URL(url); } catch(_) { return message.reply('❌ Invalid URL.').catch(()=>{}); }
        if (!['http:','https:'].includes(parsed.protocol)) return message.reply('❌ Only http/https allowed.').catch(()=>{});
        const blockedHosts = ['localhost','127.0.0.1','0.0.0.0','::1','10.','192.168.','172.16.','172.17.','172.18.','172.19.','172.20.','172.21.','172.22.','172.23.','172.24.','172.25.','172.26.','172.27.','172.28.','172.29.','172.30.','172.31.'];
        if (blockedHosts.some(h => parsed.hostname === h || parsed.hostname.startsWith(h))) {
            return message.reply('❌ Blocked host.').catch(()=>{});
        }
        const statusMsg = await message.reply(`⏳ Fetching \`${url.slice(0,80)}\`...`).catch(()=>null);
        try {
            const headers = { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36' };
            const controller = new AbortController();
            const timeout = setTimeout(()=>controller.abort(), 15000);
            const res = await fetch(url, { headers, signal: controller.signal, redirect: 'follow' });
            clearTimeout(timeout);
            if (!res.ok) {
                if (statusMsg) await statusMsg.edit(`❌ Fetch failed: ${res.status} ${res.statusText}`).catch(()=>{});
                else await message.reply(`❌ Fetch failed: ${res.status}`).catch(()=>{});
                return;
            }
            const body = await res.text();
            if (body.length > 2 * 1024 * 1024) {
                if (statusMsg) await statusMsg.edit('❌ File too large (>2MB).').catch(()=>{});
                else await message.reply('❌ File too large.').catch(()=>{});
                return;
            }
            // check obfuscation (ported from discordia example)
            function checkObfuscation(content) {
                const signatures = ["Luraph", "IronBrew", "Prometheus", "Moonsec", "Syn_Load", "Aztup"];
                for (const sig of signatures) {
                    if (content.includes(sig)) return [true, sig.toLowerCase()];
                }
                const hexCount = (content.match(/\\x/g) || []).length;
                if (hexCount > 20) return [true, "heavy hex encoding"];
                return [false, "clean"];
            }
            const [isObf, detail] = checkObfuscation(body);
            const status = isObf ? `Obfuscated [${detail}]` : "Not obfuscated";
            const buf = Buffer.from(body, 'utf8');
            // 2 options: pastefy link or direct file
            const MAX_DISCORD = 8 * 1024 * 1024;
            if (pastefyMode || buf.length > MAX_DISCORD) {
                // upload to pastefy
                try {
                    const tmpFile = path.join(config.tempDir, `get_${Date.now()}.txt`);
                    if (!fs.existsSync(config.tempDir)) fs.mkdirSync(config.tempDir, {recursive:true});
                    fs.writeFileSync(tmpFile, buf);
                    const link = await new Promise((res, rej) => {
                        const {execFile} = require('child_process');
                        execFile('curl', ['-s','-F',`f=@${tmpFile}`,'https://pastefy.app/'], {timeout:15000}, (err, stdout)=>{
                            try { fs.unlinkSync(tmpFile); } catch(_){}
                            if (err) return rej(err);
                            res(stdout.toString().trim());
                        });
                    });
                    const content = `✅ Fetched \`${url.slice(0,80)}\`\n**Status:** ${status} (${(buf.length/1024).toFixed(1)}KB)\n📎 Pastefy: ${link || 'upload failed, sending file...'}`;
                    if (link && link.startsWith('http')) {
                        if (statusMsg) await statusMsg.edit(content).catch(()=>{});
                        else await message.reply(content).catch(()=>{});
                    } else {
                        // fallback to file
                        if (buf.length <= MAX_DISCORD) {
                            const file = new AttachmentBuilder(buf, { name: `script_${Date.now()}.txt` });
                            if (statusMsg) await statusMsg.edit({ content, files: [file] }).catch(()=>{});
                            else await message.reply({ content, files: [file] }).catch(()=>{});
                        } else {
                            if (statusMsg) await statusMsg.edit(content).catch(()=>{});
                        }
                    }
                } catch (e) {
                    const file = new AttachmentBuilder(buf, { name: `script_${Date.now()}.txt` });
                    const content = `✅ Fetched \`${url.slice(0,80)}\`\n**Status:** ${status} (${(buf.length/1024).toFixed(1)}KB) (pastefy failed)`;
                    if (statusMsg) await statusMsg.edit({ content, files: [file] }).catch(()=>{});
                    else await message.reply({ content, files: [file] }).catch(()=>{});
                }
            } else {
                // direct file (default)
                const filename = `script_${Date.now()}.txt`;
                const file = new AttachmentBuilder(buf, { name: filename });
                const content = `✅ Fetched \`${url.slice(0,80)}\`\n**Status:** ${status} (${(buf.length/1024).toFixed(1)}KB)\n*Tip: use \`.get <url> --pastefy\` to get a pastefy link*`;
                if (statusMsg) await statusMsg.edit({ content, files: [file] }).catch(()=>{});
                else await message.reply({ content, files: [file] }).catch(()=>{});
            }
        } catch (e) {
            const msg = e.name === 'AbortError' ? 'Timeout fetching URL.' : `Error fetching URL: ${e.message.slice(0,200)}`;
            if (statusMsg) await statusMsg.edit(`❌ ${msg}`).catch(()=>{});
            else await message.reply(`❌ ${msg}`).catch(()=>{});
        }
    },

    async rebuild(message, args) {
        // .rebuild — deobfuscate with spray.lua, supports forwarded (reply)
        let source = null;
        let sourceName = "input.lua";
        const attachment = message.attachments.first();
        if (attachment) {
            if (!attachment.name.toLowerCase().endsWith('.lua') && !attachment.name.toLowerCase().endsWith('.luau') && !attachment.name.toLowerCase().endsWith('.txt')) {
                return message.reply('❌ Only `.lua`/`.luau`/`.txt` supported for rebuild.').catch(()=>{});
            }
            if (attachment.size > 2 * 1024 * 1024) return message.reply('❌ File too large (>2MB).').catch(()=>{});
            try {
                const res = await fetch(attachment.url);
                source = await res.text();
                sourceName = attachment.name;
            } catch(e) { return message.reply(`❌ Failed to download: ${e.message.slice(0,200)}`).catch(()=>{}); }
        } else {
            let forwarded = null;
            try { forwarded = await extractForwardData(message); } catch(_) { forwarded = null; }
            if (forwarded) {
                if (/^https?:\/\//i.test(forwarded)) {
                    try {
                        const headers = { 'User-Agent': 'Mozilla/5.0' };
                        const controller = new AbortController();
                        const t = setTimeout(()=>controller.abort(), 10000);
                        const res = await fetch(forwarded, { headers, signal: controller.signal });
                        clearTimeout(t);
                        if (res.ok) { source = await res.text(); sourceName = `forwarded_${Date.now()}.lua`; }
                        else { source = forwarded; sourceName = `forwarded_${Date.now()}.lua`; }
                    } catch(e) { source = forwarded; sourceName = `forwarded_${Date.now()}.lua`; }
                } else { source = forwarded; sourceName = `forwarded_${Date.now()}.lua`; }
            } else if (args[0] && /^https?:\/\//i.test(args[0])) {
                const url = args[0];
                try {
                    const headers = { 'User-Agent': 'Mozilla/5.0' };
                    const controller = new AbortController();
                    const t = setTimeout(()=>controller.abort(), 10000);
                    const res = await fetch(url, { headers, signal: controller.signal });
                    clearTimeout(t);
                    if (!res.ok) return message.reply(`❌ Fetch failed: ${res.status}`).catch(()=>{});
                    source = await res.text();
                    sourceName = `rebuild_${Date.now()}.lua`;
                    if (source.length > 2*1024*1024) return message.reply('❌ File too large (>2MB).').catch(()=>{});
                } catch(e) { return message.reply(`❌ Fetch failed: ${e.message.slice(0,200)}`).catch(()=>{}); }
            } else {
                try {
                    const store = global.__SKX_LAST_FETCH;
                    const last = store ? store.get(message.author.id) : null;
                    if (last && last.body) { source = last.body; sourceName = `last_get_${Date.now()}.lua`; }
                    else return message.reply('❌ Usage: `.rebuild` with attached `.lua` file, or `.rebuild <url>`, or reply to forwarded file/link, or after `.get` just `.rebuild` (uses last fetched)').catch(()=>{});
                } catch(_){ return message.reply('❌ Usage: `.rebuild` with attached `.lua` file, or `.rebuild <url>`').catch(()=>{}); }
            }
        }
        const tempDir = config.tempDir;
        if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
        const timestamp = Date.now();
        const inputPath = path.join(tempDir, `rebuild_${timestamp}_input.lua`);
        fs.writeFileSync(inputPath, source);
        const statusMsg = await message.reply(`⏳ Rebuilding \`${sourceName}\` with spray.lua...`).catch(()=>null);
        try {
            const { execFile } = require('child_process');
            const sprayPath = require('path').resolve(__dirname, '..', 'spray.lua');
            execFile('lua5.4', [sprayPath, inputPath], { timeout: 120000, maxBuffer: 50 * 1024 * 1024 }, (err, stdout, stderr) => {
                try { fs.unlinkSync(inputPath); } catch(e) {}
                if (err) {
                    const msg = `❌ Rebuild failed: ${(stderr || stdout || err.message || 'unknown').slice(0, 800)}`;
                    if (statusMsg) statusMsg.edit(msg).catch(()=>{});
                    else message.reply(msg).catch(()=>{});
                    return;
                }
                let result = stdout || '';
                if (!result || result.trim().length < 10) {
                    try { result = fs.readFileSync(inputPath, 'utf8'); } catch(_){ result = stderr || 'No output from spray.lua'; }
                }
                const buf = Buffer.from(result, 'utf8');
                const embed = { color: 0x00FF00, title: '✅ Rebuild Complete (spray.lua)', fields: [{ name: 'Source', value: `${sourceName} ${(source.length/1024).toFixed(1)}KB`, inline: true }, { name: 'Rebuilt', value: `${(buf.length/1024).toFixed(1)}KB via spray.lua`, inline: true }, { name: 'Note', value: 'Deobfuscated with spray.lua — garbage stripped, strings decoded, constants cleaned.', inline: false }], footer: { text: 'Skynox Rebuilder • spray.lua' } };
                const MAX_DISCORD = 8 * 1024 * 1024;
                if (buf.length <= MAX_DISCORD) {
                    const file = new AttachmentBuilder(buf, { name: `rebuilt_${sourceName}` });
                    if (statusMsg) statusMsg.edit({ embeds: [embed], files: [file] }).catch(()=>{});
                    else message.reply({ embeds: [embed], files: [file] }).catch(()=>{});
                } else {
                    try {
                        uploadPastefy(inputPath).then(link => {
                            embed.description = `📎 Rebuilt file too large (${(buf.length/1024/1024).toFixed(1)}MB): ${link}`;
                            if (statusMsg) statusMsg.edit({ embeds: [embed] }).catch(()=>{});
                            else message.reply({ embeds: [embed] }).catch(()=>{});
                        }).catch(upErr => {
                            const content = fs.readFileSync(inputPath, 'utf8');
                            const chunkSize = Math.ceil(content.length / 3);
                            const chunks = [];
                            for (let i = 0; i < 3; i++) {
                                chunks.push(content.slice(i * chunkSize, (i + 1) * chunkSize));
                                fs.writeFileSync(inputPath + '.part' + (i+1), chunks[i]);
                            }
                            const files = chunks.map((_, i) => new AttachmentBuilder(inputPath + '.part' + (i+1)));
                            if (statusMsg) statusMsg.edit({ embeds: [embed] }).catch(()=>{});
                            else message.reply({ embeds: [embed] }).catch(()=>{});
                        });
                    } catch (upErr) {
                        const content = fs.readFileSync(inputPath, 'utf8');
                        const chunkSize = Math.ceil(content.length / 3);
                        const chunks = [];
                        for (let i = 0; i < 3; i++) {
                            chunks.push(content.slice(i * chunkSize, (i + 1) * chunkSize));
                            fs.writeFileSync(inputPath + '.part' + (i+1), chunks[i]);
                        }
                        const files = chunks.map((_, i) => new AttachmentBuilder(inputPath + '.part' + (i+1)));
                        if (statusMsg) statusMsg.edit({ embeds: [embed] }).catch(()=>{});
                        else message.reply({ embeds: [embed] }).catch(()=>{});
                    }
                }
            });
        } catch (e) {
            const msg = `❌ Rebuild failed: ${e.message.slice(0,800)}`;
            if (statusMsg) await statusMsg.edit(msg).catch(()=>{});
            else await message.reply(msg).catch(()=>{});
        }
    },

    async obfuscate(message, args) {
        let sourceType = null;
        let sourceUrl = null;
        let attachment = message.attachments.first();
        let sourceName = null;
        let sourceSize = null;

        if (attachment) {
            sourceType = 'attachment';
            sourceUrl = attachment.url;
            sourceName = attachment.name;
            sourceSize = attachment.size;
        } else {
            const url = message.referencedMessage?.attachments?.first()?.url
                || (message.referencedMessage?.content && extractUrl(message.referencedMessage.content))
                || (message.content && extractUrl(message.content));
            if (!url) {
                return message.reply('❌ Attach a `.lua` / `.luau` / `.txt` file or provide a link and run `.obfuscate <preset>`\nUsage: `.obfuscate free <url>` or `.obfuscate maximum <url>`');
            }
            const urlPath = new URL(url).pathname;
            sourceName = urlPath.split('/').pop() || 'downloaded.lua';
            if (!sourceName) sourceName = 'downloaded.lua';
            const urlExt = path.extname(sourceName).toLowerCase();
            if (!['.lua', '.luau', '.txt'].includes(urlExt)) sourceName = sourceName + '.lua';
            const [body, err] = await handleInputLink(message);
            if (err) return message.reply(err);
            if (!body) return message.reply('❌ Could not extract a URL from the message.');
            const buf = Buffer.from(body, 'utf8');
            if (buf.length > config.maxFileSizeMB * 1024 * 1024) {
                return message.reply(`❌ File too large. Max: ${config.maxFileSizeMB}MB`);
            }
            sourceType = 'url';
            sourceUrl = url;
            const tempDir = config.tempDir;
            if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
            const timestamp = Date.now();
            const userId = message.author.id;
            const ext = '.lua';
            const inputPath = path.join(tempDir, `${userId}_${timestamp}_input${ext}`);
            const fixedBody = fixTrailingEnd(body);
            fs.writeFileSync(inputPath, Buffer.from(fixedBody || body, 'utf8'));
            const lowerName = sourceName.toLowerCase();
            if (!['.lua', '.luau', '.txt'].some(e => lowerName.endsWith(e))) {
                return message.reply('❌ Only `.lua` / `.luau` / `.txt` files are supported.');
            }
            let preset = (args[0] || 'free').toLowerCase();
        let pastefyMode = args.includes('--pastefy') || args.includes('-p');
        if (pastefyMode) args = args.filter(a => !['--pastefy','-p'].includes(a));
            let loggerMode = null;
            if (!['maximum','free'].includes(preset)) {
                if (['log','summary','diagnostic'].includes(preset)) {
                    loggerMode = preset === 'log' ? 'summary' : preset;
                    preset = 'free';
                } else {
                    return message.reply(`❌ Unknown preset \`${preset}\`. Use: \`.obfuscate free\` or \`.obfuscate maximum\` (or \`.obfuscate maximum log\`)`);
                }
            }
            let loggerMode2 = null;
            if (args[1] && ['log','summary','diagnostic'].includes(args[1].toLowerCase())) {
                loggerMode2 = args[1].toLowerCase() === 'log' ? 'summary' : args[1].toLowerCase();
            }
            if (!loggerMode && loggerMode2) loggerMode = loggerMode2;
            const validPresets = ['maximum','free'];
            if (!validPresets.includes(preset)) {
                return message.reply(`❌ Use: \`.obfuscate free\` (medium, free) or \`.obfuscate maximum\` (whitelisted)`);
            }
            const tier = getTier(message);
            if (preset === 'maximum' && tier !== 'maximum') {
                return message.reply(`🔒 \`maximum\` is **whitelisted only**.\nYour tier: \`${tier}\`\nFree tier: \`.obfuscate free\` is available to all. Ask owner for \`.whitelist\`.`);
            }
            if (loggerMode && tier !== 'maximum') {
                return message.reply(`🔒 Logger (\`log\`/\`diagnostic\`) requires whitelisted tier (\`maximum\`). Free tier: \`.obfuscate free\``);
            }
            if (preset === 'free' && loggerMode) {
                return message.reply(`❌ \`free\` does not support \`log\`. Use: \`.obfuscate free\` or \`.obfuscate maximum log\``);
            }
            const displayPreset = preset + (loggerMode ? `+${loggerMode}` : '');
            const statusMsg = await message.reply(`⏳ Obfuscating \`${sourceName}\` with \`${displayPreset}\` preset...`);
            const originalExt = path.extname(sourceName);
            const outputName = `obfuscated_${originalExt.toLowerCase() === '.txt' ? sourceName.replace(/\.txt$/i, '.lua') : sourceName}`;
            obfuscate(inputPath, preset, loggerMode, async (err, outputPath, log) => {
                try { fs.unlinkSync(inputPath); } catch(e) {}
                if (err) {
                    statusMsg.edit(`❌ Obfuscation failed:\n\`\`\`\n${err.message.slice(0, 800)}\n\`\`\``);
                    return;
                }
                const stats = fs.statSync(outputPath);
                const embed = {
                    color: 0x00FF00,
                    title: '✅ Obfuscation Complete',
                    fields: [
                        { name: 'Preset', value: preset + (loggerMode ? `+${loggerMode}` : ''), inline: true },
                        { name: 'Original', value: `${sourceSize || stats.size} bytes`, inline: true },
                        { name: 'Output', value: `${stats.size} bytes`, inline: true },
                        { name: 'Layers', value: getLayerInfo(preset, loggerMode), inline: false }
                    ],
                    footer: { text: 'Skynox Obfuscator — Luau Edition' }
                };
                const MAX_DISCORD = 8 * 1024 * 1024;
                if (pastefyMode || stats.size > MAX_DISCORD) {
                    try {
                        const link = await uploadPastefy(outputPath);
                        embed.description = `📎 Uploaded to pastefy.app: ${link}`;
                        await statusMsg.edit({ embeds: [embed] });
                    } catch (upErr) {
                        const file = new AttachmentBuilder(outputPath, { name: outputName });
                        await statusMsg.edit({ embeds: [embed], files: [file] });
                    }
                } else {
                    const file = new AttachmentBuilder(outputPath, { name: outputName });
                    await statusMsg.edit({ embeds: [embed], files: [file] });
                }
setTimeout(() => { try { fs.unlinkSync(outputPath); } catch(e) {} }, 300000);
            });
            return;
        }

        let preset = (args[0] || 'free').toLowerCase();
        let pastefyMode = args.includes('--pastefy') || args.includes('-p');
        if (pastefyMode) args = args.filter(a => !['--pastefy','-p'].includes(a));
        let loggerMode = null;
        if (!['maximum','free'].includes(preset)) {
            if (['log','summary','diagnostic'].includes(preset)) {
                loggerMode = preset === 'log' ? 'summary' : preset;
                preset = 'free';
            } else {
                return message.reply(`❌ Unknown preset \`${preset}\`. Use: \`.obfuscate free\` or \`.obfuscate maximum\` (or \`.obfuscate maximum log\`)`);
            }
        }
        let loggerMode2 = null;
        if (args[1] && ['log','summary','diagnostic'].includes(args[1].toLowerCase())) {
            loggerMode2 = args[1].toLowerCase() === 'log' ? 'summary' : args[1].toLowerCase();
        }
        if (!loggerMode && loggerMode2) loggerMode = loggerMode2;
        const validPresets = ['maximum','free'];
        if (!validPresets.includes(preset)) {
            return message.reply(`❌ Use: \`.obfuscate free\` (medium, free) or \`.obfuscate maximum\` (whitelisted)`);
        }
        const tier = getTier(message);
        if (preset === 'maximum' && tier !== 'maximum') {
            return message.reply(`🔒 \`maximum\` is **whitelisted only**.\nYour tier: \`${tier}\`\nFree tier: \`.obfuscate free\` is available to all. Ask owner for \`.whitelist\`.`);
        }
        if (loggerMode && tier !== 'maximum') {
            return message.reply(`🔒 Logger (\`log\`/\`diagnostic\`) requires whitelisted tier (\`maximum\`). Free tier: \`.obfuscate free\``);
        }
        if (preset === 'free' && loggerMode) {
            return message.reply(`❌ \`free\` does not support \`log\`. Use: \`.obfuscate free\` or \`.obfuscate maximum log\``);
        }

        const lowerName = sourceName.toLowerCase();
        if (!['.lua', '.luau', '.txt'].some(e => lowerName.endsWith(e))) {
            return message.reply('❌ Only `.lua` / `.luau` / `.txt` files are supported.');
        }

        const tempDir = config.tempDir;
        if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
        const timestamp = Date.now();
        const userId = message.author.id;
        const originalExt = path.extname(sourceName);
        const ext = originalExt.toLowerCase() === '.txt' ? '.lua' : originalExt;
        const inputPath = path.join(tempDir, `${userId}_${timestamp}_input${ext}`);

        try {
            const res = await fetch(sourceUrl);
            const bodyText = await res.text();
            const fixedText = fixTrailingEnd(bodyText);
            const buf = Buffer.from(fixedText || bodyText, 'utf8');
            fs.writeFileSync(inputPath, buf);
        } catch (err) {
            return message.reply('❌ Failed to download file.');
        }

        const displayPreset = preset + (loggerMode ? `+${loggerMode}` : '');
        const statusMsg = await message.reply(`⏳ Obfuscating \`${sourceName}\` with \`${displayPreset}\` preset...`);
        const outputName = `obfuscated_${originalExt.toLowerCase() === '.txt' ? sourceName.replace(/\.txt$/i, '.lua') : sourceName}`;
        obfuscate(inputPath, preset, loggerMode, async (err, outputPath, log) => {
            try { fs.unlinkSync(inputPath); } catch(e) {}
            if (err) {
                statusMsg.edit(`❌ Obfuscation failed:\n\`\`\`\n${err.message.slice(0, 800)}\n\`\`\``);
                return;
            }
            const stats = fs.statSync(outputPath);
            const embed = {
                color: 0x00FF00,
                title: '✅ Obfuscation Complete',
                fields: [
                    { name: 'Preset', value: preset + (loggerMode ? `+${loggerMode}` : ''), inline: true },
                    { name: 'Original', value: `${sourceSize} bytes`, inline: true },
                    { name: 'Output', value: `${stats.size} bytes`, inline: true },
                    { name: 'Layers', value: getLayerInfo(preset, loggerMode), inline: false }
                ],
                footer: { text: 'Skynox Obfuscator — Luau Edition' }
            };
            const MAX_DISCORD = 8 * 1024 * 1024;
            if (stats.size <= MAX_DISCORD) {
                const file = new AttachmentBuilder(outputPath, { name: outputName });
                await statusMsg.edit({ embeds: [embed], files: [file] });
            } else {
                try {
                    const link = await uploadPastefy(outputPath);
                    embed.description = `📎 File too large for Discord (${(stats.size/1024/1024).toFixed(1)}MB).\nDownload: ${link}`;
                    await statusMsg.edit({ embeds: [embed] });
                } catch (upErr) {
                    const content = fs.readFileSync(outputPath, 'utf8');
                    const chunkSize = Math.ceil(content.length / 3);
                    const chunks = [];
                    for (let i = 0; i < 3; i++) {
                        chunks.push(content.slice(i * chunkSize, (i + 1) * chunkSize));
                        fs.writeFileSync(outputPath + '.part' + (i+1), chunks[i]);
                    }
                    const files = chunks.map((_, i) => new AttachmentBuilder(outputPath + '.part' + (i+1)));
                    await statusMsg.edit({ embeds: [embed] });
                }
            }
            setTimeout(() => { try { fs.unlinkSync(outputPath); } catch(e) {} }, 300000);
            });
    }
};

function getLayerInfo(preset, loggerMode) {
    if (preset === 'free') {
        return 'VM Medium · Renaming · String/Number Encoding · Scrubbing [FREE]';
    }
    const base = 'VM Paranoid · Whitening · Scrubbing · Reseal Watchdog · Canary · Full Protections [MAXIMUM ONLY]';
    if (loggerMode === 'diagnostic') return base + ' + EnvLogger diagnostic (global aggregation, hashed)';
    if (loggerMode) return base + ' + EnvLogger summary';
    return base;
}

// ─── Message handler ─────────────────────────────────────────────────────────
client.on('messageCreate', async (message) => {
    if (message.author.bot) return;
    if (!message.content.startsWith(config.prefix)) return;

    const args = message.content.slice(config.prefix.length).trim().split(/\s+/);
    const command = args.shift().toLowerCase();

    if (commands[command]) {
        try {
            await commands[command](message, args);
        } catch (err) {
            console.error(`Command ${command} error:`, err);
            message.reply('❌ An error occurred.').catch(() => {});
        }
    }
});

client.on('clientReady', () => {
    console.log(`✅ Skynox Bot online as ${client.user.tag} (Luau-Obfuscator)`);
    client.user.setActivity('protecting Lua/Luau | .help');
});
// compat for older discord.js
client.on('ready', () => {
    console.log(`✅ Skynox Bot online as ${client.user.tag} (Luau-Obfuscator)`);
});

process.on('unhandledRejection', console.error);

if (process.env.HERCULES_API_TOKEN) {
  require('./api.js');
  console.log('[api] REST interface enabled');
}

if (!config.token || config.token.includes("PUT_")) {
    console.error("[FATAL] No Discord token - set DISCORD_TOKEN env var or config.json");
} else {
    client.login(config.token).catch(e=>console.error("[LOGIN FAIL]",e.message));
}
