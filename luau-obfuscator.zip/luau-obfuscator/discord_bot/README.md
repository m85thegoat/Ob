# Skynox Obfuscator Discord Bot — Luau Edition

## Setup
1. `npm install`
2. Edit `config.json` — paste your bot token + owner ID
3. Invite the bot with `Message Content` intent enabled
4. Create a role called `Premium` for paying users (or use `.whitelist`)
5. Run: `node bot.js`  (or `pm2 start bot.js --name skynox-bot`)

## Config
- `token` — Discord bot token (prefer `DISCORD_TOKEN` env var in production)
- `obfuscatorPath` — absolute path to `Obfuscator.lua` (`/luau-obfuscator/Obfuscator.lua`)
- `tempDir` — temp folder for uploads (`/tmp/skynox_bot`)
- `premiumChannelId` / `freeChannelId` — channel-based tier overrides

## Commands (MAXIMUM ONLY — whitelisted)
| Command | Description | Tier |
|---|---|---|
| `.obfuscate maximum` | VM paranoid · whitening · scrubbing · reseal watchdog | 🔒 Whitelisted only |
| `.help` | Show help | Everyone |
| `.tier` | Check your tier | Everyone |
| `.presets` | List presets | Everyone |
| `.whitelist @user` | Owner: grant maximum | Owner |

## Usage
1. Upload a `.lua` / `.luau` file
2. Type `.obfuscate maximum` (only whitelisted users)
3. Bot returns `obfuscated_<name>` or `.obf.lua`

## Requirements
- Node.js 18+
- `lua5.4` on host (`which lua5.4`)
- Skynox at `../Obfuscator.lua` (tested 166 PASS on lua5.4 + luajit)

## Hosting
```bash
cd /luau-obfuscator/discord_bot
npm install
# foreground
node bot.js
# background
nohup node bot.js > bot.log 2>&1 &
# pm2
npm i -g pm2
pm2 start bot.js --name skynox-bot
pm2 logs skynox-bot
```

REST API (optional): `HERCULES_API_TOKEN=... PORT=8080 node api.js`
