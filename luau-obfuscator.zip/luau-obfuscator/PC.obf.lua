__SKX_GARBAGE_1="\xb7\xca@E2q,\xe2\x1c\x85\xdfFE\xdfUd\xb4\xd3\x1e\xc5\x17\x16\xb6\xb2\xb7\xef\xbbj!\x91e\xcc&K\xbd\xfa\xa3W7\x81\x10\xfe\x85\xe9\xc9\x9e\xa6\xb8\xbc\xb4\x16\xafu\x9d\xac.\xea\x92)\x0c/|\x19w\x14\xb6\x89\xeff\x11\xdd\xe0d\xfb\xdf\xba\xd7\xfb\x1d\x08K\x1c\xf7\x03\xf5|\x99\xa7\xca\xbc\xce\x8ak\x96\x18\xb2F.\xb4U\x82\xc6\x1e\xec^\xc8<0L\xf6\x89;O:<\xa6\xeearyp7s\x95$Z\x18T\r\xed\x8d#\xff\x08>\xc3IF5\x9f\x01\xb2z\xd9\xf2\x0e\x10\x96\x93\xf7\x93\xbc'\x07\xdd\x16\xe6\x9644:Az\x16\x06:\xd5\xea\xae\x9b\x17\x92\xc0F\x06"
__SKX_GARBAGE_2="w\xe4O\xe1\x84\xd8'\x8f\xf5\x08l\x90Jg\xd9Y\xde\xa4\xc0\xe7t\xf2}o=\x1cA\xe56`$\x00\xdd\\#nipX\nt\x15\xe3\xb2\x19\xa8Xw\x93[\xbc\x8d[\xe4h\xd3\xe2\xf9\xbf+{\xa6xVj\xb7\xa4cWS\xd5I|\xde>m\x80JA\xe2X\x1dS\xf8\xe8\x83\xf9\xe8\xf6\xe6\x10\x1asH\xa0t\x1fCr\xff\n~.H\xe6\xe0{\x9e\x9a\xd8\xdf\xa4)Y\x0e\xa8#\xd7!\x9646Q\xd8I\x98\xd2\x1e\xa1\x8e\x91\xa5mP\xf9\x8d\xb9b=?\xb1\xb2\xbe{u\xd1!8!\x87\x1fn\x7f2w\xd7Y\n\xf7g\x91\x90\\.@\x83\x16ff-)\xd8,\xd6\xb6M\xe9\x99\x15J\x96\xdb>\xf6N\xb4Z\xeb*XI[\xdaW]h\tY\x87\xdd\xf6G\xfb\x83\x94\xa1GxCV_\"\x13\x08\x0b\xf7\x00\x93\xd0@\xdd\xd5\xb8i\x15'\xf8UI\x13\x84\xe2\x10\xb7\x90Ie\x0e]\xcb\xda~D\x9fi\xbdy\xbb\xfc\x1f\x83.\xd3^\xcc/\xc12\x8cW\x90S\x0bo\xce\x93vm\x7f\x89\x05\xa0u\xbb\x95\x84\x05\xd7oE\x18\xf5vO\xf5\xee\xba\xe4\x84R\x9dun\x0b\x97\n\x8dc`\x91b\xcd\x84kn\xf2\x99>\r*\x0e\xceP\xd1\xb8^,\x15!\x1d\xed\xb3\xc4\xa8\x0f\xd4\x10\xc65\xf1\xea\xef@)Q\x18\x89\xd3l\x8c\n\n\xe3s\x89\xc6\xf6P\x03}#4v\rX\xbf\xf9\xc5\xd2e9\x84\x99\x19\x91"
__SKX_GARBAGE_3="\xfe\xa0m\x1d\xfa\xae\xa9\xac\xb0\xc3\xa48u:\x11L\x8b\x9a2\xdd\xd0\x9fV\xbf\xf6\xf7\x83 \xb0\x9e::\xf3\x99\x8fS\xfc\xe1\xc2\xc6\xa8C\xfd\xdb\x8f\xc4\xdc\xcbrl\xc4=\x1f8\xca\xb3\x7f\x9dO\xd55\x96g\x93\xd7\x0f\x81\x16\x9f\x10j\xcf\xc5\xde\xd2\xfaS~\x0f\xad\xc6\xa6\x8a\xf4\xffo\x1f\xe8i\x8f\xe0\x000\x0b\xa9\xd6\x89\x88M\xb93\x1f\xea1\xcf\nB\x01#\x96\x00\xcfy\xc3\xac\xb6\xe1\x10b:o\x1cn\xf0\xc2\xa3q\xd1\x8e\xc4&9\xc6\x0c \x83\xb7\xb2\xcf\x1eH\xbc>\xf1\xb6=)T\x99\x07\xec\xa7\xee\xc4\xf9\x02\xc1\x81\xc7\x87\r\xc0\x85\xec\xaeyqr\x80_\x05\x8a\x91\xcfcT\xa0&0@-Y_\xe2d\x86$\xff\xcc\x86\xe7\t6\x18\x80\x99\x12\x86\x1b\xeeo\xcb\\\xb1e\xa3\xd8-\x02I"
__SKX_GARBAGE_4="\x9cA\xc7\xa9\xe3\x8e}\xadS:\x13Zp=KEAr&;\x16\x1e{aWn\xe6Q-\xe7!\xee\xb2\x95\xd4\xf2\xedw\xaf\x17c3\x04\x01\xf0=\x19&\xb2\xba\xd7x\xae\x9d`I\xa0\xf1\x05^\x81\xab\x97\xd77\xee\xdc\xe6\x9e\xc4\t\xeei\xcd\xab\xbc\xd3\xbf\xe0Z\xed\x7f\xab\xee\xbd\xc41x\x88\xe6\x1as\x19\xa8\x06O\n\x11E\x94,\xf6\x86W\x81\x12Mp/\x1d\x11^i\xd5\xd4\xcfj\x06D+S$\x1a\x05y\xc2\xb6\xf9s\x0f\xc4\xf8y0\xd8p\xaa\xf2mv\x13\x1dRF<\xc3\xe7\x12N\xa9\xbe\"\xa5\x84\xa5\xca`\x8b\xfdh\x9c\xc4\x8e\xe3\xe8P\x06h\xa7\xad\xd68tX\x88\xe1\x82c\xe5\xcd9'\x82\xf3\x9d\xe7\xadZ\x80Oy\xbf\x0b\xadRNb\xb2\xf3\x1a\xe2\x86\xb0*n\xff\x88\xb5@\xb6\xf3\x8e\xf8\x15\x89f-q\nO\xce\x8e\xae\xebe\xeb\xe0\xcc\xf6\xdf\xba\xeeG h\x7f\x88R\x1f\xf9\x13\xeb\xae\x00\xbc\x95\x1b\x10\xd1\x01\x875\xaa\xbf\xc3\xd4u\x1b\x02\xd2,_\x90\xe9\x1e\xd2\x9c\xd9\xc7\xad\xccS\xa6\xee\xfc\xa6\xbe\xb4v[\x8d\xc3\xc0\x1f\xc8\xc8-X\x16\xbd\x0c\x7f\x90\xf1\xc4y\rY\xb8\xe9Fx\xa9\xc7\xc9\xedf\xcd\xdd8\xfb\xf3\x96%DJV\xf0\xb2'F\xc7\xec\x90x^\xee\xe0\xcc\x87v\xcd\xf2\xaa\xfb\xae\x1f\x8f\x83q\x0e\x1b\xbc\xf7\x89\xda\x19\x160\xf7\xbe\x88\x12\xbbR>U\x16\x0c\x9e\xe1\xa2\xacl\r\x8c\x88\xe5\xdb\xd8ZBK\xa5Z\x86\xfd\xb6\xf6\xc1V\x90\n+\xff\x1b\xac\xdc_\x9a\xf0\x1c*\x9dX\xa7\x90j<\xec\xb89w\x16\x9c\xee\xb6[\x98>\xef\xd2\xa4\xad\xbf\xb1h\xae)\x98\xa9/>\xa9\xc8N\x85\xbcQ]4V\xa7]r\xd2Q&3ae\xc6K\xd7^\x0c\xbf4\xf0\x97P\xe8\x06\x9e\x10'\xfb\x1f]\x14y\x89\xbd\x7fn\x83\xe0\xd9\xe3.K\xc7\xdcz\x91X\x7fV\xc5RJC\xcap\xef\xb6s\xb5\xd3\xbe\xaak\xb6hQ"
__SKX_GARBAGE_5="h]\x82\x19\x83-&\x04=\xca`E\x8c,\xad#\xfce\xd2\x16N\xa3\xff\xe0\xb2oG\xcd\x07[\x08\xc0F0\x87\xa8j\x18\xd3\xd8S\xb7\x0e\x94\x926\xc6R\xc9\xca\n\xe3\x8aE\xec\xda\x08[\xe9\xd7\xa3\xbb\xa6\x1bZ\xb7Y\xbc\x9b\xafk@\x14\xbd\x05\x99\x08D\x9d\x91\xa5\x02\x9b\xfe\x10\x94\x15\xc2_\x00\x7f\xa6&\xcdb\xabc2\xde\x9c\xa3\xb22\x80nz\x85\xb5\x8bi\x1cE\x18\x16\x0c\xf9\xf4L-C\x15U\x9akD\x06\x1d\r)\n$\xb4\xd8\xa2\xb6e\xec\xcb\x1d\xe3\x0f\x85Wl\x90\xb7L\x83\xae\xbf\xa2\xaen\xd6rN\xa5\xb8\xae\xd7\x06\xf2\x92\xf8\x84\xfd\xeeL\xf7\xa4\x9c<\xf5P\x03\xb1|G\xbb\xbc\x02N\x16\x051.\xf4k\xb3UN\xb0\xf2\xb2\x81;\r\x84c\x0b\xf7\xad0It\x1d\xa8\";\xa4{\x04\xaf_\xb4\x12\x18[\xcd\x91\xc7^\xe39\x9d\xab\xf2s\xe5\xe6\xc8\x1e\xc3\xd8\x9e\n\xbe\xe5\x02\x8a'\x95b\xd7\x96\xe8\xd8\xce\x91\x80\xe1m\x98\t\xcej[\x956\x1b\xc4I\xd1\xe9\xdf\xbc'\x06\xdbCB\x13\xee\xfa\xfe\x06A\xe8\x0c\x9d\xf7\x11\r\x80\xc0\xa5\x84P\xcc\xfb\xc5\xb7\xc70F\x0b\x0fW\x18\xdc\x06/\xee\xafY5\xb3\\\xbe\x91\xfc\x18\x7f\x83\x9a\xc2\xf3\x10M\x93i\"\xed\xd4\x96b|G\x08\xda\x1e\x1a\xf9\xc6J\xf8\x17\xfc^$\x86\xab\xf9P\xca\xc3b(\xe7\\\xcab\xd6:\xb4\x1b?RC`%\xdd\x1f\x04^$\x06s}\xfb\x05\xe5\x9e\xa9\x92v\xa57\\\x9d\xcd\xa8\xfa\xcf\x11\x0e%\x10;\x01|\x9c\xaf&\xd8K\xb1\x0cn<\xec|\xe8A7"
__SKX_FAKE="\xf7\x80\x17T\x10\x89\xc3p\xd0\\3\xcc\x93\xcf\x1c\xbb4\xa9\xb4\xdc\xdb\xc9\x97\x8f\x11\xbb\xe0h\x98n\x16\xc1\"\xc84\xcf\xfdgX~\x82\x90}\x9e\x08d\x04\x8aMOKq\xa4\xbc\x8ah\xc6jAB\xde\xf7*\xac\x1b\xfc\x8f\x01<\x13Eg\x0e\x9a\x1f\xdf@\xd0\x03P\x16N\\\x82Vh\x95\xbb\x9c]\xb6\xa7n\x00=\xd6O\x95\xees\xda-K\x9a}\xe7\"\xb4B\xe23\x10\x86\xb8\xe1\x90\x0eV4\x969\xdbge\x97#\xbfHD\xc4S72(q\xb9\x1e\x8f\x8c\x8a\xc6\xcb\x92\x19[&\xec\xbd\x05+\xb8\x8c8\x8e\xb7)\xe3F&\x04et\x1c\x85\xf7\xec\x13\x06\r\xec\x1ad\x91vjy\x91\xb1w\xfc\r\xe8\xb1cpv`-cv\xf8G\x01&\x91sZ\xe9B\x8fyW\x9bH\x98-\xc4\x8a\xfc\xb77\"\xfdVz\x80b\xd7\xf0\xb5\x97\xdb*\xdeI\xd1\x9dJ\x95Z\xc9kJ\x04\x80\xd5-\xd1#\xa9V\xaeer\xb5\x02\xb1\x9b\xff\x10}{\x8f\xbay\x18|\x950\xadj\xe6\xa2\n\xc9\x97Q\xe7t"
__SKX_FAKE_KEY=291685146
local __SKX_SEG_2="\x8dG\xfbl5f\x14\x88\xa3B\x7f$\xf91\x12&\xfc\xe5+\xd6\x9eW,\xa0\xb5y\x94\x9f@\xdei\x0c\x03\x85\x88\xf9"
local __SKX_SEG_3="\x98\xb5\xe0\x98\xb6\xca\x0c\t\x97\x8bI\xf4\x1df\xdbG\xa9'a)\xb5\r2\x9c\xd0\x0f{H<\xce\xd5Y\x03\xdc\xbd"
local __SKX_SEG_1="\x82I\xea\xb1\x1fLpd\xbf\x99\xa7]\xd4-*D.\xe4\xfc\xe7\xfc\xbcLAr\x07\xf5\x17p\xca\xc1\xbb\xfc# \x82"
local __SKX_SEG={__SKX_SEG_1,__SKX_SEG_2,__SKX_SEG_3}
local _SBI_enc={5,91,129,211,83,105,36,91,38,187,188,216,173,238,121,2,143,128,179,216,230,188,49,130,217,86,84,249,94,151,227,84,74,107,233,48,82,246,30,119,121,145,13,162,231,9,116,5,222,195,130,149,28,158,218,251,121,172,214,8,43,83,170,124,110,213,116,97,166,1,104,181,224,236,43,71,24,225,61,43,130,68,21,116,114,66,86,131,90,33,190,140,39,145,23,215,74,189,206,105,10,192,12,181,101,167,185,133,0,242,152,42,62,242,38,164,192,164,152,10,45,166,17,86,41,86,91,225,191,179,113,68,81,79,244,105,31,149,41,30,145,145,135,169,251,10,254,249,79,76,65,158,111,230,38,171,46,22,25,238,48,233,255,210,222,44,194,25,24,228,48,234,61,186,69,162,53,103,182,239,144,158,1,195,100,88,229,55,136,205,16,137,38,123,43,150,252,187,227,190,229,30,7,90,243,123,62,32,54,84,125,16,133,201,7,250,16,94,69,190,109,154,36,248,48,19,47,74,14,158,220,197,200,57,19,137,46,243,165,36,198,154,147,121,170,132,143,163,251,171,238,142,40,64,147,69}
local _SBI_key=195
local _SBI={} local _49c4peOOU52={} for i=1,256 do local v=_SBI_enc[i] v=(v - _SBI_key - i*7)%256 _SBI[i]=v _49c4peOOU52[i]=v end _SBI_enc=nil _SBI_key=nil
local __skx_msg_key=29
local __skx_msg_enc={105,140,137,61,145,143,150,134,139,132,61,145,140,61,97,130,140,127,131,146,144,128,126,145,130,61,140,143,61,98,139,147,61,105,140,132,61,145,143,150,61,127,130,145,145,130,143,61,137,146,128,136,61,139,130,149,145,61,145,134,138,130}
local __skx_message=(function() local t={} for i=1,#__skx_msg_enc do t[i]=string.char((__skx_msg_enc[i]-__skx_msg_key)%256) end return table.concat(t) end)()
local __skx_guard_seed=1853727016
local __skx_scan_a=1915897629
local __skx_scan_b=339245276
local __skx_env_digest=284694554
local __skx_env_signatures={{11,4119751156,3865368271},{8,234917171,201597482},{9,4082781235,1372535228},{10,81897818,3345065797},{6,984519274,2731401453},{4,3792473602,827840105},{6,3661717065,4225633444},{8,2452701285,1901658820},{8,1456820315,1021110866},{7,737806848,984068995},{9,1536624489,673825454},{8,3156119931,565548526},{5,1031442425,2355332158},{5,1451690540,1398940431},{6,4211799870,3460694945},{4,1663046643,3177322998},{4,1956900652,2261155855},{5,609681416,4241500155},{6,842343010,1214980225},{8,1754065901,3681929160},{14,2283390636,1652240823},{12,2848254497,3352837864},{8,2376511217,2375431568},{12,1108868456,3137042051},{11,1463160203,688707868},{15,1057253545,3865762134},{5,3658751633,3604712658},{7,2820001047,1759404988},{7,2820001047,1759404988},{12,1843773,1422259144},{16,485526019,3475962754},{15,342241702,765801081},{8,1897095275,4213542014},{9,427836872,1128521003},{15,2836435446,3427439917},{7,729775194,2313407865},{10,2664957089,1399934048},{17,678980287,2376259576},{16,1635810093,153990356},{7,1006029571,2626897896},{10,1140982099,2954514074},{11,791135584,871119891},{12,844084502,3033704113},{14,3008277574,706913593},{16,3893866732,3414873895},{10,1798718539,3151581706},{17,3528259425,2976648394},{10,2035353804,3065267623},{10,1087272399,1721641322},{11,3313912071,2303918556},{12,2550131451,184196454},{11,1359947679,353155488},{11,2369292673,1315624358},{10,374873055,2618961694},{3,2716246341,2082045034},{6,3106458603,1891868438},{17,3057100542,1791666993},{17,2684116354,2127219373},{17,4027231265,2517495618},{10,950874109,2005607452},{6,2500863747,1130276046},{7,745591561,1493294474},{8,1452868562,3385604637},{9,421553138,3925471665},{17,4246384382,1719997541},{19,4187327482,2091402029},{19,1165379653,1858730350}}
local __skx_type0=type
local __skx_pcall0=pcall
local __skx_error0=error
local __skx_print0=print
local __skx_rawget0=rawget
local __skx_next0=next
local __skx_pairs0=pairs
local __skx_ipairs0=ipairs
local __skx_select0=select
local __skx_tostring0=tostring
local __skx_tonumber0=tonumber
local __skx_rawequal0=rawequal
local __skx_getmetatable0=getmetatable
local __skx_setmetatable0=setmetatable
local __skx_getfenv0=getfenv
local __skx_string0=string
local __skx_math0=math
local __skx_table0=table
local __skx_byte0=__skx_string0 and __skx_string0.byte
local __skx_char0=__skx_string0 and __skx_string0.char
local __skx_sub0=__skx_string0 and __skx_string0.sub
local __skx_gmatch0=__skx_string0 and __skx_string0.gmatch
local __skx_format0=__skx_string0 and __skx_string0.format
local __skx_concat0=__skx_table0 and __skx_table0.concat
local __skx_unpack0=(unpack or (__skx_table0 and __skx_table0.unpack))
local __skx_floor0=__skx_math0 and __skx_math0.floor
local __skx_ceil0=__skx_math0 and __skx_math0.ceil
local __skx_max0=__skx_math0 and __skx_math0.max
local __skx_tointeger0=__skx_math0 and __skx_math0.tointeger
local __skx_load0=load
local __skx_loadstring0=loadstring
local __skx_debug0=debug
local __skx_gethook0=__skx_debug0 and __skx_debug0.gethook
local __skx_getinfo0=__skx_debug0 and __skx_debug0.getinfo
do
  local _reg0 = __skx_debug0 and __skx_debug0.getregistry and __skx_debug0.getregistry()
  if _reg0 then
    local orig = rawget(_reg0, "__skx_leaker_orig_getfenv")
    if __skx_type0(orig)=="function" then __skx_getfenv0 = orig end
    local dbg0 = rawget(_reg0, "__skx_leaker_orig_debug")
    if __skx_type0(dbg0)=="table" then __skx_debug0 = dbg0 end
  end
end
local __skx_env
if __skx_type0(__skx_getfenv0)=="function" then
  local ok,value=__skx_pcall0(__skx_getfenv0,0)
  if ok and __skx_type0(value)=="table" then
    if rawget(value,"_G") and __skx_type0(rawget(value,"_G"))=="table" and next(value)==nil then
      __skx_env=_G
    else
      __skx_env=value
    end
  end
end
if __skx_type0(__skx_env)~="table" and __skx_type0(_ENV)=="table" then
  __skx_env=_ENV
end
if __skx_type0(__skx_env)~="table" then __skx_env=_G end
if __skx_env~=nil and __skx_env~= _G and rawget(_G,"__SKX_LEAKER_GUARD_ACTIVE") then
  if __skx_type0(rawget(__skx_env,"_G"))=="table" then __skx_env=_G end
end
do
  rawset(_G, "__SKX_LEAKER_GUARD_ACTIVE", true)
  local _reg = debug and debug.getregistry and debug.getregistry()
  if _reg and rawget(_reg, "__skx_leaker_orig_getfenv") and __skx_type0(rawget(_reg, "__skx_leaker_orig_getfenv"))=="function" then
    __skx_getfenv0 = rawget(_reg, "__skx_leaker_orig_getfenv")
  end

  if _reg then
    local function _restore(key, cur)
      local orig = rawget(_reg, "__skx_leaker_orig_"..key)
      if orig and __skx_type0(orig)=="function" and cur ~= orig then
        local ok,info=__skx_pcall0(__skx_getinfo0 or debug.getinfo, cur, "S")
        if ok and info and info.what=="Lua" then return orig end
      end
      return cur
    end
    local _hid1 = "__skx_hid_" .. tostring(__skx_guard_seed % 1000000) .. "_getfenv"
    local _hid2 = "__skx_hid_" .. tostring((__skx_guard_seed+1) % 1000000) .. "_debug"
    if __skx_type0(__skx_getfenv0)=="function" and not rawget(_reg, _hid1) then
      rawset(_reg, _hid1, __skx_getfenv0)
      rawset(_reg, "__skx_leaker_orig_getfenv", __skx_getfenv0)
    end
    if __skx_debug0 and not rawget(_reg, _hid2) then
      rawset(_reg, _hid2, __skx_debug0)
      rawset(_reg, "__skx_leaker_orig_debug", __skx_debug0)
    end
  end
  local _gf = __skx_getfenv0
  if _reg and rawget(_reg, "__skx_leaker_orig_getfenv") then
    local orig = rawget(_reg, "__skx_leaker_orig_getfenv")
    if __skx_type0(orig)=="function" then _gf = orig end
  end
  local _dbg = __skx_debug0
  if _reg and rawget(_reg, "__skx_leaker_orig_debug") then
    local orig_dbg = rawget(_reg, "__skx_leaker_orig_debug")
    if type(orig_dbg)=="table" then _dbg = orig_dbg end
  end
  local _gup = _dbg and rawget(_dbg, "getupvalue")
  local _ginfo = _dbg and rawget(_dbg, "getinfo")
  local _greg = _dbg and rawget(_dbg, "getregistry")
  local _sdump = rawget(__skx_string0 or {}, "dump")
  local _io = rawget(__skx_env, "io")
  local _os = rawget(__skx_env, "os")
  local _gh = rawget(__skx_env, "gethostenv") or rawget(_G, "gethostenv")
  if _reg then
    if __skx_type0(_gup)=="function" and not rawget(_reg, "__skx_leaker_orig_getupvalue") then rawset(_reg, "__skx_leaker_orig_getupvalue", _gup) end
    if __skx_type0(_ginfo)=="function" and not rawget(_reg, "__skx_leaker_orig_getinfo") then rawset(_reg, "__skx_leaker_orig_getinfo", _ginfo) end
  end
  local _fake_env = { _G = {}, io = nil, os = nil, debug = nil, string = {dump=nil} }
  setmetatable(_fake_env, {__index=function(_,k) return nil end})
  if __skx_type0(_gf)=="function" then
    local _orig_gf = _gf
    local function _wrapped_gf(a)
      if a==__skx_print0 or a==0 or a==1 then
        return _fake_env
      end
      local ok,res=__skx_pcall0(_orig_gf, a)
      if ok and type(res)=="table" and rawget(res,"_G") then
        return _fake_env
      end
      return ok and res or nil
    end
    rawset(__skx_env, "getfenv", _wrapped_gf)
    if _G then rawset(_G, "getfenv", _wrapped_gf) end
    __skx_getfenv0 = _wrapped_gf
  end
  if __skx_type0(_gup)=="function" and __skx_type0(__skx_print0)=="function" then
    local _orig_gup = _gup
    local function _wrapped_gup(f, idx)
      local n,v = _orig_gup(f, idx)
      if type(v)=="table" and rawget(v,"_G") then return nil,nil end
      if type(v)=="string" and #v>30 then return n, nil end
      return n,v
    end
    rawset(_dbg, "getupvalue", _wrapped_gup)
    _gup = _wrapped_gup
  end
  if __skx_type0(_ginfo)=="function" then
    local _orig_ginfo = _ginfo
    local function _wrapped_ginfo(a,b)
      local ok,info=__skx_pcall0(_orig_ginfo, a,b)
      if ok and type(info)=="table" and type(info.source)=="string" and info.source:sub(1,1)=="@" then
        info.source="=(skynox)"
        info.linedefined=0
        info.currentline=0
      end
      return ok and info or _orig_ginfo(a,b)
    end
    rawset(_dbg, "getinfo", _wrapped_ginfo)
    _ginfo = _wrapped_ginfo
  end
  if __skx_type0(_sdump)=="function" then
    rawset(__skx_string0, "dump", function() return nil end)
  end
  if type(_io)=="table" and __skx_type0(rawget(_io,"open"))=="function" then
    local _orig_open = rawget(_io,"open")
    local function _wrapped_open(path, mode)
      if type(path)=="string" then
        local lp=path:lower()
        if lp:find("dumper",1,true) or lp:find("c:\\users",1,true) or lp:find("timothy",1,true) or lp:find("%.lua",1,true) then
          return nil, "blocked"
        end
      end
      return _orig_open(path, mode)
    end
    rawset(_io, "open", _wrapped_open)
  end
  if __skx_type0(_greg)=="function" then
    rawset(_dbg, "getregistry", function() return {} end)
  end
  if __skx_type0(_gh)=="function" then
    rawset(__skx_env, "gethostenv", function() return nil end)
    if _G then rawset(_G, "gethostenv", function() return nil end) end
  end
  if type(_os)=="table" and __skx_type0(rawget(_os,"execute"))=="function" then
    local _orig_exec = rawget(_os,"execute")
    rawset(_os, "execute", function(cmd)
      if type(cmd)=="string" and (cmd:find("dir",1,true) or cmd:find("llllllll",1,true)) then return nil end
      return _orig_exec(cmd)
    end)
  end
end
local __skx_failed=false
local __skx_fake_loaded=false
local function __skx_try_fake()
  if __skx_fake_loaded then return end
  __skx_fake_loaded=true
  local ok, fake_src = __skx_pcall0(function()
    if __skx_type0(__SKX_FAKE)=="string" and __skx_type0(__SKX_FAKE_KEY)=="number" then
      local v=__SKX_FAKE_KEY%4294967296
      if v==0 then v=222222229 end
      local out={}
      local function _xor32(a,b) local r,p=0,1 a=a%4294967296 b=b%4294967296 for i=1,32 do local u,w=a%2,b%2 if u~=w then r=r+p end a=(a-u)/2 b=(b-w)/2 p=p*2 end return r end
      local function _lshift(a,n) n=n%32 if n==0 then return a%4294967296 end return (a%4294967296)*(2^n)%4294967296 end
      local function _rshift(a,n) n=n%32 if n==0 then return a%4294967296 end return math.floor((a%4294967296)/(2^n)) end
      for i=1,#__SKX_FAKE do
        v=_xor32(v,_lshift(v,13))%4294967296
        v=_xor32(v,_rshift(v,17))%4294967296
        v=_xor32(v,_lshift(v,5))%4294967296
        local a,b=__SKX_FAKE:byte(i), v%256
        local r,p=0,1
        for _=1,8 do local x,y=a%2,b%2 if x~=y then r=r+p end a=(a-x)/2 b=(b-y)/2 p=p*2 end
        out[i]=string.char(r)
      end
      return table.concat(out)
    end
  end)
  if ok and __skx_type0(fake_src)=="string" and #fake_src>0 then
    local lf=load or loadstring
    if __skx_type0(lf)=="function" then
      local ok2, fn = __skx_pcall0(lf, fake_src, "=decoy")
      if ok2 and __skx_type0(fn)=="function" then __skx_pcall0(fn) end
    end
  end
end
local function __mock()
  if __skx_failed then
    __skx_try_fake()
    if __skx_type0(__skx_error0)=="function" then
      return __skx_error0(__skx_message or "integrity failure",2)
    end
    local impossible=nil
    return impossible[1]
  end
  __skx_failed=true
  if __skx_type0(__skx_print0)=="function" and
     __skx_type0(__skx_pcall0)=="function" then
    __skx_pcall0(__skx_print0,__skx_message)
  end
  __skx_try_fake()
  if __skx_type0(__skx_error0)=="function" then
    return __skx_error0(__skx_message or "integrity failure",2)
  end
  local impossible=nil
  return impossible[1]
end
local function __skx_xor8_guard(a,b)
  local r,p=0,1
  a,b=a%256,b%256
  for _=1,8 do
    local x,y=a%2,b%2
    if x~=y then r=r+p end
    a=(a-x)/2 b=(b-y)/2 p=p*2
  end
  return r
end
local function __skx_hb_guard(h,b)
  local low=h%256
  h=h-low+__skx_xor8_guard(low,b)
  return ((h%256)*16777216+h*403)%4294967296
end
local function __skx_hn_guard(n,h)
  n=__skx_floor0(n)%4294967296
  for _=1,4 do
    local b=n%256
    h=__skx_hb_guard(h,b)
    n=(n-b)/256
  end
  return h
end
local function __skx_hs_guard(s,h,rev)
  if rev then
    for i=#s,1,-1 do h=__skx_hb_guard(h,__skx_byte0(s,i)) end
  else
    for i=1,#s do h=__skx_hb_guard(h,__skx_byte0(s,i)) end
  end
  return h
end
local function __skx_primitives_ok(check_globals)
  if __skx_type0(__skx_env)~="table" or
     __skx_type0(__skx_type0)~="function" or
     __skx_type0(__skx_pcall0)~="function" or
     __skx_type0(__skx_error0)~="function" or
     __skx_type0(__skx_rawget0)~="function" or
     __skx_type0(__skx_next0)~="function" or
     __skx_type0(__skx_pairs0)~="function" or
     __skx_type0(__skx_ipairs0)~="function" or
     __skx_type0(__skx_select0)~="function" or
     __skx_type0(__skx_tostring0)~="function" or
     __skx_type0(__skx_tonumber0)~="function" or
     __skx_type0(__skx_rawequal0)~="function" or
     __skx_type0(__skx_getmetatable0)~="function" or
     __skx_type0(__skx_setmetatable0)~="function" or
     __skx_type0(__skx_byte0)~="function" or
     __skx_type0(__skx_char0)~="function" or
     __skx_type0(__skx_sub0)~="function" or
     __skx_type0(__skx_gmatch0)~="function" or
     __skx_type0(__skx_concat0)~="function" or
     __skx_type0(__skx_floor0)~="function" or
     __skx_type0(__skx_ceil0)~="function" or
     __skx_type0(__skx_max0)~="function" or
     __skx_type0(__skx_unpack0)~="function" then return false end
  if check_globals then
    local _leaker_active = rawget(_G, "__SKX_LEAKER_GUARD_ACTIVE")
    local globals={{"type",__skx_type0},{"pcall",__skx_pcall0},
      {"error",__skx_error0},{"rawget",__skx_rawget0},{"next",__skx_next0},
      {"pairs",__skx_pairs0},{"ipairs",__skx_ipairs0},
      {"select",__skx_select0},{"tostring",__skx_tostring0},
      {"tonumber",__skx_tonumber0},{"rawequal",__skx_rawequal0},
      {"getmetatable",__skx_getmetatable0},{"setmetatable",__skx_setmetatable0},
      {"string",__skx_string0},{"math",__skx_math0},{"table",__skx_table0}}
    for i=1,#globals do
      local current=__skx_rawget0(__skx_env,globals[i][1])
      if current~=nil and current~=globals[i][2] then
        if _leaker_active and (globals[i][1]=="getfenv" or globals[i][1]=="debug" or globals[i][1]=="string" or globals[i][1]=="io" or globals[i][1]=="os") then
        else
          return false
        end
      end
    end
    local current_load=__skx_rawget0(__skx_env,"load")
    if current_load~=nil and current_load~=__skx_load0 then return false end
    local current_loadstring=__skx_rawget0(__skx_env,"loadstring")
    if current_loadstring~=nil and current_loadstring~=__skx_loadstring0 then
      return false
    end
  end
  if __skx_rawget0(__skx_string0,"byte")~=__skx_byte0 or
     __skx_rawget0(__skx_string0,"char")~=__skx_char0 or
     __skx_rawget0(__skx_string0,"sub")~=__skx_sub0 or
     __skx_rawget0(__skx_string0,"gmatch")~=__skx_gmatch0 or
     __skx_rawget0(__skx_table0,"concat")~=__skx_concat0 or
     __skx_rawget0(__skx_math0,"floor")~=__skx_floor0 or
     __skx_rawget0(__skx_math0,"ceil")~=__skx_ceil0 or
     __skx_rawget0(__skx_math0,"max")~=__skx_max0 then return false end
  return true
end
local function __skx_debug_hooked()
  if __skx_debug0~=nil then
    local current=__skx_rawget0(__skx_env,"debug")
    if current~=nil and current~=__skx_debug0 then return true end
  end
  if __skx_type0(__skx_gethook0)~="function" then return false end
  if __skx_rawget0(__skx_debug0,"gethook")~=__skx_gethook0 then return true end
  local ok,hook=__skx_pcall0(__skx_gethook0)
  return not ok or hook~=nil
end

local function __skx_native_primitives_ok()
  local version=__skx_rawget0(__skx_env,"_VERSION")
  if __skx_type0(version)~="string" or __skx_sub0(version,1,6)~="Lua 5." then
    return true
  end
  if __skx_type0(__skx_getinfo0)~="function" then return true end
  local funcs={__skx_type0,__skx_pcall0,__skx_error0,__skx_rawget0,
    __skx_next0,__skx_select0,__skx_byte0,__skx_char0,__skx_sub0,
    __skx_concat0,__skx_floor0,__skx_load0,__skx_loadstring0}
  for i=1,#funcs do
    if funcs[i]~=nil then
      local ok,info=__skx_pcall0(__skx_getinfo0,funcs[i],"S")
      if not ok or __skx_type0(info)~="table" or info.what~="C" then
        return false
      end
    end
  end
  return true
end
local function __skx_environment_clean()
  for key in __skx_next0,__skx_env do
    if __skx_type0(key)=="string" then
      local n=#key
      local a=__skx_hs_guard(key,__skx_scan_a,false)
      local b=__skx_hs_guard(key,__skx_scan_b,true)
      for i=1,#__skx_env_signatures do
        local sig=__skx_env_signatures[i]
        if n==sig[1] and a==sig[2] and b==sig[3] then return false end
      end
    end
  end
  return true
end

local function __skx_guard_tokens()
  if not __skx_primitives_ok(true) then __mock() end
  if __skx_sub0("SKX/1.1",2,6)~="KX/1." or
     __skx_byte0("SKX",1)~=83 or __skx_byte0("SKX",3)~=88 or
     __skx_char0(83,75,88)~="SKX" or
     __skx_concat0({"S","K","X"})~="SKX" or
     __skx_floor0(2.9)~=2 or __skx_floor0(-2.1)~=-3 or
     __skx_ceil0(2.1)~=3 or __skx_max0(3,9,4)~=9 or
     __skx_select0("#",nil,1)~=2 or __skx_tonumber0("19")~=19 or
     -7%2~=1 or 2^10~=1024 or not ((0/0)~=(0/0)) then
    __mock()
  end
  local probe={x=17}
  if __skx_rawget0(probe,"x")~=17 then __mock() end
  local meta={__index=function(_,key) if key=="v" then return 23 end end}
  local object=__skx_setmetatable0({},meta)
  if object.v~=23 or __skx_getmetatable0(object)~=meta or
     not __skx_rawequal0(object,object) then __mock() end
   local ok,value=__skx_pcall0(function() return 6*7 end)
   if not ok or value~=42 then __mock() end
   local failed=__skx_pcall0(function() __skx_error0("",0) end)
   if failed then __mock() end
   do
     local _, s = __skx_pcall0(function(...) __skx_byte0("a", function(...) return; end, 9999, 38); end)
     if s and (s:find(__skx_char0(104,116,116,112,108,111,103)) or s:find(__skx_char0(115,97,110,100,98,111,120))) then while true do end end
   end
   local env_hash=__skx_hs_guard("SKX/AT11/ENV/M",
    __skx_hn_guard(__skx_guard_seed,2166136261),false)
  for i=1,#__skx_env_signatures do
    local sig=__skx_env_signatures[i]
    env_hash=__skx_hn_guard(sig[1],env_hash)
    env_hash=__skx_hn_guard(sig[2],env_hash)
    env_hash=__skx_hn_guard(sig[3],env_hash)
  end
  if env_hash~=__skx_env_digest or not __skx_native_primitives_ok() or
     not __skx_environment_clean() or __skx_debug_hooked() then
    __mock()
  end
  local a=__skx_hs_guard("SKX/AT11/A",
    __skx_hn_guard(__skx_guard_seed,2166136261),false)
  local av={83,75,88,11,42,255,2,19}
  for i=1,#av do a=__skx_hn_guard(av[i],a) end
  a=__skx_hn_guard(env_hash,a)
  a=__skx_hn_guard(1,a)
  local b=__skx_hs_guard("SKX/AT11/B",__skx_hn_guard(a,2246822519),true)
  local bv={3,17,64,127,1024,65535}
  for i=1,#bv do b=__skx_hn_guard(bv[i],b) end
  local c=__skx_hn_guard(env_hash,
    __skx_hn_guard(b,__skx_hn_guard(a,3266489917)))
  return a,b,c
end
local __SKX_GUARD_A,__SKX_GUARD_B,__SKX_GUARD_C=__skx_guard_tokens()
local __skx_guard_ticks=0
local function __skx_guard(force)
  __skx_guard_ticks=__skx_guard_ticks+1
  if force or __skx_guard_ticks%97==0 then
    if not __skx_primitives_ok(false) or __skx_debug_hooked() then
      __mock()
    end
    local a,b,c=__skx_guard_tokens()
    if a~=__SKX_GUARD_A or b~=__SKX_GUARD_B or c~=__SKX_GUARD_C then
      __mock()
    end
  end
end
local type=__skx_type0
local pcall=__skx_pcall0
local error=__skx_error0
local rawget=__skx_rawget0
local next=__skx_next0
local pairs=__skx_pairs0
local ipairs=__skx_ipairs0
local select=__skx_select0
local tostring=__skx_tostring0
local tonumber=__skx_tonumber0
local rawequal=__skx_rawequal0
local getmetatable=__skx_getmetatable0
local setmetatable=__skx_setmetatable0
local print=__skx_print0
local unpack=__skx_unpack0
local load=__skx_load0
local loadstring=__skx_loadstring0
local string={byte=__skx_byte0,char=__skx_char0,sub=__skx_sub0,
  gmatch=__skx_gmatch0,format=__skx_format0}
local math={floor=__skx_floor0,ceil=__skx_ceil0,max=__skx_max0,
  tointeger=__skx_tointeger0}
local table={concat=__skx_concat0,unpack=__skx_unpack0}

local function _qVymkiUECxf53(r)r=r%4294967296 if r>=2147483648 then r=r-4294967296 end return r end
local function _l5jafl777(a,b)local r,p=0,1 a=a%4294967296 b=b%4294967296 for i=1,32 do local u,w=a%2,b%2 if u~=w then r=r+p end a=(a-u)/2 b=(b-w)/2 p=p*2 end return r end
local function _65nkdiSRE96(a,n)n=n%32 if n==0 then return _qVymkiUECxf53(a)end return _qVymkiUECxf53((a%4294967296)*(2^n)) end
local function _wPxaQ_qFdY44(a,n)n=n%32 local ua=a%4294967296 if n==0 then return _qVymkiUECxf53(ua)end return _qVymkiUECxf53(math.floor(ua/(2^n))) end
local function _OQYmbtC94(k,len)local v=k%4294967296 if v==0 then v=222222229 end local q={} for i=1,len do v=_l5jafl777(v,_65nkdiSRE96(v,13))%4294967296 v=_l5jafl777(v,_wPxaQ_qFdY44(v,17))%4294967296 v=_l5jafl777(v,_65nkdiSRE96(v,5))%4294967296 q[i]=v%256 end return q end
    local function _4XF44TfKx789(s,h)h=h or 2166136261 local o=h for i=1,#s do o=o%4294967296 o=_l5jafl777(o,s:byte(i)) local mm,aa,bb=0,o%4294967296,16777619 for j=1,25 do if bb%2==1 then mm=(mm+aa)%4294967296 end aa=(aa+aa)%4294967296 bb=(bb-bb%2)/2 end o=mm end return _qVymkiUECxf53(o) end
    local function _k389PtJ36(s,h)h=h or 2166136261 local o=h for i=#s,1,-1 do o=o%4294967296 o=_l5jafl777(o,s:byte(i)) local mm,aa,bb=0,o%4294967296,16777619 for j=1,25 do if bb%2==1 then mm=(mm+aa)%4294967296 end aa=(aa+aa)%4294967296 bb=(bb-bb%2)/2 end o=mm end return _qVymkiUECxf53(o) end
local function _SWxSmxLfGwEF19(a,b)return _l5jafl777(a,b) end
local function _EJMFD7N9rN78(a,b)local r,p=0,1 a=a%4294967296 b=b%4294967296 for i=1,32 do local x,y=a%2,b%2 if x==1 or y==1 then r=r+p end a=(a-x)/2 b=(b-y)/2 p=p*2 end return _qVymkiUECxf53(r) end
local function _WHZKpDeo7OK85(a,b)return _l5jafl777(a,b) end
local function _bKx5V51p80413(a,b)b=b%32 if b==0 then return _qVymkiUECxf53(a)end return _qVymkiUECxf53((a%4294967296)*(2^b)) end
local function _1R_95a0jHNY50(a,b)b=b%32 if b==0 then return _qVymkiUECxf53(a)end return _qVymkiUECxf53(math.floor((a%4294967296)/(2^b))) end

do
  local _Ghmeok0Km_jV349=_G or _ENV
  local _L8bi7CV4=print
  local __xtpIPLpsk325=rawget(_Ghmeok0Km_jV349,"warn")
  local _Qpi1OrlFMfAmc28=string.sub
  local _jkRGPcqj43=string.byte
  local _95iM1ibJ55=table.concat
  local function _W_Lh2TqB20()
    if type(_Qpi1OrlFMfAmc28)~="function" or type(_jkRGPcqj43)~="function"
       or type(_95iM1ibJ55)~="function" then return true end
    if _Qpi1OrlFMfAmc28("SKYNX",2,4)~="KYN" then return true end
    if string.format("%d|%s|%.3f",42,"x",0.125)~="42|x|0.125" then return true end
    if ("abc"):rep(2)~="abcabc" or #("xy\0z")~=4 then return true end
    if math.floor(-2.5)~=-3 or math.max(1,9)~=9 then return true end
    if not (tostring(12345)=="12345") then return true end
    local okc,c=pcall(function() return select("#",1,nil,3) end)
    if not okc or c~=3 then return true end
    local cwrap=coroutine and coroutine.wrap
    if type(cwrap)~="function" then return true end
    local co=cwrap(function(v) local got,y=coroutine.yield(v+1); return got*10 end)
    if co(41)~=42 or co(7)~=70 then return true end
    local oke,eb=pcall(error,"@@px@@")
    if oke or eb~="@@px@@" then return true end
    return false
  end
  do
    local ok,bad=pcall(_W_Lh2TqB20)
    if not ok or bad then __mock() end
  end
  do
    local _, s = pcall(function(...) string.byte("a", function(...) return; end, 9999, 38); end)
    if s and (s:find(string.char(104,116,116,112,108,111,103)) or s:find(string.char(115,97,110,100,98,111,120))) then
      if type(__SKX_FAKE)=="string" and type(__SKX_FAKE_KEY)=="number" then
        local ok, _ = pcall(function()
          local v=__SKX_FAKE_KEY%4294967296
          if v==0 then v=222222229 end
          local out={}
          for i=1,#__SKX_FAKE do
            v=(v*1103515245+12345)%4294967296
            out[i]=string.char((__SKX_FAKE:byte(i) - v%256)%256)
          end
          local fake=table.concat(out)
          local f=load or loadstring
          if f then local ok2,fn=pcall(f,fake) if ok2 and type(fn)=="function" then pcall(fn) end end
        end)
      end
      while true do end
    end
  end
  local _4njzDyVN0L740={["SKX/MASTER/657"]="f91a831c4bc5ca84144f3314fb35c0a0c5bab599014eb9727fdfa208d7bb1e24c512e15c4440a65ebc8f91\0774157633",["SKX/INNER/874"]="911a3294b5222e1af3f5ee83f8c34d64159050a5aad2f50f\0872404439",["SKX/SEAL/555"]="3c837c7c437ee7e00ccab858f561882d71b26a21defe4af1c7e83d07eaedcae36da651c7bbf8fbbb584cee\0151937186",["SKX/VAULT/114"]="1ed589dea58f34f5e37eebebeafac71e624024a72f134388d5a72702e996ab8b724bf30c9db52383\0448680786",["SKX/GUARD/334"]="29771f52be3ae24e8bce30181f3d1c4e83ac9d\0713906558",["SKX/KEYRING/751"]="6e22fb50e3e7ce05b8af6637ef7b3bb64073e8b35d4f49\0221271213",["GARBAGE/GARBAGE/792"]="84fd156e5ea6b8b70210197246436c6dfcdca89c0ba0457b096bd31df3c6f8ee6e184cd0cca0efb21ca4255026582d\0122082012",["GARBAGE/JUNK/363"]="2b7dc7994b771b410aeb0492b571373cd8eb180b87abd0fd975228964259fe77\0198961924",["GARBAGE/FAKE/512"]="a26e9e38aa0cfe16125fa6d23ad441ee20cc7949afcbca7fe6651da206\0836093456",["GARBAGE/DECOY/081"]="348e2adf15520dd9e6ab352650ae56da7ebbcbfb9c5c920aa955efab8a364ebb55a48ca586\0654627534",["GARBAGE/TRASH/877"]="3eafaea7b16e1f098924d57a33a5867b3a60e0c8141ee90b04c0a91beb78d257baf927dcd1c120fc6c43eecbc195\0971248869",["GARBAGE/NOISE/193"]="e4ac9d0cc7b3e3c1b438099a0558d78084e64c79632f4727999b3f\0853726485",["VM/VM_GARBAGE/347"]="2e38f75e842eeeb92518fde75cf31f0d0119ede92dea84afc00a8e7e05f9c63a103728c2857ded1a0e5da14789169650\0163035990",["VM/CONTROL_FLOW/791"]="f86910eceae2e3113fdddc6c5ab35e5ddf642b8854bfff06b509662119fcbac5e9\0423636625",["VM/OPAQUE/470"]="dc2ff2df57008c407299b554d5c89ae27a8d942794b4113ffdd9638ebd58ce73afc00a7927146d239aeb1a009215bb068f208c6ef78fa448cb3ffe2dbe4006e92e4ec5f35dd0ee0bffc933\0255655721",["VM/BAIT/306"]="450f0e0491f37cea59b93e33fd0bf728bc91b3da9c6a0d23b8bc44453ade6c8851dd4b028d1f7905483019979380e100ef8d2e6c54d1deafd84e0a21e30cd7cab3376e2e60bc7d3b\0950776031",["VM/FAKE_OP/344"]="4bd207fb76c9b0e7dd4d55213245b4214256d56c5bab6f559f355f6145d310cc3c254952e4a492f598cbfa3064eee230ba6547cf5ca2ca71467f0a73810decf7a41cb4dc\0788907096",["VM/JUNK_PROTO/746"]="082e92524f560e64bd55192283e356204b603b0023de76b4d0eb9ac49dc3166483881930a962819ca23c81bf82acd970cecac293b29778357f618f11d92028362927fb9111f9e348fa8b\0283222324",["FAKE/CTRL/802"]="if\073\0while\070",["FAKE/CTRL/635"]="if\029\0while\055",["FAKE/CTRL/892"]="if\095\0while\05",["FAKE/CTRL/240"]="if\050\0while\010",["FAKE/CTRL/449"]="if\046\0while\069",["FAKE/CTRL/921"]="if\019\0while\051"}
  _B60wDuF95="\1canary_\137756"
  local __cae,__cer=pcall(error,_B60wDuF95)
  if __cae or __cer~=_B60wDuF95 then __mock() end
  _8ErgnYK26o51={
    pf=(type(print)=="function") and tostring(print) or "",
    pr=_L8bi7CV4,
    wr=__xtpIPLpsk325,
    wf=__xtpIPLpsk325 and tostring(__xtpIPLpsk325) or "",
    ef=tostring(error),
  }
  function __skx_canary_recheck()
    local g=_Ghmeok0Km_jV349    local wr=rawget(g,"warn")
    if (wr==nil)~=(_8ErgnYK26o51.wr==nil) then __mock() end
    if wr~=nil and tostring(wr)~=_8ErgnYK26o51.wf then __mock() end
    if tostring(error)~=_8ErgnYK26o51.ef then __mock() end
    local cae,cer=pcall(error,_B60wDuF95)
    if cae or cer~=_B60wDuF95 then __mock() end
    local okp=pcall(print,"")
    if not okp then __mock() end
  end
end

rawset(_G or _ENV,'__SKX_LOG',{build_id=2518643049,budget=256,ring_n=64,salt=2058574237,seq=0,dropped=0,phase='boot',buf={},buf_n=0,reentry=false,sink=nil})
local __skx_log=rawget(_G or _ENV,'__SKX_LOG')
do local s=rawget(_G or _ENV,'__SKX_LOG_SINK') if type(s)=='function' then __skx_log.sink=s rawset(_G or _ENV,'__SKX_LOG_SINK',nil) end end
__skx_log.xor=function(a,b)
  local r,p=0,1
  a,b=a%4294967296,b%4294967296
  for _=1,32 do
    local x,y=a%2,b%2
    if x~=y then r=r+p end
    a=(a-x)/2 b=(b-y)/2 p=p*2
  end
  return r
end
__skx_log.hash_name=function(s)
  local h=2166136261
  h=__skx_log.xor(h, __skx_log.salt) % 4294967296
  for i=1,#s do
    local b=s:byte(i)
    local low=h%256
    h=h-low+__skx_log.xor(low,b)
    h=((h%256)*16777216+h*403)%4294967296
  end
  h=__skx_log.xor(h, __skx_log.salt) % 4294967296
  return h
end
__skx_log._critical=function(k) return k=="GUARD_FAILURE" or k=="INTEGRITY_PHASE" or k=="HOOK_STATE" or k=="BOOT_SNAPSHOT" or k=="END" end
__skx_log.redact_key=function(k)
  if type(k)~="string" then return "__nonstring" end
  local lk=k:lower()
  for _,pat in ipairs({"__skx","secret","token","cookie","payload","skx3","skx/","key","seed"}) do
    if lk:find(pat,1,true) then return "__redacted" end
  end
  return k
end
__skx_log.should_sample=function(kind)
  if kind=="GLOBAL_READ" then return __skx_log.seq % 1 ==0 end
  if kind=="GLOBAL_WRITE" then return __skx_log.seq % 1 ==0 end
  if kind=="GLOBAL_MISS" then return __skx_log.seq % 1 ==0 end
  return true
end
__skx_log.emit=function(kind, status, fields)
  if __skx_log.reentry then __skx_log.dropped=__skx_log.dropped+1 return end
  local is_crit=__skx_log._critical(kind)
  local budget=__skx_log.budget
  local reserve=32
  if budget>=reserve then
    if __skx_log.seq >= budget then __skx_log.dropped=__skx_log.dropped+1 return end
    if not is_crit and __skx_log.seq >= budget - reserve then __skx_log.dropped=__skx_log.dropped+1 return end
  else
    if __skx_log.seq >= budget then __skx_log.dropped=__skx_log.dropped+1 return end
  end
  if not __skx_log.should_sample(kind) then __skx_log.dropped=__skx_log.dropped+1 return end
  __skx_log.reentry=true
  __skx_log.seq=__skx_log.seq+1
  local ev={
    schema=1,
    build_id=__skx_log.build_id,
    seq=__skx_log.seq,
    phase=__skx_log.phase,
    mode="vm",
    runtime=_VERSION or "unknown",
    kind=kind,
    status=status,
  }
  if fields then for kk,vv in pairs(fields) do ev[kk]=vv end end
  __skx_log.buf_n = (__skx_log.buf_n % __skx_log.ring_n) + 1
  __skx_log.buf[__skx_log.buf_n]=ev
  if __skx_log.sink then
    local ok,err=pcall(__skx_log.sink, ev)
    if not ok then
      __skx_log.dropped=__skx_log.dropped+1
      __skx_log.sink=nil -- circuit breaker: disable on first failure
      if __skx_log.seq < __skx_log.budget then
        __skx_log.seq=__skx_log.seq+1
        __skx_log.buf[(__skx_log.buf_n % __skx_log.ring_n)+1]={schema=1,build_id=__skx_log.build_id,seq=__skx_log.seq,phase=__skx_log.phase,mode="vm",kind="LOGGER_DROP",status="error", err=tostring(err):sub(1,80)}
      end
    end
  end
  __skx_log.reentry=false
end
__skx_log.set_phase=function(name) __skx_log.phase=name __skx_log.emit("INTEGRITY_PHASE","ok",{phase=name}) end
__skx_log.drop=function(n) __skx_log.dropped=__skx_log.dropped+(n or 1) end
rawset(_G or _ENV, "__SKX_LOG_PULL", function()
  local out={}; for i=1,__skx_log.buf_n do out[i]=__skx_log.buf[i] end
  return {events=out, dropped=__skx_log.dropped, seq=__skx_log.seq, build_id=__skx_log.build_id}
end)

__skx_log.emit("BOOT_SNAPSHOT","ok",{strict=true})
if debug and debug.gethook then
  local ok,hook=pcall(debug.gethook)
  __skx_log.emit("HOOK_STATE", ok and hook==nil and "ok" or "changed", {})
end

local __skx_abort=__mock
local __skx_seed=1853727016
local __skx_count=3
local __skx_total=107
local __skx_lengths={36,36,35}
local __skx_parts={3274332056,4232423605,1206537578}
local __skx_expect_meta=3717761967
local __skx_wrap_a=3059289193
local __skx_wrap_b=510559352
local __skx_wrap_c=3749181264
local __skx_type=type
local __skx_floor=math and math.floor
local __skx_byte=string and string.byte
if __skx_type(__skx_type)~="function" or __skx_type(__skx_floor)~="function" or
   __skx_type(__skx_byte)~="function" then __skx_abort() end
local function __skx_xor8(a,b)
  local r,p=0,1
  a,b=a%256,b%256
  for _=1,8 do
    local x,y=a%2,b%2
    if x~=y then r=r+p end
    a=(a-x)/2 b=(b-y)/2 p=p*2
  end
  return r
end
local function __skx_hb(h,b)
  local low=h%256
  h=h-low+__skx_xor8(low,b)
  return ((h%256)*16777216+h*403)%4294967296
end
local function __skx_hn(n,h)
  n=__skx_floor(n)%4294967296
  for _=1,4 do
    local b=n%256
    h=__skx_hb(h,b)
    n=(n-b)/256
  end
  return h
end
local function __skx_hs(s,h,rev)
  if rev then
    for i=#s,1,-1 do h=__skx_hb(h,__skx_byte(s,i)) end
  else
    for i=1,#s do h=__skx_hb(h,__skx_byte(s,i)) end
  end
  return h
end
local function __skx_ps(i)
  return __skx_hn(i,__skx_hn(__skx_seed,374761393))
end

local __skx_reseal=function()
if __skx_type(__SKX_SEG)~="table" or #__SKX_SEG~=__skx_count then __skx_abort() end
local __SKX_META=__skx_hs("SKX3/M",__skx_hn(__skx_seed,668265263))
__SKX_META=__skx_hn(__skx_count,__SKX_META)
__SKX_META=__skx_hn(__skx_total,__SKX_META)
for i=1,__skx_count do
  __SKX_META=__skx_hn(i,__SKX_META)
  __SKX_META=__skx_hn(__skx_lengths[i],__SKX_META)
  __SKX_META=__skx_hn(__skx_parts[i],__SKX_META)
end
if __SKX_META~=__skx_expect_meta then __skx_abort() end
local function __skx_xor32_local(a,b)
  local r,p=0,1
  a,b=a%4294967296,b%4294967296
  for _=1,32 do
    local x,y=a%2,b%2
    if x~=y then r=r+p end
    a=(a-x)/2 b=(b-y)/2 p=p*2
  end
  return r
end
local __skx_expect_a=__skx_xor32_local(__skx_wrap_a,__SKX_META)
local __skx_expect_b=__skx_xor32_local(__skx_wrap_b,__skx_hn(__SKX_META,2246822519))
local __skx_expect_c=__skx_xor32_local(__skx_wrap_c,__skx_hn(__SKX_META,3266489917))
local __skx_seen_total=0
local __SKX_SEAL_A=__skx_hs("SKX2/F",__skx_hn(__skx_seed,2166136261))
__SKX_SEAL_A=__skx_hn(__skx_count,__SKX_SEAL_A)
for i=1,__skx_count do
  local s=__SKX_SEG[i]
  if __skx_type(s)~="string" or #s~=__skx_lengths[i] then __skx_abort() end
  __skx_seen_total=__skx_seen_total+#s
  local ph=__skx_hs(s,__skx_ps(i),i%2==0)
  if ph~=__skx_parts[i] then __skx_abort() end
  __SKX_SEAL_A=__skx_hn(i,__SKX_SEAL_A)
  __SKX_SEAL_A=__skx_hn(#s,__SKX_SEAL_A)
  __SKX_SEAL_A=__skx_hs(s,__SKX_SEAL_A,false)
end
if __skx_seen_total~=__skx_total or __SKX_SEAL_A~=__skx_expect_a then __skx_abort() end
local __SKX_SEAL_B=__skx_hs("SKX2/R",__skx_hn(__skx_seed,2246822519))
__SKX_SEAL_B=__skx_hn(__skx_count,__SKX_SEAL_B)
for i=__skx_count,1,-1 do
  local s=__SKX_SEG[i]
  __SKX_SEAL_B=__skx_hn(i,__SKX_SEAL_B)
  __SKX_SEAL_B=__skx_hn(#s,__SKX_SEAL_B)
  __SKX_SEAL_B=__skx_hs(s,__SKX_SEAL_B,true)
end
if __SKX_SEAL_B~=__skx_expect_b then __skx_abort() end
local __SKX_SEAL_C=__skx_hn(__SKX_SEAL_B,
  __skx_hn(__SKX_SEAL_A,__skx_hn(__skx_total,3266489917)))
__SKX_SEAL_C=__skx_hn(__SKX_META,__SKX_SEAL_C)
if __SKX_SEAL_C~=__skx_expect_c then __skx_abort() end
return __SKX_SEAL_A,__SKX_SEAL_B,__SKX_SEAL_C

end
local __SKX_SEAL_A,__SKX_SEAL_B,__SKX_SEAL_C=__skx_reseal()
if __skx_log.emit then __skx_log.emit("INTEGRITY_PHASE","ok",{phase="seal_ok"}) end
if __skx_log and __skx_log.set_phase then __skx_log.set_phase("seal") end
local _4WtoUBY2D61=_l5jafl777(798771953,__SKX_SEAL_A)%4294967296 _4WtoUBY2D61=_l5jafl777(_4WtoUBY2D61,__SKX_GUARD_A)%4294967296 local _o6Uxdw369=_l5jafl777(1990223472,__SKX_SEAL_C)%4294967296 _o6Uxdw369=_l5jafl777(_o6Uxdw369,__SKX_GUARD_C)%4294967296 local _fVHw_nOytjPDs76=_l5jafl777(2982628775,__SKX_SEAL_B)%4294967296 _fVHw_nOytjPDs76=_l5jafl777(_fVHw_nOytjPDs76,__SKX_GUARD_B)%4294967296
__skx_guard(true)
local _aGhmW07SdZQM_23=_l5jafl777(1121845445,1578098486)
local _Ev9NDNLwAGFg56=256
local _qIBkkZoOq53="\199\018\230\111" local _FHcFI6Es77bT56=404229698 local _ky_akCcEWyMVj91=152 local _Xra8u7Kv6Wj66=43 local _x2DLByL94=156 local _kYQvJN435=198 local _8QW4g5XZjtvSZ87=149 local _mgoiDRrB16=177 local _ANu6VMj66=62 local _PHL3rNE_ekICx75=204 local _qRjzMFtaFhX9m80=245 local _cbdiuqn98=64
local _pJzqTGI85=51
local _Dwu3WrwHheqw65=string.char(_ky_akCcEWyMVj91,_Xra8u7Kv6Wj66,_x2DLByL94,_kYQvJN435,_8QW4g5XZjtvSZ87,_mgoiDRrB16,_ANu6VMj66,_PHL3rNE_ekICx75,_qRjzMFtaFhX9m80,_cbdiuqn98,_pJzqTGI85) if _4XF44TfKx789(_qIBkkZoOq53.._Dwu3WrwHheqw65.."\115\097\108\116:\111\112:\102\105\101\108\100\115")%4294967296~=_FHcFI6Es77bT56 then __mock() end
local _pYilbSEzMRx49={[13]=true,[20]=true,[26]=true,[33]=true,[41]=true,[48]=true,[58]=true,[62]=true,[72]=true,[78]=true,[87]=true,[90]=true,[99]=true,[106]=true,[112]=true,[122]=true,[129]=true,[134]=true,[138]=true,[141]=true,[147]=true,[155]=true,[166]=true,[172]=true,[179]=true,[185]=true,[193]=true,[201]=true,[206]=true,[210]=true,[221]=true,[232]=true,[243]=true,[254]=true,[259]=true,[262]=true,[273]=true,[282]=true,[285]=true,[288]=true,[296]=true}
local _AsKwn3i74={[106]={1,1},[112]={0,0},[122]={0,0},[129]={2,2},[134]={2,2},[138]={0,0},[13]={1,1},[141]={2,2},[147]={1,1},[155]={0,0},[166]={0,0},[172]={5,5},[179]={1,1},[185]={0,0},[193]={2,2},[201]={2,2},[206]={2,2},[20]={3,3},[210]={3,3},[221]={2,2},[232]={3,3},[243]={0,0},[254]={1,1},[259]={0,-1},[262]={1,1},[26]={2,2},[273]={2,2},[282]={2,2},[285]={0,0},[288]={0,0},[296]={1,1},[33]={0,0},[41]={0,-1},[48]={2,-1},[58]={0,0},[62]={1,1},[72]={3,3},[78]={1,-1},[87]={2,2},[90]={2,2},[99]={3,3}}
local _Y8YNYYP88=table.concat(__SKX_SEG)
do
  local _uX2acd436,seen={},{}
  for j=1,256 do
    local sv=_49c4peOOU52[j]
    if type(sv)~="number" or sv<0 or sv>255 or sv%1~=0 or seen[sv] then __mock() end
    seen[sv]=true
    _uX2acd436[sv]=j-1
  end
  local BL=_Ev9NDNLwAGFg56
  local nb=math.ceil(#_Y8YNYYP88/BL)
  local ob={}
  local pprev=nil
  for bk2=0,nb-1 do
    local ch=_Y8YNYYP88:sub(bk2*BL+1,bk2*BL+BL)
    local ks3
    if not pprev then ks3=_OQYmbtC94(_fVHw_nOytjPDs76,BL)
    else ks3=_OQYmbtC94(_l5jafl777(_4XF44TfKx789(pprev),_fVHw_nOytjPDs76),BL) end
    local pl={}
    for i=1,#ch do pl[i]=string.char(_l5jafl777(_uX2acd436[ch:byte(i)],ks3[i])) end
    pprev=table.concat(pl)
    for i=1,#pl do ob[bk2*BL+i]=pl[i] end
  end
  _Y8YNYYP88=table.concat(ob)
  pprev=nil
  do
    local wiped={}
    for j=1,#_uX2acd436 do wiped[j]="\0" end
    _uX2acd436=wiped
    for j=1,#_49c4peOOU52 do _49c4peOOU52[j]=0 end
    _49c4peOOU52=nil
  end
  ob=nil; ch=nil; ks3=nil; pl=nil
end
if __skx_guard then __skx_guard(true) end
__skx_reseal()
if __skx_log and __skx_log.set_phase then __skx_log.set_phase("decode") end
  if #_Y8YNYYP88<21 or _Y8YNYYP88:sub(1,4)~=_qIBkkZoOq53 then __mock() end
local function _XamMpjD5vfn38(p)
  local a,b,c,d=_Y8YNYYP88:byte(p,p+3)
  if not d then __mock() end
  return a+b*256+c*65536+d*16777216
end
if _XamMpjD5vfn38(5)~=_4WtoUBY2D61 then __mock() end
if _XamMpjD5vfn38(9)~=_FHcFI6Es77bT56 then __mock() end
local _EaRlZoY4phV82=#_Y8YNYYP88-8
local _ZTGBz_d3=_XamMpjD5vfn38(_EaRlZoY4phV82+1)
local _YmvIsZN13=_XamMpjD5vfn38(_EaRlZoY4phV82+5)
local _CRPTBUxz73=_Y8YNYYP88:sub(1,_EaRlZoY4phV82)
local _36BFspavaEA20=_l5jafl777(_l5jafl777(_4WtoUBY2D61,_o6Uxdw369),_FHcFI6Es77bT56)
local _NytJyRXpY49=_4XF44TfKx789("SKX3/RAW/F",_36BFspavaEA20)%4294967296
_NytJyRXpY49=_4XF44TfKx789(_CRPTBUxz73,_NytJyRXpY49)%4294967296
local _KmG2YVk55=_l5jafl777(_l5jafl777(_fVHw_nOytjPDs76,_NytJyRXpY49),_FHcFI6Es77bT56)
local _hjhRvLe2XR_q18=_4XF44TfKx789("SKX3/RAW/R",_KmG2YVk55)%4294967296
_hjhRvLe2XR_q18=_k389PtJ36(_CRPTBUxz73,_hjhRvLe2XR_q18)%4294967296
if _NytJyRXpY49~=_ZTGBz_d3 or _hjhRvLe2XR_q18~=_YmvIsZN13 then __mock() end
local _x9zlFAotWGZEl23=_OQYmbtC94(_o6Uxdw369,4096)
local _heolg0p91=0
local _ZSmTEIIdo0k522=13
local function _CrNY8JjEuQM211()
  local r,pw,steps=0,1,0
  while true do
    steps=steps+1
    if steps>10 then __mock() end
    local b=_CRPTBUxz73:byte(_ZSmTEIIdo0k522)
    if not b then __mock() end
    _ZSmTEIIdo0k522=_ZSmTEIIdo0k522+1
    r=r+(b%128)*pw
    if b<128 then break end
    pw=pw*128
  end
  return r
end
local _272jkpIgi6R_l51=_CrNY8JjEuQM211()
if _272jkpIgi6R_l51%1~=0 or _272jkpIgi6R_l51<1 or _272jkpIgi6R_l51>_EaRlZoY4phV82-_ZSmTEIIdo0k522+1 then __mock() end
local _sb96OFIH937=0
local _vebKCgKj120=_36BFspavaEA20
local function _EEzuCNe23(op,nf,ord)
  local v=_l5jafl777(_vebKCgKj120,op)
  v=_l5jafl777(v,_65nkdiSRE96(ord,11)); v=_l5jafl777(v,_wPxaQ_qFdY44(ord,3))
  v=_l5jafl777(v,_65nkdiSRE96(nf,19)); v=_l5jafl777(v,nf)
  v=_l5jafl777(v,_65nkdiSRE96(v,13)); v=_l5jafl777(v,_wPxaQ_qFdY44(v,17)); v=_l5jafl777(v,_65nkdiSRE96(v,5))
  return (v%4294967296)%(_pJzqTGI85+1)
end
local function _jYpBPhDG62(n)
  local v
  if n%2==1 then v=-(n+1)/2 else v=n/2 end
  if math.tointeger then return math.tointeger(v) end
  return v
end
local function _Y1dVlSpyCk22() return _l5jafl777(_jYpBPhDG62(_CrNY8JjEuQM211())%4294967296,_4WtoUBY2D61)%4294967296 end
local function _5oNfqUC12()
  local ln=_CrNY8JjEuQM211()
  if ln%1~=0 or ln<0 or ln>_EaRlZoY4phV82-_ZSmTEIIdo0k522+1 then __mock() end
  local t={}
  for i=1,ln do
    t[i]=string.char(_l5jafl777(_CRPTBUxz73:byte(_ZSmTEIIdo0k522),_x9zlFAotWGZEl23[_heolg0p91%4096+1]))
    _heolg0p91=_heolg0p91+1
    _ZSmTEIIdo0k522=_ZSmTEIIdo0k522+1
  end
  return table.concat(t)
end
local function _SOop7gHe1B31()
  local np=_CrNY8JjEuQM211()
  if np%1~=0 or np<1 or np>64 then __mock() end
  local ln=0
  local list={}
  for pi=1,np do
    local plen=_CrNY8JjEuQM211()
    if plen%1~=0 or plen<0 or plen>_EaRlZoY4phV82-_ZSmTEIIdo0k522+1 then __mock() end
    list[pi]={p=_ZSmTEIIdo0k522,o=_heolg0p91,n=plen}
    _ZSmTEIIdo0k522=_ZSmTEIIdo0k522+plen
    _heolg0p91=_heolg0p91+plen
    ln=ln+plen
  end
  return {np=np,list=list,n=ln}
end
local function _rQoEnFTheMVp12(p)
  local b0,b1,b2,b3,b4,b5,b6,b7=_CRPTBUxz73:byte(p,p+7)
  if not b7 then __mock() end
  local sgn=(b7>=128) and -1 or 1
  local ex=(b7%128)*16+math.floor(b6/16)
  local mt=(b6%16)*2^48+b5*2^40+b4*2^32+b3*2^24+b2*2^16+b1*2^8+b0
  if ex==2047 then
    if mt==0 then return sgn*(1/0) end
    return 0/0
  elseif ex==0 then
    return sgn*mt*2^-1074
  end
  return sgn*(1+mt*2^-52)*2^(ex-1023)
end
local function _StKe6GY7ejIF66(depth)
  depth=(depth or 0)+1
  if depth>256 then __mock() end
  _sb96OFIH937=_sb96OFIH937+1
  if _sb96OFIH937>_272jkpIgi6R_l51 then __mock() end
  local onum,nf,_salt
  _salt=_CrNY8JjEuQM211() onum=_Y1dVlSpyCk22() nf=_CrNY8JjEuQM211()
  local __bounds=_AsKwn3i74[onum]
  if not _pYilbSEzMRx49[onum] or not __bounds or nf<__bounds[1] or
     (__bounds[2]>=0 and nf>__bounds[2]) then __mock() end
  if _salt<0 or _salt>_pJzqTGI85 or _salt~=_EEzuCNe23(onum,nf,_sb96OFIH937) then __mock() end
  if nf%1~=0 or nf<0 or nf>_EaRlZoY4phV82-_ZSmTEIIdo0k522+1 then __mock() end
  local t={onum}
  for _=1,nf do
    local tag=_CRPTBUxz73:byte(_ZSmTEIIdo0k522); _ZSmTEIIdo0k522=_ZSmTEIIdo0k522+1
    if tag==_ky_akCcEWyMVj91 then t[#t+1]=_jYpBPhDG62(_CrNY8JjEuQM211())
    elseif tag==_Xra8u7Kv6Wj66 then t[#t+1]=_5oNfqUC12()
    elseif tag==_x2DLByL94 then t[#t+1]=_StKe6GY7ejIF66(depth)
    elseif tag==_kYQvJN435 then t[#t+1]=true
    elseif tag==_8QW4g5XZjtvSZ87 then t[#t+1]=false
    else __mock() end
  end
  return t
end
local _NC=_CrNY8JjEuQM211()
if _NC%1~=0 or _NC<0 or _NC>_EaRlZoY4phV82-_ZSmTEIIdo0k522+1 then __mock() end
local _TmOp7s378={}
for ci=1,_NC do
  local tg=_CRPTBUxz73:byte(_ZSmTEIIdo0k522); _ZSmTEIIdo0k522=_ZSmTEIIdo0k522+1
  if tg==_mgoiDRrB16 then _TmOp7s378[ci]={t=tg,v=_jYpBPhDG62(_CrNY8JjEuQM211())}
  elseif tg==_ANu6VMj66 then
    if _ZSmTEIIdo0k522+7>_EaRlZoY4phV82 then __mock() end
    _TmOp7s378[ci]={t=tg,p=_ZSmTEIIdo0k522}
    _ZSmTEIIdo0k522=_ZSmTEIIdo0k522+8
  elseif tg==_PHL3rNE_ekICx75 then
    local ref=_SOop7gHe1B31(); ref.t=tg; _TmOp7s378[ci]=ref
  elseif tg==_qRjzMFtaFhX9m80 or tg==_cbdiuqn98 then _TmOp7s378[ci]={t=tg}
  else __mock() end
end
local _NP=_CrNY8JjEuQM211()
if _NP%1~=0 or _NP<1 or _NP>_EaRlZoY4phV82-_ZSmTEIIdo0k522+1 then __mock() end
local _mtjUY7xBXHSW82={}
for pi=1,_NP do
  local np=_CrNY8JjEuQM211()
  if np%1~=0 or np<0 or np>_EaRlZoY4phV82-_ZSmTEIIdo0k522+1 then __mock() end
  local ps={}
  for ii=1,np do ps[ii]=_5oNfqUC12() end
  local vab=_CRPTBUxz73:byte(_ZSmTEIIdo0k522)
  if vab~=0 and vab~=1 then __mock() end
  local va=vab==1; _ZSmTEIIdo0k522=_ZSmTEIIdo0k522+1
  _mtjUY7xBXHSW82[pi]={p=ps,va=va,b=_StKe6GY7ejIF66(0)}
end
if _sb96OFIH937~=_272jkpIgi6R_l51 or _ZSmTEIIdo0k522~=_EaRlZoY4phV82+1 then __mock() end
__skx_reseal()

local _xID2mFk54={}
_xID2mFk54[1]=function(a,b)return a<b end
_xID2mFk54[2]=function(a,b)return a-b end
_xID2mFk54[3]=_1R_95a0jHNY50
_xID2mFk54[4]=_bKx5V51p80413
_xID2mFk54[5]=function(a,b)return a^b end
_xID2mFk54[6]=function(a,b)return a..b end
_xID2mFk54[7]=function(a,b)return a/b end
_xID2mFk54[8]=_SWxSmxLfGwEF19
_xID2mFk54[9]=function(a,b)local q=a/b return q-q%1 end
_xID2mFk54[10]=function(a,b)return a%b end
_xID2mFk54[11]=function(a,b)return a>=b end
_xID2mFk54[12]=function(a,b)return a<=b end
_xID2mFk54[13]=_WHZKpDeo7OK85
_xID2mFk54[14]=function(a,b)return a~=b end
_xID2mFk54[15]=function(a,b)return a*b end
_xID2mFk54[16]=function(a,b)return a==b end
_xID2mFk54[17]=function(a,b)return a+b end
_xID2mFk54[18]=_EJMFD7N9rN78
_xID2mFk54[19]=function(a,b)return a>b end
local _TqZpeDP583={}
_TqZpeDP583[1]=function(v)return #v end
_TqZpeDP583[2]=function(v)return _WHZKpDeo7OK85(v,4294967295) end
_TqZpeDP583[3]=function(v)return -v end
_TqZpeDP583[4]=function(v)return not v end
local __bc=0
for k,v in pairs(_xID2mFk54) do
  if type(k)~="number" or type(v)~="function" then __mock() end
  __bc=__bc+1
end
if __bc~=19 then __mock() end
local __uc=0
for k,v in pairs(_TqZpeDP583) do
  if type(k)~="number" or type(v)~="function" then __mock() end
  __uc=__uc+1
end
if __uc~=4 then __mock() end

  local _Q8ctM8jez85,_WBCnD6B76,_nnmxRdYZrH6M32={},{},{}
local __GSyJyh4u2_m84=_G or _ENV
local unpack=unpack or table.unpack
local function _HT4f79ndi_qvH91(...) return {n=select("#",...),...} end
local function _m9P6AVDCmgM4(v) return not (v==nil or v==false) end
local function _7_5NSriC2HuBf64(p) return {v={},p=p} end
local function _S0PVWkB4Mv93(sc,n,val) sc.v[n]=(val==nil) and _nnmxRdYZrH6M32 or val end
local function _OVJrFUV5v59(sc,n)
  local cc=sc
  while cc do
    local value=rawget(cc.v,n)
    if value~=nil then
      if value==_nnmxRdYZrH6M32 then return nil end
      return value
    end
    cc=cc.p
  end
  return __GSyJyh4u2_m84[n]
end
local function _w3mvlUNi068(sc,n,val)
  local cc=sc
  while cc do
    if rawget(cc.v,n)~=nil then _S0PVWkB4Mv93(cc,n,val) return end
    cc=cc.p
  end
  __GSyJyh4u2_m84[n]=val
end
local function _HOYgQqUwF29(sc,path,val)
  local parts={}
  for part in path:gmatch("[^\1]+") do parts[#parts+1]=part end
  if #parts==0 then __mock() end
  if #parts==1 then _w3mvlUNi068(sc,parts[1],val) return end
  local target=_OVJrFUV5v59(sc,parts[1])
  for i=2,#parts-1 do target=target[parts[i]] end
  target[parts[#parts]]=val
end
local _zkrvgX27K8zB91,_TzZTs7EC15
local _yY3niI596={}
local _DClZE5oJfdD785=function(ix)
  local ki=_l5jafl777(ix,_aGhmW07SdZQM_23)+1
  local cached=_yY3niI596[ki]
  if cached~=nil then return cached end
  local d=_TmOp7s378[ki]
  if type(d)~="table" then __mock() end
  local value
  if d.t==_mgoiDRrB16 then value=d.v
  elseif d.t==_ANu6VMj66 then value=_rQoEnFTheMVp12(d.p)
  elseif d.t==_PHL3rNE_ekICx75 then
    local chars={}
    local cursor=0
    for pi=1,d.np do
      local part=d.list[pi]
      for i=1,part.n do
        cursor=cursor+1
        chars[cursor]=string.char(_l5jafl777(_Y8YNYYP88:byte(part.p+i-1),_x9zlFAotWGZEl23[(part.o+i-1)%4096+1]))
      end
    end
    if cursor~=d.n then __mock() end
    value=table.concat(chars)
  elseif d.t==_qRjzMFtaFhX9m80 then value=true
  elseif d.t==_cbdiuqn98 then value=false
  else __mock() end
  _yY3niI596[ki]=value
  return value
end
local function _U6C3KgKBv_UVA68(x,sc)
  local op=x[1]
  if op==166 then local va=sc.va or {n=0} return va,(va.n or #va) end
  if op==78 or op==48 then
    local fna,args,st,argc
    if op==48 then
      local base=_zkrvgX27K8zB91(x[2],sc)
      fna=base[_DClZE5oJfdD785(x[3])]
      args={base}
      st,argc=4,1
    else
      fna=_zkrvgX27K8zB91(x[2],sc)
      args={}
      st,argc=3,0
    end
    for i=st,#x do
      local a=x[i]
      local last=i==#x
      if a[1]==166 then
        local va=sc.va or {n=0} local cnt=va.n or #va
        if last then
          for kk=1,cnt do argc=argc+1 args[argc]=va[kk] end
        else
          argc=argc+1 args[argc]=va[1]
        end
      elseif a[1]==78 or a[1]==48 then
        local values,count=_U6C3KgKBv_UVA68(a,sc)
        if last then
          for kk=1,count do argc=argc+1 args[argc]=values[kk] end
        else
          argc=argc+1 args[argc]=values[1]
        end
      else
        argc=argc+1 args[argc]=_zkrvgX27K8zB91(a,sc)
      end
    end
    local rs=_HT4f79ndi_qvH91(fna(unpack(args,1,argc)))
    return rs,rs.n
  end
  local rs=_HT4f79ndi_qvH91(_zkrvgX27K8zB91(x,sc))
  return rs,1
end
_zkrvgX27K8zB91=function(x,sc)
  local op=x[1]
  if op==262 then return _DClZE5oJfdD785(x[2])
  elseif op==33 then return nil
  elseif op==243 then return true
  elseif op==112 then return false
  elseif op==13 then return _OVJrFUV5v59(sc,x[2])
  elseif op==129 then return _zkrvgX27K8zB91(x[2],sc)[_zkrvgX27K8zB91(x[3],sc)]
  elseif op==166 then local va=sc.va or {} return va[1]
  elseif op==78 or op==48 then
    local tt=_U6C3KgKBv_UVA68(x,sc) return tt[1]
  elseif op==87 then
    local aa=_zkrvgX27K8zB91(x[2],sc)
    if _m9P6AVDCmgM4(aa) then return _zkrvgX27K8zB91(x[3],sc) end return aa
  elseif op==193 then
    local aa=_zkrvgX27K8zB91(x[2],sc)
    if _m9P6AVDCmgM4(aa) then return aa end return _zkrvgX27K8zB91(x[3],sc)
  elseif op==72 then
    local ff=_xID2mFk54[x[2]]
    if ff then return ff(_zkrvgX27K8zB91(x[3],sc),_zkrvgX27K8zB91(x[4],sc)) end
    __mock()
  elseif op==134 then
    local ff=_TqZpeDP583[x[2]]
    if ff then return ff(_zkrvgX27K8zB91(x[3],sc)) end
    __mock()
  elseif op==259 then
    local t={} local ii=1
    for j=2,#x do
      local it=x[j]
      if it[1]==254 then
        local item=it[2]
        if j==#x and (item[1]==78 or item[1]==48 or item[1]==166) then
          local values,count=_U6C3KgKBv_UVA68(item,sc)
          for k=1,count do t[ii]=values[k] ii=ii+1 end
        else
          t[ii]=_zkrvgX27K8zB91(item,sc) ii=ii+1
        end
      else t[_zkrvgX27K8zB91(it[2],sc)]=_zkrvgX27K8zB91(it[3],sc) end
    end
    return t
  elseif op==62 then
    local id=x[2] local dsc=sc
    return function(...)
      local pr=_mtjUY7xBXHSW82[id]
      local ar=_HT4f79ndi_qvH91(...) local nn=ar.n
      local nsc=_7_5NSriC2HuBf64(dsc)
      for i=1,#pr.p do _S0PVWkB4Mv93(nsc,pr.p[i],ar[i]) end
      if pr.va then
        local va={n=math.max(0,nn-#pr.p)}
        for i=#pr.p+1,nn do va[i-#pr.p]=ar[i] end
        nsc.va=va
      end
      return _QQOrsWsJbFel66(id,nsc)
    end
  end
  __mock()
end
local function _KSyeq36JV75(stv,sc)
  local vals,n={},0
  for vi=2,#stv do
    local vx=stv[vi]
    if vi==#stv and (vx[1]==78 or vx[1]==166 or vx[1]==48) then
      local expanded,count=_U6C3KgKBv_UVA68(vx,sc)
      for k=1,count do n=n+1 vals[n]=expanded[k] end
    else
      n=n+1 vals[n]=_zkrvgX27K8zB91(vx,sc)
    end
  end
  return vals,n
end
local function _IsOTVaN8dHhU76(tg,stv,sc)
  local vals=_KSyeq36JV75(stv,sc)
  local refs={}
  for ti=2,#tg do
    local target=tg[ti]
    if target[1]==106 then refs[ti-1]={name=target[2]}
    else refs[ti-1]={obj=_zkrvgX27K8zB91(target[2],sc),key=_zkrvgX27K8zB91(target[3],sc)} end
  end
  for index,ref in ipairs(refs) do
    if ref.name then _w3mvlUNi068(sc,ref.name,vals[index])
    else ref.obj[ref.key]=vals[index] end
  end
end
local function _xUeWFNE1KNQ_60(names,stv,sc)
  local vals=_KSyeq36JV75(stv,sc)
  for ni=2,#names do _S0PVWkB4Mv93(sc,names[ni],vals[ni-1]) end
end
local function _l3JKWs8Q190(target,binid,rhs,sc)
  local fn=_xID2mFk54[binid]
  if not fn then __mock() end
  if target[1]==106 then
    local name=target[2]
    _w3mvlUNi068(sc,name,fn(_OVJrFUV5v59(sc,name),_zkrvgX27K8zB91(rhs,sc)))
  else
    local obj=_zkrvgX27K8zB91(target[2],sc)
    local key=_zkrvgX27K8zB91(target[3],sc)
    obj[key]=fn(obj[key],_zkrvgX27K8zB91(rhs,sc))
  end
end
_TzZTs7EC15=function(sq,sc)
  for si=2,#sq do
    local st=sq[si]
    local op=st[1]
    if op==20 then
      _S0PVWkB4Mv93(sc,st[2],_zkrvgX27K8zB91(st[3],sc))
    elseif op==90 then _xUeWFNE1KNQ_60(st[2],st[3],sc)
    elseif op==232 then _HOYgQqUwF29(sc,_DClZE5oJfdD785(st[2]),_zkrvgX27K8zB91(st[4],sc))
    elseif op==179 then _zkrvgX27K8zB91(st[2],sc)
    elseif op==26 then _IsOTVaN8dHhU76(st[2],st[3],sc)
    elseif op==210 then _l3JKWs8Q190(st[2],st[3],st[4],sc)
    elseif op==147 then
      local r=_TzZTs7EC15(st[2],_7_5NSriC2HuBf64(sc))
      if r then return r end
    elseif op==221 then
      while true do
        if not _m9P6AVDCmgM4(_zkrvgX27K8zB91(st[2],sc)) then break end
        local r=_TzZTs7EC15(st[3],_7_5NSriC2HuBf64(sc))
        if r==_Q8ctM8jez85 then break end
        if r~=nil and r~=_WBCnD6B76 then return r end
      end
    elseif op==206 then
      while true do
        local nsc=_7_5NSriC2HuBf64(sc)
        local r=_TzZTs7EC15(st[2],nsc)
        if r==_Q8ctM8jez85 then break end
        if r~=nil and r~=_WBCnD6B76 then return r end
        if _m9P6AVDCmgM4(_zkrvgX27K8zB91(st[3],nsc)) then break end
      end
    elseif op==141 then
      local dn=false
      for cj=2,#st[2] do
        local cl=st[2][cj]
        if _m9P6AVDCmgM4(_zkrvgX27K8zB91(cl[2],sc)) then
          dn=true
          local r=_TzZTs7EC15(cl[3],_7_5NSriC2HuBf64(sc))
          if r then return r end
          break
        end
      end
      if not dn and type(st[3])=="table" then
        local r=_TzZTs7EC15(st[3],_7_5NSriC2HuBf64(sc))
        if r then return r end
      end
    elseif op==172 then
      local s0=_zkrvgX27K8zB91(st[3],sc) local e0=_zkrvgX27K8zB91(st[4],sc)
      local sp=(st[5]~=false) and _zkrvgX27K8zB91(st[5],sc) or 1
      if sp==0 then error("'for' step is zero") end
      local vv=st[2]
      local i=s0
      while (sp>0 and i<=e0) or (sp<0 and i>=e0) do
        local nsc=_7_5NSriC2HuBf64(sc) _S0PVWkB4Mv93(nsc,vv,i)
        local r=_TzZTs7EC15(st[6],nsc)
        if r==_Q8ctM8jez85 then break end
        if r~=nil and r~=_WBCnD6B76 then return r end
        i=i+sp
      end
    elseif op==99 then
      local init=_KSyeq36JV75(st[3],sc)
      local ff,s2,c2=init[1],init[2],init[3]
      local vars={}
      for vnm in _DClZE5oJfdD785(st[2]):gmatch("[^\1]+") do vars[#vars+1]=vnm end
      while true do
        local rs=_HT4f79ndi_qvH91(ff(s2,c2))
        if rs[1]==nil then break end
        c2=rs[1]
        local nsc=_7_5NSriC2HuBf64(sc)
        for i=1,#vars do _S0PVWkB4Mv93(nsc,vars[i],rs[i]) end
        local r=_TzZTs7EC15(st[4],nsc)
        if r==_Q8ctM8jez85 then break end
        if r~=nil and r~=_WBCnD6B76 then return r end
      end
    elseif op==296 then
      local res,nr=_KSyeq36JV75(st[2],sc)
      return {list=res,n=nr}
    elseif op==288 then return _Q8ctM8jez85
    elseif op==58 then return _WBCnD6B76
    else __mock() end
  end
end
function _QQOrsWsJbFel66(id,nsc)
  local pr=_mtjUY7xBXHSW82[id]
  local r=_TzZTs7EC15(pr.b,nsc)
  if type(r)=="table" and r.list then return unpack(r.list,1,r.n) end
end
local _OVJrFUV5v59_orig=_OVJrFUV5v59
_OVJrFUV5v59=function(sc,n)
  local cc=sc
  while cc do
    local v=rawget(cc.v,n)
    if v~=nil then
      if not __skx_log.reentry then
        if v==_nnmxRdYZrH6M32 then __skx_log.emit("GLOBAL_READ","ok",{h=__skx_log.hash_name(n),hit="local_nil"})
        else __skx_log.emit("GLOBAL_READ","ok",{h=__skx_log.hash_name(n),hit="local"}) end
      end
      if v==_nnmxRdYZrH6M32 then return nil end
      return v
    end
    cc=cc.p
  end
  local gv=__GSyJyh4u2_m84[n]
  if not __skx_log.reentry then
    if gv==nil then __skx_log.emit("GLOBAL_MISS","ok",{h=__skx_log.hash_name(n)})
    else __skx_log.emit("GLOBAL_READ","ok",{h=__skx_log.hash_name(n),hit="global"}) end
  end
  return gv
end
local _w3mvlUNi068_orig=_w3mvlUNi068
_w3mvlUNi068=function(sc,n,val)
  local cc=sc
  while cc do
    if rawget(cc.v,n)~=nil then
      if not __skx_log.reentry then __skx_log.emit("GLOBAL_WRITE","ok",{h=__skx_log.hash_name(n)}) end
      return _w3mvlUNi068_orig(sc,n,val)
    end
    cc=cc.p
  end
  if not __skx_log.reentry then __skx_log.emit("GLOBAL_WRITE","ok",{h=__skx_log.hash_name(n),hit="global"}) end
  return _w3mvlUNi068_orig(sc,n,val)
end

do
  if __skx_canary_recheck then __skx_canary_recheck() end
  __skx_reseal()
end
_QQOrsWsJbFel66(1,_7_5NSriC2HuBf64(nil))
