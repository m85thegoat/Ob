# Stronger Env Logger: Design Plan

**Status:** planning only. This document proposes work; it does not implement an
Env Logger or change the runtime.

## Scope and safety

Here, “Env Logger” means an opt-in, authorized diagnostics component for a
generated protected Lua/Luau script. It should report bounded environment
metadata and runtime events without dumping source, decrypted payloads,
constants, keys, or user values. It must not bypass, disable, or weaken the
existing integrity and anti-tamper protections.

This plan is based on `bin/Obfuscator.lua` and the relevant `src` files, not the
Discord bot’s `.l` command.

## What the current code does

| Area | Current behavior | Design consequence |
|---|---|---|
| CLI | `bin/Obfuscator.lua:47-123` parses mode, intensity, seed, and protection flags, then `:151-194` calls `build.build`. | Logger policy should enter through build options, remain off by default, and be recorded in build metadata. |
| Build pipeline | `src/build.lua:71-117` chooses the seed, mode, protected status, and strict profile. Source and VM output diverge after `:130`. | A common event schema is needed, with mode-specific adapters. |
| Source output | `src/build.lua:146-217` encrypts segments, verifies them, loads decrypted source, wipes segment/source locals, and runs the payload. | Log phase boundaries, not plaintext source or loader contents. Do not assume a portable environment proxy around `load`. |
| VM output | `src/build.lua:225-369` compiles tuples, whitens constant indexes, authenticates/encrypts/splits the blob, and emits the interpreter. | VM mode has central name-resolution points that can support precise, aggregated global events. |
| Anti-tamper | `src/protection.lua:123-269` captures primitives and checks their types/identities; `:271-324` checks debug hooks, native primitives, and strict environment signatures; `:328-388` recomputes guard tokens. | Logger initialization must use captured primitives and must fail closed if it fails. It must never replace protected primitives. |
| Anti-envlog canary | `src/protections.lua:94-152` snapshots `print`, `warn`, and `error`, runs an execution oracle, and exposes `__skx_canary_recheck()`. | Keep telemetry independent of mutable output channels. Strengthen the canary separately; do not use the logger as a bypass. |
| VM environment | `src/vm/emit2.lua:471-506` stores locals in a scope chain and falls back to `_G`/`_ENV`; `:578-633` evaluates names and constants; `:648-675` performs assignments. | Instrument `_gL`, `_sG`, and `_set_path` only for VM user operations, with recursion guards and aggregation. |
| Integrity | `src/integrity.lua:146-220` and later emitted code verify segment count, lengths, hashes, and re-seal state. | Logger state must be outside the payload manifest, or be separately authenticated; logger errors must never turn a failed integrity check into success. |
| Tests | `tests/run_tests.lua:140-200` covers both modes/runtimes, mutations, hostile globals, and a currently non-asserting print-hook smoke test. | Add logger-specific correctness, privacy, reentrancy, and failure tests before enabling it. |

## Current blind spots to address

1. There is no unified event stream. Guard checks are boolean/fail-closed, so a
   host cannot distinguish a changed primitive, a debug hook, a suspicious key,
   or a malformed payload without exposing sensitive internals.
2. The VM’s `_gL`/`_sG` path covers VM `NAME` reads and writes, but direct user
   indexing of `_G`/`_ENV` goes through ordinary table operations. Nested
   `SETGFN` paths also write tables directly. These must be documented as
   visibility limits or handled by an explicitly opted-in proxy.
3. Source mode executes code through `load`/`loadstring` with runtime-dependent
   environment semantics. A blanket global hook would be incompatible with the
   Lua 5.1–5.4, LuaJIT, and Luau targets.
4. `__skx_canary_recheck()` captures a print identity/representation but only
   verifies that `print` can be called; a callable wrapper can therefore pass
   that individual check. It verifies `warn` and `error` more directly, but
   `tostring`-based fingerprints are not cryptographic identity proofs.
5. `__skx_guard()` has a 97-tick branch only when it is called. The visible
   source/VM call sites are primarily forced phase-boundary calls, so continuous
   cadence must be confirmed before it is advertised as continuous monitoring.
6. Strict environment scanning hashes exact string keys from the environment.
   Aliases, indirect references, metatable-provided members, and behaviorally
   equivalent wrappers are outside that scan’s scope.
7. The current failure path uses captured `print` and `error` to emit a mockery
   message and abort. A logger that calls those channels can recurse or alter
   failure behavior.

## Goals

- Provide a small, structured, opt-in telemetry stream for authorized debugging.
- Correlate events with build identity, mode, strictness, runtime, and phase.
- Report environment shape, capability presence, guard outcomes, and selected
  global read/write activity without recording raw values.
- Preserve fail-closed behavior, payload wiping, primitive pinning, and seal
  checks in all configurations.
- Work with the existing source/VM split and remain portable across the stated
  Lua/Luau runtimes.
- Bound CPU, memory, event count, and output size so logging cannot become a
  denial-of-service vector.

## Non-goals

- Dumping decrypted source, VM blobs, constant strings, closures, upvalues,
  stack traces containing user data, or complete `_G`/`_ENV` values.
- Capturing arbitrary third-party environments or defeating their protections.
- Replacing `print`, `warn`, `error`, `debug`, `load`, or other primitives.
- Promising visibility into direct table mutation, native executor internals, or
  every source-mode global access.
- Making telemetry an integrity oracle that attackers can use to reconstruct
  guard tokens or payload keys.

## Proposed architecture

### 1. Build-time policy

Add a future, explicit logger policy to the build options rather than silently
enabling it. The policy should contain:

- `enabled` (default `false`);
- mode: `off`, `summary`, or `diagnostic`;
- event budget and ring-buffer size;
- sampling rates for global reads, writes, and misses;
- allowlisted metadata fields;
- redaction rules and a keyed-name hashing salt;
- sink mode (`callback`, `pull`, or `discard`);
- whether strict-profile failures produce a summary event before abort.

The effective policy, logger schema version, and a one-way build correlation ID
may be returned in `meta` from `src/build.lua`; never return guard tokens,
payload keys, or raw seeds solely for logging.

### 2. Runtime logger core

Plan a dedicated generator/module (for example, `src/envlogger.lua`) with three
parts:

1. **Policy compiler:** validates options and emits only the selected features.
2. **Runtime state:** a bounded ring buffer, sequence counter, phase marker,
   drop counter, reentrancy flag, and circuit breaker.
3. **Sink adapter:** invokes an explicitly supplied host callback or exposes a
   pullable batch; otherwise it discards events. Sink failures are recorded once
   and then disable the sink without affecting the protected payload.

The logger must capture the same pristine aliases used by the guard, keep all
state local, avoid `tostring` on arbitrary user objects, and never call a
mutable output channel during normal operation.

### 3. Event schema

Every event should have a small common envelope:

| Field | Meaning |
|---|---|
| `schema` | Logger schema version. |
| `build_id` | One-way correlation identifier for this build. |
| `seq` | Monotonic event sequence. |
| `phase` | `boot`, `integrity`, `decode`, `load`, `user`, `shutdown`, or `failure`. |
| `mode` | `source` or `vm`. |
| `runtime` | Coarse `_VERSION`/capability label, not a full environment dump. |
| `kind` | Event type. |
| `status` | `ok`, `changed`, `blocked`, `dropped`, or `error`. |
| `sampled` | Whether the event was sampled or aggregated. |

Recommended event kinds:

- `BOOT_SNAPSHOT`: runtime/version capability booleans, strictness, and logger
  policy ID;
- `ENV_SHAPE`: count and keyed digest of selected environment names, with raw
  names only for an explicit safe allowlist;
- `PRIMITIVE_CHECK`: category-level result for a pinned primitive family;
- `HOOK_STATE`: debug-hook and output-channel status;
- `GLOBAL_READ`, `GLOBAL_MISS`, `GLOBAL_WRITE`, `PATH_WRITE`: hashed name/path,
  value type, nil/present state, and aggregate count—never the value;
- `INTEGRITY_PHASE`: start/end and result of manifest, payload, wire, or seal
  verification;
- `GUARD_FAILURE`: stable reason class such as `primitive`, `hook`,
  `environment_signature`, `oracle`, or `seal`, without sensitive operands;
- `LOGGER_DROP`: number of events discarded because of budget, recursion, or
  sink failure;
- `END`: final counts and elapsed coarse timing.

Use keyed hashes for names by default so logs can correlate repeated accesses
without exposing names. Redact keys matching credentials, tokens, cookies,
source/payload markers, `__SKX_*`, crypto material, and user-configured secret
patterns. Values should be represented only as safe categories (`nil`, boolean,
number, string length bucket, table, function, userdata, thread).

### 4. Source-mode integration

Use only stable phase boundaries already present in `src/build.lua:189-217`:

1. logger bootstrap after protected primitive capture;
2. integrity/decrypt start and success;
3. loader start and success/failure;
4. segment/source wipe completion;
5. canary/guard re-check result;
6. user payload start/end or fail-closed abort.

Do not instrument every source global expression by rewriting the AST in the
first version. That would change semantics, interact with `load` environment
differences, and create a new plaintext/value-leak surface. If detailed source
global events are later required, make them a separate runtime-specific feature
with explicit Lua-version capability checks.

### 5. VM-mode integration

The VM has a safer central observation point. Add a future, opt-in adapter around
the logical operations represented by:

- `_gL`: classify local-hit, parent-hit, global-hit, or miss;
- `_sG`: classify local update versus global write;
- `_set_path`: classify nested path writes and invalid targets;
- `_XP`: mark function/proto entry and return summary;
- `KKREF`: count constant reads by type/index class only, never decoded content.

Instrument logical user operations, not guard/decoder internals. A phase flag and
an internal-operation/reentrancy guard are required, because logger code itself
must not generate recursive global events. Reserve and mangle logger symbols in
the same way as the existing VM machine region.

Direct `_G`/`_ENV` table indexing remains a documented blind spot unless a
separate proxy is explicitly enabled and proven safe for the target runtime.

### 6. Guard and canary integration

- Add reason-class callbacks at the existing fail boundary without changing the
  fail function’s externally visible behavior.
- Keep logger initialization independent from `print`, `warn`, and `error`.
- Strengthen the channel canary as its own change: compare captured print
  identity where the runtime makes that meaningful, add a behavior/fingerprint
  test that a wrapper cannot trivially satisfy, and retain graceful behavior for
  runtimes with different function representations.
- Treat logger failures as telemetry loss, not as permission to continue after a
  guard or integrity failure.
- Verify and document the actual call schedule of `__skx_guard`; do not claim
  periodic protection unless a real runtime call site exists.

### 7. Sink and transport

Prefer, in order:

1. a host-provided callback captured once at boot;
2. a pull API that returns an already-redacted batch to trusted host code;
3. discard mode for production builds.

There should be no default file, network, Discord, or console sink in generated
scripts. If authenticity of telemetry matters, use a logger-specific session
nonce/MAC at the host boundary; never reuse anti-tamper tokens or payload keys.

## Delivery phases

1. **Specification:** settle target runtimes, authorized users, sink, privacy
   policy, event budget, and whether names are hashed or allowlisted.
2. **Common core:** add policy validation, schema documentation, redaction,
   hashing, ring-buffer behavior, and a no-op path. No runtime hooks yet.
3. **Boundary telemetry:** add source and VM boot/phase/integrity summaries.
4. **VM detail:** add aggregated `_gL`/`_sG`/`_set_path` observations with
   feature flags and symbol mangling.
5. **Failure/canary work:** add reason classes, sink circuit breaking, and
   stronger channel-canary tests without weakening fail-closed behavior.
6. **Hardening and rollout:** fuzz malformed events/options, measure overhead,
   review generated output for leakage, document blind spots, and keep the
   feature disabled until all acceptance criteria pass.

## Verification plan

### Functional

- Build and run source/VM output under Lua 5.4 and LuaJIT; include Luau in the
  supported external matrix.
- Exercise local shadowing, global reads, missing names, local/global writes,
  nested function declarations, varargs, loops, and errors.
- Confirm VM aggregates distinguish local hits from global fallback and do not
  count guard/decoder operations as user events.
- Confirm source mode emits phase events even though detailed global coverage is
  intentionally limited.

### Security and privacy

- Grep generated output and serialized events for source text, known constants,
  payload markers, guard tokens, keys, mockery text, and redacted values.
- Mutate segments, manifests, wrapped keys, wire headers, primitive globals,
  debug hooks, and output channels; each must still fail closed, with at most a
  bounded failure summary.
- Replace the sink with a throwing, recursive, slow, or mutating callback; the
  payload must not gain execution or integrity privileges.
- Test buffer overflow, event storms, logger reentrancy, unavailable `debug`,
  absent `warn`, and unavailable `load`/`loadstring`.

### Compatibility and performance

- Run the existing suite unchanged, then add logger cases to
  `tests/run_tests.lua` for protections on/off, strict/non-strict, and logger
  off/summary/diagnostic.
- Assert that logger-off output and behavior are unchanged from the current
  build for a fixed seed.
- Set a measured target before implementation (for example, bounded memory and
  single-digit percentage overhead in summary mode); reject unbounded per-read
  serialization.

## Acceptance criteria

The design is ready to implement only when:

- logging is explicitly enabled and has a safe no-op default;
- every event is bounded, versioned, correlated, and redacted;
- no event contains raw source, decrypted payload, constants, keys, or arbitrary
  user values;
- logger and sink failure cannot bypass integrity, anti-tamper, canary, or
  payload-wipe behavior;
- source and VM visibility limits are documented and tested;
- existing cross-runtime and tamper tests remain green, with new logger tests
  covering direct `_G` access and other known blind spots;
- the generated output contains no unintended logger sink or secret material.

## Decisions needed before implementation

1. Is the target environment primarily Roblox Luau, standalone Lua, or both?
2. Should the sink be a callback, a trusted pull API, or discard-only in
   production?
3. Are raw allowlisted names acceptable, or must all names be keyed hashes?
4. Is summary telemetry sufficient, or is VM global read/write aggregation
   required?
5. What event count, memory, and latency budgets are acceptable?

