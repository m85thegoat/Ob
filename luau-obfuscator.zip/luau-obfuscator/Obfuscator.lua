#!/usr/bin/env lua
-- Obfuscator.lua :: Skynox command-line entry point (Lua 5.4 / LuaJIT)

local function script_dir()
  local source = debug and debug.getinfo and debug.getinfo(1, "S").source
  source = source or (arg and arg[0]) or "Obfuscator.lua"
  source = source:gsub("^@", "")
  return source:match("^(.*)[/\\]") or "."
end

local root = script_dir()
package.path = root .. "/src/?.lua;" ..
               root .. "/src/vm/?.lua;" ..
               root .. "/src/passes/?.lua;" .. package.path

local USAGE = [[
------[Skynox Obfuscator]
Usage: lua5.4 Obfuscator.lua <input.lua|input.luau> [options]

Options:
  -o, --output <file>       Output path (default: <input>.obf.lua)
  --maximum                 Use VM mode and paranoid intensity
  --mode <source|vm>        Output mode (default: source)
  --intensity <level>       light, medium, or paranoid (default: medium)
  --seed <integer>          Reproducible build seed
  --no-rename               Disable local identifier renaming
  --no-deadcode             Disable source-mode dead-code injection
  --protections <on|off>    Toggle the source-mode protection wrapper
  --cfflatten <on|off>      Toggle source-mode control-flow flattening
  --envlogger <off|summary|diagnostic>  Opt-in telemetry logger (default off)
  -h, --help                Show this help
]]

local function fail(message, show_usage)
  io.stderr:write("Obfuscator: " .. message .. "\n")
  if show_usage then io.stderr:write("\n" .. USAGE) end
  return nil, message
end

local function take_value(argv, index, option)
  local value = argv[index + 1]
  if value == nil then
    return fail("missing value for " .. option, true)
  end
  return value, index + 1
end

local function parse_args(argv)
  local parsed = { opts = {} }
  local i = 1

  while i <= #argv do
    local token = argv[i]
    if token == "-h" or token == "--help" then
      parsed.help = true
    elseif token == "-o" or token == "--output" then
      local value, next_i = take_value(argv, i, token)
      if not value then return nil end
      parsed.output = value
      i = next_i
    elseif token == "--maximum" then
      parsed.opts.maximum = true
      parsed.opts.mode = "vm"
      parsed.opts.intensity = "paranoid"
      parsed.opts.protections = "on"
    elseif token == "--mode" then
      local value, next_i = take_value(argv, i, token)
      if not value then return nil end
      if value ~= "source" and value ~= "vm" then
        return fail("invalid mode '" .. value .. "' (expected source or vm)", true)
      end
      parsed.opts.mode = value
      i = next_i
    elseif token == "--intensity" then
      local value, next_i = take_value(argv, i, token)
      if not value then return nil end
      if value ~= "light" and value ~= "medium" and value ~= "paranoid" then
        return fail("invalid intensity '" .. value ..
                    "' (expected light, medium, or paranoid)", true)
      end
      parsed.opts.intensity = value
      i = next_i
    elseif token == "--seed" then
      local value, next_i = take_value(argv, i, token)
      if not value then return nil end
      local seed = tonumber(value)
      if not seed or seed ~= seed or seed == math.huge or seed == -math.huge or
         seed ~= math.floor(seed) or math.abs(seed) > 9007199254740991 then
        return fail("invalid seed '" .. value .. "' (expected a safe integer)", true)
      end
      parsed.opts.seed = seed
      i = next_i
    elseif token == "--no-rename" then
      parsed.opts.no_rename = true
    elseif token == "--no-deadcode" then
      parsed.opts.no_deadcode = true
    elseif token == "--protections" or token == "--cfflatten" then
      local value, next_i = take_value(argv, i, token)
      if not value then return nil end
      if value ~= "on" and value ~= "off" then
        return fail("invalid value '" .. value .. "' for " .. token ..
                    " (expected on or off)", true)
      end
      if token == "--protections" then
        parsed.opts.protections = value
      else
        parsed.opts.cfflatten = value
      end
      i = next_i
    elseif token == "--envlogger" then
      local value, next_i = take_value(argv, i, token)
      if not value then return nil end
      if value ~= "off" and value ~= "summary" and value ~= "diagnostic" then
        return fail("invalid envlogger '" .. value .. "' (expected off, summary or diagnostic)", true)
      end
      parsed.opts.envlogger = (value == "off") and false or {enabled=true, mode=value}
      i = next_i
    elseif token:sub(1, 1) == "-" then
      return fail("unknown option '" .. token .. "'", true)
    elseif parsed.input then
      return fail("multiple input files supplied ('" .. parsed.input ..
                  "' and '" .. token .. "')", true)
    else
      parsed.input = token
    end
    i = i + 1
  end

  if not parsed.help and not parsed.input then
    return fail("no input file supplied", true)
  end
  return parsed
end

local function default_output(input)
  local base, count = input:gsub("%.[Ll][Uu][Aa][Uu]?$", "")
  if count == 0 then base = input end
  return base .. ".obf.lua"
end

local function read_file(path)
  local file, err = io.open(path, "rb")
  if not file then return nil, err end
  local source, read_err = file:read("*a")
  file:close()
  if not source then return nil, read_err end
  return source
end

local function write_file(path, contents)
  local file, err = io.open(path, "wb")
  if not file then return nil, err end
  local ok, write_err = file:write(contents)
  local close_ok, close_err = file:close()
  if not ok then return nil, write_err end
  if not close_ok then return nil, close_err end
  return true
end

local function main(argv)
  local parsed = parse_args(argv)
  if not parsed then return 1 end
  if parsed.help then
    io.write(USAGE)
    return 0
  end

  local output = parsed.output or default_output(parsed.input)
  if output == parsed.input then
    fail("output path must differ from the input path")
    return 1
  end

  local source, read_err = read_file(parsed.input)
  if not source then
    fail("cannot read '" .. parsed.input .. "': " .. tostring(read_err))
    return 1
  end

  local loaded, build = pcall(require, "build")
  if not loaded then
    fail("cannot load the build pipeline: " .. tostring(build))
    return 1
  end

  local built, result, meta = pcall(build.build, source, parsed.opts)
  if not built then
    fail("build failed: " .. tostring(result))
    return 1
  end

  local written, write_err = write_file(output, result)
  if not written then
    fail("cannot write '" .. output .. "': " .. tostring(write_err))
    return 1
  end

  meta = meta or {}
  local seed = tonumber(meta.seed) or 0
  print("--" .. tostring(build.WATERMARK or "------[Skynox Obfuscator]"))
  print(("built %s -> %s [mode=%s seed=%.0f bytes=%d]"):format(
    parsed.input, output, tostring(meta.mode or "?"), seed, #result))
  return 0
end

local argv = {}
for i = 1, #(arg or {}) do argv[i] = arg[i] end
local exit_code = main(argv)
io.stdout:flush()
io.stderr:flush()
os.exit(exit_code)
