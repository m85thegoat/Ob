local has_http, http = pcall(require, "coro-http")

local skx_deobfuscator = {}

local function unescape_hex_bytes(str)
    if not str then return "" end
    return str:gsub("\\x(%x%x)", function(hex)
        return string.char(tonumber(hex, 16))
    end)
end

local function is_valid_text(str)
    if not str or #str < 2 then return false end
    local printable = 0
    for i = 1, #str do
        local b = str:byte(i)
        if (b >= 32 and b <= 126) or b == 10 or b == 13 or b == 9 then
            printable = printable + 1
        end
    end
    return (printable / #str) >= 0.75
end

local function is_honeypot(str)
    local l = str:lower()
    return l:find("deobfuscate") or l:find("env log") or l:find("leaker") or l:find("skynox") or l:find("skx")
end

local function extract_vm_constants(fn, visited, results)
    visited = visited or {}
    results = results or {}
    
    if type(fn) ~= "function" or visited[fn] then return results end
    visited[fn] = true

    local idx = 1
    while true do
        local name, val = debug.getupvalue(fn, idx)
        if not name then break end

        local val_type = type(val)
        if val_type == "string" and is_valid_text(val) and not is_honeypot(val) then
            results[#results + 1] = { type = "String Constant", value = val }
        elseif val_type == "table" and not visited[val] then
            visited[val] = true
            for k, v in pairs(val) do
                if type(k) == "string" and is_valid_text(k) and not is_honeypot(k) then
                    results[#results + 1] = { type = "VM Key/Global", value = k }
                end
                if type(v) == "string" and is_valid_text(v) and not is_honeypot(v) then
                    results[#results + 1] = { type = "VM Table Entry", value = v }
                elseif type(v) == "function" then
                    extract_vm_constants(v, visited, results)
                end
            end
        elseif val_type == "function" then
            extract_vm_constants(val, visited, results)
        end

        idx = idx + 1
    end

    return results
end

local function make_stealth_dummy(name, trace_log)
    local dummy = {}
    setmetatable(dummy, {
        __index = function(_, key)
            trace_log[#trace_log + 1] = string.format("Indexed Global: %s.%s", tostring(name), tostring(key))
            return make_stealth_dummy(tostring(name) .. "." .. tostring(key), trace_log)
        end,
        __call = function(_, ...)
            local args = { ... }
            local formatted_args = {}
            for i, a in ipairs(args) do
                formatted_args[i] = type(a) == "string" and ('"' .. a .. '"') or tostring(a)
            end
            trace_log[#trace_log + 1] = string.format("Called VM Method: %s(%s)", tostring(name), table.concat(formatted_args, ", "))
            return make_stealth_dummy(tostring(name) .. "()", trace_log)
        end,
        __tostring = function() return tostring(name) end,
        __concat = function(a, b) return tostring(a) .. tostring(b) end,
        __add = function() return 0 end,
        __sub = function() return 0 end,
        __mul = function() return 0 end,
        __div = function() return 0 end,
        __eq = function() return true end,
        __len = function() return 0 end
    })
    return dummy
end

local bit32_mock = {
    band = function(a, b) return (a or 0) & (b or 0) end,
    bor = function(a, b) return (a or 0) | (b or 0) end,
    bxor = function(a, b) return (a or 0) ~ (b or 0) end,
    bnot = function(a) return ~(a or 0) end,
    lshift = function(a, b) return (a or 0) << (b or 0) end,
    rshift = function(a, b) return (a or 0) >> (b or 0) end,
    arshift = function(a, b) return (a or 0) >> (b or 0) end,
    extract = function(n, field, width)
        width = width or 1
        return ((n or 0) >> field) & ((1 << width) - 1)
    end,
    replace = function(n, v, field, width)
        width = width or 1
        local mask = ((1 << width) - 1) << field
        return ((n or 0) & (~mask)) | (((v or 0) << field) & mask)
    end
}

local function create_vm_sandbox(captured_closures, trace_log, char_strings)
    local sandbox = {}

    sandbox._G = sandbox
    sandbox.shared = sandbox
    sandbox.getfenv = function() return sandbox end
    sandbox.setfenv = function(fn) return fn end
    sandbox.getgenv = function() return sandbox end
    sandbox.renv = sandbox

    local orig_char = string.char
    local custom_string = setmetatable({
        char = function(...)
            local res = orig_char(...)
            if is_valid_text(res) and not is_honeypot(res) then
                char_strings[#char_strings + 1] = res
            end
            return res
        end
    }, { __index = string })

    sandbox.string = custom_string

    local base_env = {
        _VERSION = _VERSION,
        assert = assert, error = error, ipairs = ipairs, pairs = pairs,
        next = next, pcall = pcall, xpcall = xpcall, select = select,
        tonumber = tonumber, tostring = tostring, type = type,
        unpack = unpack or table.unpack,
        math = math, string = custom_string, table = table, bit32 = bit32_mock,
        typeof = function(val) return type(val) end,
        task = {
            spawn = function(fn, ...) if type(fn) == "function" then captured_closures[#captured_closures + 1] = fn pcall(fn, ...) end end,
            defer = function(fn, ...) if type(fn) == "function" then captured_closures[#captured_closures + 1] = fn pcall(fn, ...) end end,
            delay = function(d, fn, ...) if type(fn) == "function" then captured_closures[#captured_closures + 1] = fn end end,
            wait = function() return 0 end
        },
        os = {
            clock = os.clock, time = os.time, difftime = os.difftime,
            execute = function() return nil end, remove = function() return nil end,
            rename = function() return nil end, exit = function() error("sandbox exit blocked") end
        },
        io = { open = function() return nil, "blocked" end, write = function() end, read = function() return nil end }
    }

    local hook_load = function(chunk, name, mode, env)
        if type(chunk) == "string" then
            local sub_chunk = load(chunk, name or "=sandbox", "bt", sandbox)
            if sub_chunk then
                captured_closures[#captured_closures + 1] = sub_chunk
                return sub_chunk
            end
        elseif type(chunk) == "function" then
            captured_closures[#captured_closures + 1] = chunk
            return chunk
        end
        return function() end
    end

    sandbox.load = hook_load
    sandbox.loadstring = hook_load

    sandbox.debug = {
        gethook = function() return nil, "" end,
        sethook = function() end,
        getinfo = function() return { what = "C", source = "=(skynox)" } end,
        getregistry = function() return {} end,
        getupvalue = debug.getupvalue,
        setupvalue = debug.setupvalue,
        traceback = function() return "" end
    }

    setmetatable(sandbox, {
        __index = function(_, key)
            if base_env[key] ~= nil then
                return base_env[key]
            end
            trace_log[#trace_log + 1] = string.format("Accessed Global: %s", tostring(key))
            return make_stealth_dummy(key, trace_log)
        end,
        __newindex = function(tbl, key, val)
            if type(val) == "function" then
                captured_closures[#captured_closures + 1] = val
            end
            rawset(tbl, key, val)
        end,
        __metatable = "locked"
    })

    return sandbox
end

function skx_deobfuscator.deobfuscate_vm(source_code)
    source_code = unescape_hex_bytes(source_code)
    
    local captured_closures = {}
    local trace_log = {}
    local char_strings = {}
    local env = create_vm_sandbox(captured_closures, trace_log, char_strings)

    local chunk, err = load(source_code, "=vm_runner", "bt", env)
    if not chunk then
        return nil, err
    end

    captured_closures[#captured_closures + 1] = chunk

    local op_counter = 0
    debug.sethook(function()
        op_counter = op_counter + 500
        if op_counter > 200000 then
            debug.sethook()
            error("timeout: vm execution threshold reached")
        end
    end, "", 500)

    pcall(chunk)
    debug.sethook()

    local extracted_constants = {}
    local visited_fns = {}
    for _, fn in ipairs(captured_closures) do
        extract_vm_constants(fn, visited_fns, extracted_constants)
    end

    return {
        constants = extracted_constants,
        trace = trace_log,
        char_strings = char_strings
    }
end

local function fetch_url(url)
    if not has_http or not http then return nil end
    local res, body = http.request("GET", url)
    if res and res.code == 200 then
        return body
    end
    return nil
end

local function handle_deobf_command(message, script_code)
    local code_input = nil

    if type(message) == "table" and message.attachments and #message.attachments > 0 then
        local file_url = message.attachments[1].url
        code_input = fetch_url(file_url)
    elseif script_code and script_code:match("https?://%S+") then
        local target_url = script_code:match("https?://%S+")
        code_input = fetch_url(target_url)
    elseif script_code and #script_code > 0 then
        code_input = script_code
    end

    if not code_input or #code_input == 0 then
        local err_msg = "please provide a valid script, file attachment, or url link."
        if type(message) == "table" and message.reply then
            message:reply(err_msg)
        else
            print(err_msg)
        end
        return
    end

    local vm_result, err = skx_deobfuscator.deobfuscate_vm(code_input)
    local output = { "**rebuilded the script**\n" }

    if not vm_result then
        output[#output + 1] = string.format("**vm parse error:** `%s`", tostring(err))
    else
        if #vm_result.constants > 0 then
            output[#output + 1] = "**extracted vm constants & strings:**"
            local seen = {}
            for _, item in ipairs(vm_result.constants) do
                if not seen[item.value] then
                    seen[item.value] = true
                    output[#output + 1] = string.format("* %s: `%s`", item.type, item.value)
                end
            end
            output[#output + 1] = ""
        end

        if #vm_result.char_strings > 0 then
            output[#output + 1] = "**dynamically constructed vm strings:**"
            local seen = {}
            for _, s in ipairs(vm_result.char_strings) do
                if not seen[s] then
                    seen[s] = true
                    output[#output + 1] = string.format("`%s`", s)
                end
            end
            output[#output + 1] = ""
        end

        if #vm_result.trace > 0 then
            output[#output + 1] = "**rebuilded vm call graph & reconstructed logic:**"
            output[#output + 1] = "```lua"
            local seen = {}
            for _, call in ipairs(vm_result.trace) do
                if not seen[call] then
                    seen[call] = true
                    output[#output + 1] = call
                end
            end
            output[#output + 1] = "```"
        else
            output[#output + 1] = "**rebuilded the script:**"
            output[#output + 1] = "```lua\n-- VM Executed cleanly. No direct global side-effects captured.\n```"
        end
    end

    local final_text = table.concat(output, "\n")
    if type(message) == "table" and message.reply then
        message:reply(final_text)
    else
        print(final_text)
    end
end

if arg and arg[1] then
    local file = io.open(arg[1], "r")
    if file then
        local file_content = file:read("*a")
        file:close()
        handle_deobf_command(nil, file_content)
    else
        print("could not open file: " .. tostring(arg[1]))
    end
end

