# Skynox Obfuscator (seed:123 mode:vm) — Deobfuscation How-To

> For educational / security-research use only. The sample at `https://pastefy.app/vY4MdC1a/raw` (old, `472608` bytes) is a Roblox Luau exploit (IQ game, tool steal / orbit / kill). **Patched sample** `https://pastefy.app/qiQdymDS/raw` (`472738` bytes, same seed, same input) is built with the hardened `src/` below — old method fails there.

> **PATCHED 2026-08-29 — CODE, NOT JUST DOCS**: 
> - `src/protection.lua` restored `__skx_getfenv0` from registry *before* `__skx_env` determination + `_fake_env` check — fixes `luajit` repeated-load pollution where `__SKX_LEAKER_GUARD_ACTIVE` left `getfenv(0)` returning `_fake_env` and `__skx_environment_clean` missed `getrawmetatable`.
> - `src/envlogger.lua` keyed `hash_name` via `Integrity.hash` + `salt` avalanche + priority `reserve=32` for `GUARD_FAILURE/INTEGRITY_PHASE` + `set_phase("decrypt"/"integrity"/"wipe"/"user"/"shutdown"/"seal"/"decode")`.
> - `src/vm/emit2.lua` `SBF` scrub `for j=1,#_SBF do _SBF[j]=0 end _SBF=nil` (keep `__SKX_SEG` for `__skx_reseal` watchdog) + `KKREF` chunk wipe.
> - `src/build.lua` + `src/vm/emit2.lua` **strip all `--` line comments** per user request — output now starts with `local __SKX_SEG_...` not `--------[Skynox Obfuscator]` (console `print("--" .. WATERMARK)` still prints to stdout, file has `0` `------`).
> - `src/protection.lua:98` still `__skx_msg_key`/`__skx_msg_enc` per-build, `src/vm/binfmt.lua:304` `esplit` 1-5 chunks, `src/build.lua:245` konst whitening `__KM=_x8(ka,kb)`, `src/vm/emit2.lua:19` mangled `quote_safe`, `src/protections.lua:127` `httplog` trap — unchanged.

## 1. Fetch & Fingerprint

```bash
# old (still works as described): 1109 lines, 472608 bytes
curl -L https://pastefy.app/vY4MdC1a/raw -o /tmp/skynox.lua
# patched (old inject fails): 1109 lines, 472738 bytes — same input, hardened src
curl -L https://pastefy.app/qiQdymDS/raw -o /tmp/skynox_patched.lua
wc -l /tmp/skynox.lua /tmp/skynox_patched.lua
# current build (2026-08-29, -- stripped):
lua5.4 -e 'package.path="src/?.lua;src/vm/?.lua;src/passes/?.lua;"..package.path; local b=require("build"); io.open("/tmp/cur.lua","w"):write(b.build("print(1)",{mode="vm",seed=123}))'
head -n 5 /tmp/cur.lua
# local __SKX_SEG_2="\xbcN\xc6!>\xd1\xb9\x8c/'\xc17"
# local __SKX_SEG_4="@\x94[\xda\xa3\xee l\xca\x8a.\xbb"
# grep "------" /tmp/cur.lua | wc -l # 0 (stripped)
# grep "Lol trying" /tmp/cur.lua | wc -l # 0 (now __skx_msg_enc)
# lua5.4 Obfuscator.lua input.lua --maximum 2>&1 | head -1 # --------[Skynox Obfuscator] (console only)
```

Segments: `__SKX_SEG_1..N` where `N = rng.int(3,7)` per build (not fixed 4), `__skx_total`, `__skx_lengths`, `__skx_parts` at `src/build.lua:192-200` + `src/build.lua:352-361`. Check: `grep -c "__SKX_SEG_" /tmp/cur.lua` and `grep -o "__skx_total=[0-9]*"`.

## 2. Map the Protections (read `src/build.lua:1` & `Obfuscator.lua:1` & current `/tmp/cur.lua:13-583`)

- **VM**: constants `K` (`_NC` variable, e.g. 2796) + protos `PR` (`_NP` e.g. 58) decoded via `KKREF(ix)` → `_x8(ix,__KM)+1` cache `KC`, string decrypt via `__BJ:byte(part.p+i-1)` xor `__KS1[(part.o+i-1)%4096+1]` (chunked `np/list` across keystream, `src/vm/binfmt.lua:300` `esplit`). `__KM=_x8(ka,kb)` split at `src/build.lua:270` + `src/vm/emit2.lua:200`.
- **Anti-Tamper V1.1** (`src/protection.lua`):
  - `__skx_guard_tokens()` — checks `__skx_primitives_ok(true)`, `__skx_native_primitives_ok()` (now Luau-aware + restored `getfenv` before `__skx_env` — `src/protection.lua:150`), `__skx_environment_clean()` (hash `scan_a`/`scan_b` vs `__skx_env_signatures`), `__skx_debug_hooked()`. Fails → `__mock()` prints decoded `__skx_message` (`__skx_msg_key`/`__skx_msg_enc` per-build).
  - `__skx_reseal()` hashes segments (`__skx_ps`, `__skx_hs`) — re-sealable watchdog, called at every phase boundary (`src/build.lua` + `src/vm/emit2.lua:265` `set_phase`).
  - Periodic `__skx_guard(force)` every 97 ticks + `__skx_guard(true)` at decrypt/decode/engine.
- **Anti-Leaker** (`src/protection.lua:85-211`): `getfenv`→`_fake_env` (`_G={}`), `debug.getupvalue`→hide `_G`, `string.dump→nil`, `io.open` block, `debug.getregistry→{}`, `getfenv` restore from registry before `__skx_env` (fix for repeated loads).
- **EnvLogger** (`src/envlogger.lua`): opt-in `summary`/`diagnostic`, `budget=256` `ring=64`, keyed `hash_name` (`Integrity.hash` + salt), priority `reserve=32` for `INTEGRITY_PHASE`, `set_phase` at `seal`/`decode`/`engine`.
- **Anti-Dump**: `SBI`/`SBF` `for j=1,256` S-box, `__KS1=_ks(__K1,4096)`, then `for j=1,#_SBF do _SBF[j]=0 end _SBF=nil` (keep `__SKX_SEG` for reseal), `KC` chunk wipe after cache, ` Protections.extras` bait `SKX/MASTER` etc (now `--` stripped from output).

### 2.1 Patched (current `src/`)

- `src/protection.lua` leaker pollution fix (see above) — `luajit` `vm:untampered` now `PASS=166` both runtimes (was `FAIL` after `source` run).
- `src/envlogger.lua` priority + keyed hash — `grep "__SKX_LOG"` only when `envlogger` enabled.
- `src/vm/emit2.lua` `SBF` scrub — `grep "_SBF=nil"` present, `__SKX_SEG` kept.
- `src/build.lua` + `src/vm/emit2.lua` strip `"\n%s*%-%-.-\n"` — `grep -c "--"` in file = `0` (was `34`), console `print` still shows watermark.
- Unchanged: `__skx_msg_enc`, `esplit`, `whitening`, `quote_safe`, `httplog` trap, `11` vectors.

## 3. Find Why It Fails Outside Roblox

```bash
lua5.1 /tmp/skynox.lua   # -> Skynox: integrity failure at __skx_guard_tokens:349
luajit /tmp/skynox.lua   # same
```

Patch to log:

```lua
-- replace composite if at /tmp/skynox.lua:347
print(env_hash, __skx_env_digest, __skx_native_primitives_ok(), __skx_environment_clean(), __skx_debug_hooked())
```

Result (old sample): `env_hash` matches `1946355656`, but `__skx_native_primitives_ok()==false` (old `what=="Lua"` for `getfenv`).

Root cause (old): `getfenv` is `what=="Lua"` (`@/tmp/skynox.lua`) not `"C"` → false on Lua5.1/LuaJIT.

**Fix (research only) for old sample:** Use Lua 5.4 where `getfenv==nil` → skipped:

```bash
lua5.4 /tmp/skynox.lua # passes guard, then fails at VM runtime: attempt to index nil 'base' at _BNXVs2193:896 (missing Roblox globals like `game`)
```

**Fixed in current build:** `getfenv`/`getupvalue`/`getinfo` leaks are wrapped *before* guard + `__skx_getfenv0` restored from registry, so `native_primitives_ok` passes on 5.4 *and* correctly blocks `env-leakers-leak` 1..11 without relying on Lua version. New samples are not vulnerable to single-check patch; `GUARD_A/B/C` still required for `__MK/__K1/__IV` unwrapping, but `mangle` and `whitening` mean you must also recover `__KM`.

Deterministic guard keys (seed=123, digest=1946355656):
```python
# hb/hn/hs as in /tmp/skynox.lua:504-528
# computed: A=801976478 B=2335684469 C=1112793511
```

### 3.1 Fixed in Current Build

- `mockery` no longer `grep "Lol trying"` — now `__skx_msg_enc` per-build.
- `httplog` trap will hang any hook that makes `string.byte("a",function)` error contain `httplog`/`sandbox`.
- `getfenv`/`getupvalue`/`getinfo` leaks are now wrapped to return `_fake_env`/`nil`/`"=(skynox)"` *before* guard + restored from registry, so `native_primitives_ok` passes on 5.4 and correctly blocks `env-leakers-leak` without version bypass.
- New samples have `0` `------` in file (stripped), so `grep "------"` → `0`; use `grep -c "__SKX_SEG_"` and `grep -c "Skynox: integrity"` (fallback `__mock`) instead.
- Repeated-load pollution fixed — `luajit` `PASS=166` both `source`/`vm` `untampered` + `tripwire` after `source` run.

## 4. Dump VM Without Executing Payload

Don’t run `_9dM4ueqz07(1,...)` `/tmp/skynox.lua:1120` (requires Roblox `game.Players` etc.). Dump after `__skx_reseal()` where `K` (`_NC`) and `PR` (`_NP`) are ready (now `local __KS1` scrub keeps `KC`).

**Minimal inject** (avoids 200-local limit — update for `esplit` + `KKREF` + no `--`):
```lua
-- tail marker: do if __skx_canary_recheck then ... end __skx_reseal() end _9dM4ueqz07(1,...)
_G._DUMP_F=K;_G._DUMP_NC=_NC;_G._DUMP_PR=PR;_G._DUMP_NP=_NP;
_G._DUMP_KC=KC;_G._DUMP_K=K;_G._DUMP_SBI=_SBI;_G._DUMP_SBF=_SBF;
-- _DUMP_KM is mangled __KM, find via grep "_x8%(%d+,%d+%)" -> local _XXXX=_x8(ka,kb)
for k,v in pairs(_G) do if type(v)=="number" and k:match("^_[%w]+$") and v>1000000 then _G._DUMP_KM=v end end
dofile("/tmp/dump_helper.lua");os.exit(0)
```

`dump_helper.lua` — **update for `esplit` + `__KM`**:
```lua
for ci=1,_NC do
  d=K[ci]
  if d.t==_TCI then val=d.v
  elseif d.t==_TCN then val=_double_at(d.p)
  elseif d.t==_TCS then
    chars={}; for pi=1,d.np do part=d.list[pi]; for i=1,part.n do chars[#chars+1]=string.char(_x8(_BJ:byte(part.p+i-1),_KS1[(part.o+i-1)%4096+1])) end end
    val=table.concat(chars)
  elseif d.t==_TCY then val=true elseif d.t==_TCF then val=false end
end
-- KKREF now _x8(ix,__KM)+1, so use _x8(ix,_DUMP_KM)+1
```

Run:
```bash
python3 patch_inject.py  # creates /tmp/skynox_dump_final.lua
lua5.4 /tmp/skynox_dump_final.lua
# [DUMP] _NC 2796 _NP 58 (counts vary per seed due to fake ops if enabled)
# -> /tmp/dump_constants_raw.txt (105K), /tmp/dump_protos_pretty.txt (382K)
```

**No `eval` needed:** S-box inversion is ` _SBI/_SBF` (`for j=1,256 do _IV8[_SBF[j]]=j-1 end` then ` _SBF=nil` after decrypt) — still valid, but `quote_safe` means `__MAGIC` is `\DDD` escaped.

### 4.1 Patched: What Breaks the Old Inject

- Old helper assumed `d.t==_TCS` had `d.p/d.n/d.o` single chunk; now `d.np/d.list` — truncated.
- Old helper used raw `ix` for `KON`; now `ix` is whited ` _x8(ix,__KM)` — must do `_x8(ix,_DUMP_KM)+1` and fetch `_DUMP_KM` per-build.
- Old inject searched for `__skx_message` plaintext; now `__skx_msg_enc` — search `__skx_msg_key`.
- Mangled names (`_x8`→`_U5aw...`) change per seed — discover via `grep -o "_[A-Za-z0-9]\{7,13\}[0-9]\{1,2\}"` and `KC`/`K` dumps, not hardcode.
- `SBI`/`SBF` scrub: after `__BJ=table.concat(ob)` `for j=1,#_SBF do _SBF[j]=0 end _SBF=nil` — dump `SBI` before that point (inject after `__skx_reseal()` but before `SBF=nil`).
- `------` no longer in file — don't rely on `head -1` watermark; use `grep -c "__SKX_SEG_"` and `grep -c "Skynox: integrity"` instead.

## 5. Read the Dumps

```bash
head -n 40 /tmp/dump_constants_raw.txt
# C[0001] "Players"  C[0008] "TweenService"  C[0023] "[Purchase] Purchasing remote not found!"

grep -c "PROTO" /tmp/dump_protos.txt  # 58 (varies 58-60 with junk proto if enabled)
grep "IQ" /tmp/dump_constants_raw.txt | head
head -n 800 /tmp/dump_protos_pretty.txt
# PROTO 1 params=[] va=true -> main: game:GetService("Players") etc
# PROTO 2 -> purchase via ReplicatedStorage.Purchasing:InvokeServer(149827570)
# PROTO 5 -> orbit tool stealing (WeldConstraint, Grip)
```

Opcodes map (now per-build, not fixed — example for seed 123):
- `__VALID_OP` size `36 + rng.int(3,7)` fake bombs if enabled (currently disabled for `luajit` stability, `src/vm/gen.lua` fakeCount `0`)
- `BLOCK` fixed `256` (variable `128-512` reverted for stability)
- `__MAGIC` 4B `quote_safe` `\DDD` escaped, `__PROFILE_ID` FNV of `magic+tags+layout`

## 6. Notes & Limits

- Don’t hook `debug.gethook` while dumping; `__skx_debug_hooked` will trigger. Repeated-load `getfenv` pollution fixed in `src/protection.lua:150`, but still keep `string`/`math`/`table` pristine until after dump; `__skx_primitives_ok` checks `rawget(string,"byte")==__skx_byte0`.
- Keep `string`/`math`/`table` pristine; `__skx_primitives_ok` checks `rawget`.
- `envlogger` opt-in only — `grep "__SKX_LOG"` only when `--envlogger summary`/`diagnostic` (see `src/envlogger.lua` priority `reserve=32`).
- Full source reconstruction still needs a decompiler (walk `proto.b` tree → Luau). The dumps are the ground truth; the original `Obfuscator.lua` shows the inverse transform.
- This technique is for analysis, not for re-arming the exploit.
- Current output has `0` `------`/`--` line comments (stripped in `src/build.lua` final `gsub`), console still prints `--------[Skynox Obfuscator]` via `print`.

Artifacts from this session: `/tmp/skynox.lua`, `/tmp/skynox_dump_final.lua`, `/tmp/dump_helper.lua`, `/tmp/dump_constants_raw.txt`, `/tmp/dump_protos*.txt`, `/tmp/cur.lua` (current `seed:123` no `--`).

