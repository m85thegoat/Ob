-- envlogger.lua :: opt-in diagnostics logger (planning artifact v0)
-- Implements the architecture from ENV_LOGGER_PLAN.md without weakening
-- fail-closed protections. Default is off; no logger code is emitted unless
-- explicitly enabled with a validated policy.

local bitutil = require("bitutil")
local Integrity = require("integrity")

local E = {}
E.SCHEMA = 1
E.VERSION = "envlogger-0.1"

local VALID_MODES = {off=true, summary=true, diagnostic=true}
local VALID_SINKS = {callback=true, pull=true, discard=true}

local DEFAULTS = {
  enabled = false,
  mode = "off",
  budget = 256,          -- max events total
  ring = 64,             -- ring buffer slots
  sample_read = 1,       -- 1 = every read, 2 = 1/2, etc.
  sample_write = 1,
  sample_miss = 1,
  sink = "discard",      -- callback|pull|discard
  strict_summary = false,-- emit summary before abort on guard failure
  hash_salt = 0,         -- 0 = auto from seed, else provided
}

local function is_uint(n, lo, hi)
  return type(n)=="number" and n==math.floor(n) and n>=lo and n<=hi
end

function E.compile(input, ctx)
  ctx = ctx or {}
  local seed = ctx.seed or 0
  local mode = ctx.mode or "source"

  -- normalize input: nil/false/"off" => disabled
  if input==nil or input==false or input=="off" then
    return {enabled=false, mode="off", budget=0, ring=0, sink="discard", build_id=Integrity.hash("SKX/ENVLOG/ID", seed), schema=E.SCHEMA}
  end
  if input==true then input = {enabled=true} end
  if type(input)=="string" then
    if VALID_MODES[input] then input = {enabled=input~="off", mode=input}
    else error("envlogger: invalid mode string", 0) end
  end
  if type(input)~="table" then error("envlogger: policy must be table/string/boolean", 0) end

  local p = {}
  for k,v in pairs(DEFAULTS) do p[k]=v end
  for k,v in pairs(input) do p[k]=v end

  -- enabled implies mode != off, and vice versa
  if p.enabled == false then p.mode="off" end
  if p.mode=="off" then p.enabled=false end
  if p.enabled and p.mode=="off" then p.mode="summary" end

  if not VALID_MODES[p.mode] then error("envlogger: mode must be off|summary|diagnostic", 0) end
  if not VALID_SINKS[p.sink] then error("envlogger: sink must be callback|pull|discard", 0) end
  if not is_uint(p.budget, 0, 4096) then error("envlogger: budget 0..4096", 0) end
  if not is_uint(p.ring, 0, 1024) then error("envlogger: ring 0..1024", 0) end
  if not is_uint(p.sample_read, 1, 1024) then error("envlogger: sample_read 1..1024", 0) end
  if not is_uint(p.sample_write, 1, 1024) then error("envlogger: sample_write 1..1024", 0) end
  if not is_uint(p.sample_miss, 1, 1024) then error("envlogger: sample_miss 1..1024", 0) end

  -- hash salt: 0 => derive from seed, else use provided
  local salt = p.hash_salt
  if salt==0 or salt==nil then
    salt = Integrity.hash_number(seed, 0x9e3779b9) % 4294967296
    p.hash_salt = salt
  else
    if not is_uint(salt, 0, 4294967295) then error("envlogger: hash_salt uint32", 0) end
  end

  -- correlation ID: one-way, never guard tokens
  local build_id = Integrity.hash("SKX/ENVLOG/BUILD/"..mode, seed)
  build_id = Integrity.hash_number(p.budget, build_id)
  build_id = Integrity.hash_number(p.ring, build_id)
  build_id = Integrity.hash_number(salt, build_id)
  p.build_id = build_id % 4294967296
  p.schema = E.SCHEMA
  p.seed = seed
  p.runtime = mode

  -- redact: never allow raw names for sensitive patterns; enforce allowlist vs hash
  p.redact_patterns = {"__SKX", "secret", "token", "cookie", "payload", "SKX3", "SKX/", "key", "seed"}
  return p
end

-- helper: emit Lua code that will be spliced into generated output.
-- Uses pinned primitives captured at boot; never replaces them.
function E.runtime(policy, fail_name, opts)
  fail_name = fail_name or "__skx_fail"
  opts = opts or {}
  if not policy or not policy.enabled then
    return "" -- no logger code when disabled: output must be bit-identical for fixed seed
  end

  local mode = policy.runtime or "source"
  local build_id = policy.build_id or 0
  local budget = policy.budget
  local ring = policy.ring
  local sink = policy.sink
  local salt = policy.hash_salt or 0

  -- Sink adapter: only callback is active in this v0; pull/discard are no-ops for generated code
  -- The host must provide __SKX_LOG_SINK callback once at boot via rawset(_G,"__SKX_LOG_SINK",fn) or via EnvLogger host API.
  -- If sink is callback but no callback is provided, events are counted as dropped.

  local lines = {
    "-- envlogger " .. E.VERSION .. " " .. mode .. " " .. policy.mode,
    -- single global table to avoid 200-local limit in VM main chunk (locals are scarce there)
    "rawset(_G or _ENV,'__SKX_LOG',{build_id=" .. string.format("%.0f", build_id) .. ",budget=" .. string.format("%.0f", budget) .. ",ring_n=" .. string.format("%.0f", math.max(1, ring)) .. ",salt=" .. string.format("%.0f", salt) .. ",seq=0,dropped=0,phase='boot',buf={},buf_n=0,reentry=false,sink=nil})",
    "local __skx_log=rawget(_G or _ENV,'__SKX_LOG')",
    -- capture sink once at boot from host-provided global, then clear it so payload cannot see it
    "do local s=rawget(_G or _ENV,'__SKX_LOG_SINK') if type(s)=='function' then __skx_log.sink=s rawset(_G or _ENV,'__SKX_LOG_SINK',nil) end end",
    [==[
__skx_log.xor=function(a,b)
  local r,p=0,1
  a,b=a%4294967296,b%4294967296
  for _=1,32 do
    local x,y=a%2,b%2
    if x~=y then r=r+p end
    a=(a-x)/2 b=(b-y)/2 p=p*2
  end
  return r
end
__skx_log.hash_name=function(s)
  -- keyed hash, not cryptographic, for correlation only
  local h=2166136261
  h=__skx_log.xor(h, __skx_log.salt) % 4294967296
  for i=1,#s do
    local b=s:byte(i)
    h = (__skx_log.xor(h % 256, b) % 256) + math.floor(h/256)*403 + (h%256)*16777216
    h = h % 4294967296
  end
  return h
end
__skx_log.redact_key=function(k)
  if type(k)~="string" then return "__nonstring" end
  local lk=k:lower()
  for _,pat in ipairs({"__skx","secret","token","cookie","payload","skx3","skx/","key","seed"}) do
    if lk:find(pat,1,true) then return "__redacted" end
  end
  return k
end
__skx_log.should_sample=function(kind)
  -- simple deterministic sampling by seq
  if kind=="GLOBAL_READ" then return __skx_log.seq % ]==] .. tostring(policy.sample_read) .. [==[ ==0 end
  if kind=="GLOBAL_WRITE" then return __skx_log.seq % ]==] .. tostring(policy.sample_write) .. [==[ ==0 end
  if kind=="GLOBAL_MISS" then return __skx_log.seq % ]==] .. tostring(policy.sample_miss) .. [==[ ==0 end
  return true
end
__skx_log.emit=function(kind, status, fields)
  if __skx_log.reentry then __skx_log.dropped=__skx_log.dropped+1 return end
  if __skx_log.seq >= __skx_log.budget then __skx_log.dropped=__skx_log.dropped+1 return end
  if not __skx_log.should_sample(kind) then __skx_log.dropped=__skx_log.dropped+1 return end
  __skx_log.reentry=true
  __skx_log.seq=__skx_log.seq+1
  local ev={
    schema=1,
    build_id=__skx_log.build_id,
    seq=__skx_log.seq,
    phase=__skx_log.phase,
    mode="]==] .. mode .. [==[",
    runtime=_VERSION or "unknown",
    kind=kind,
    status=status,
  }
  if fields then for kk,vv in pairs(fields) do ev[kk]=vv end end
  -- ring buffer
  __skx_log.buf_n = (__skx_log.buf_n % __skx_log.ring_n) + 1
  __skx_log.buf[__skx_log.buf_n]=ev
  -- sink: callback if present, else pull/discard
  if __skx_log.sink then
    local ok,err=pcall(__skx_log.sink, ev)
    if not ok then
      __skx_log.dropped=__skx_log.dropped+1
      __skx_log.sink=nil -- circuit breaker: disable on first failure
      -- record sink failure once
      if __skx_log.seq < __skx_log.budget then
        __skx_log.seq=__skx_log.seq+1
        __skx_log.buf[(__skx_log.buf_n % __skx_log.ring_n)+1]={schema=1,build_id=__skx_log.build_id,seq=__skx_log.seq,phase=__skx_log.phase,mode="]==] .. mode .. [==[",kind="LOGGER_DROP",status="error", err=tostring(err):sub(1,80)}
      end
    end
  end
  __skx_log.reentry=false
end
__skx_log.set_phase=function(name) __skx_log.phase=name __skx_log.emit("INTEGRITY_PHASE","ok",{phase=name}) end
__skx_log.drop=function(n) __skx_log.dropped=__skx_log.dropped+(n or 1) end
-- pull API for host: returns copy of buffered events and drop count
rawset(_G or _ENV, "__SKX_LOG_PULL", function()
  local out={}; for i=1,__skx_log.buf_n do out[i]=__skx_log.buf[i] end
  return {events=out, dropped=__skx_log.dropped, seq=__skx_log.seq, build_id=__skx_log.build_id}
end)
]==],
  }

  -- strict: emit failure summary before abort, but never bypass abort
  if policy.strict_summary then
    lines[#lines+1] = [==[
local __skx_log_orig_fail=]==] .. fail_name .. [==[
]==] .. fail_name .. [==[=function(...)
  __skx_log.emit("GUARD_FAILURE","blocked",{reason="guard"})
  __skx_log.emit("END","blocked",{dropped=__skx_log.dropped})
  return __skx_log_orig_fail(...)
end
]==]
  end

  -- initial boot snapshot (bounded, no values)
  lines[#lines+1] = [==[
__skx_log.emit("BOOT_SNAPSHOT","ok",{strict=]==] .. (opts.strict and "true" or "false") .. [==[})
if debug and debug.gethook then
  local ok,hook=pcall(debug.gethook)
  __skx_log.emit("HOOK_STATE", ok and hook==nil and "ok" or "changed", {})
end
]==]

  return table.concat(lines, "\n")
end

return E
