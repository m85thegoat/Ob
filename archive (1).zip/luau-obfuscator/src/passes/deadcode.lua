-- deadcode.lua :: injects opaque-predicate-guarded junk blocks
local bitutil = require("bitutil")
local D = {}

local function num(n) return { type = "Number", value = n } end

-- always-false predicate: (x*x - x*2 + 1) % 2 == 0 style; built from odd/even facts
local function opaque_false(rng)
  local a = rng.int(1000, 999999)
  -- (2a+1)^2 is odd => % 2 == 1 ; claim == 0 -> false
  return {
    type = "Binop", op = "==",
    l = { type = "Binop", op = "%",
          l = { type = "Binop", op = "*",
                l = { type = "Number", value = 2 * a + 1 },
                r = { type = "Number", value = 2 * a + 1 } },
          r = num(2) },
    r = num(0),
  }
end

local JUNK_STRINGS = {
  "\1decoy_dump_bait\2", "\1env_logger_trap\3", "\1fake_payload_segment\4",
}

-- API: D.run(chunk_ast, seed, opts)
function D.run(chunk, seed, opts)
  opts = opts or {}
  local rng = bitutil.newrng((seed or os.time()) + 31337)
  local count = rng.int(2, 5)

  for i = 1, count do
    local junkname = "_dc" .. tostring(math.floor(rng.int(10 ^ 6, 10 ^ 9)))
    local bait = {
      type = "Local",
      names = { junkname },
      exprs = {
        { type = "String", value = JUNK_STRINGS[rng.int(1, #JUNK_STRINGS)] },
      },
    }
    local branch = {
      type = "If",
      clauses = { { cond = opaque_false(rng), body = {
        { type = "ExprStat", expr =
          { type = "Call", fn = { type = "Name", name = junkname }, args = {} } },
      } } },
    }
    local pos = rng.int(1, math.max(1, #chunk.body))
    table.insert(chunk.body, pos, bait)
    table.insert(chunk.body, pos + 1, branch)
  end
  return { injected = count }
end

return D
