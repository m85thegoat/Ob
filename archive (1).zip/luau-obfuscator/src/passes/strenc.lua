-- strenc.lua :: string literal encryption (XOR + rolling key)
local bitutil = require("bitutil")
local S = {}

local function gen_marker(rng)
  return "_" .. tostring(rng.int(1000000, 999999999)) .. "x"
end

-- mirrors the runtime decoder exactly
local function encode(plain, key)
  local outbytes = {}
  local k = key
  for i = 1, #plain do
    local b = plain:byte(i)
    -- 8-bit xor
    local r, p, a, bb = 0, 1, b % 256, k % 256
    for _ = 1, 8 do
      local x, y = a % 2, bb % 2
      if x ~= y then r = r + p end
      a = (a - x) / 2; bb = (bb - y) / 2; p = p * 2
    end
    outbytes[#outbytes + 1] = string.char(r)
    k = (k * 31 + i * 7 + 13) % 251
  end
  return table.concat(outbytes)
end

-- API: S.run(chunk_ast, seed, opts) mutates AST; returns metadata
function S.run(chunk, seed, opts)
  opts = opts or {}
  local rng = bitutil.newrng((seed or os.time()) + 7777)
  local D_MARKER = gen_marker(rng)
  local walkmod = require("astwalk")
  local count = 0

  walkmod.map_stmt_exprs(chunk.body, function(e)
    if e.type ~= "String" then return nil end
    local v = e.value
    if v == "" then return nil end
    local key = rng.int(11, 250)
    local cipher = encode(v, key)
    count = count + 1
    return {
      type = "Call",
      fn = { type = "Name", name = D_MARKER },
      args = { { type = "String", value = cipher }, { type = "Number", value = key } },
    }
  end, true)

  return { count = count, dmarker = D_MARKER }
end

-- runtime header source (reuses the 32-bit bxor helper named `bxname`)
function S.header(meta, bxname)
  local d = meta.dmarker
  return "" .. d .. "=function(s,k) local t={} for i=1,#s do local b=s:byte(i)" ..
    " local r,p,a,c=0,1,b,k%256 for j=1,8 do local x,y=a%2,c%2 if x~=y then r=r+p end " ..
    " a=(a-x)/2 c=(c-y)/2 p=p*2 end t[i]=string.char(r) k=(k*31+i*7+13)%251 end " ..
    " return table.concat(t) end"
end

return S
