-- cfflatten.lua :: conservative control-flow flattening via state dispatcher
local C = {}

-- scan block: returns true if any top-level stmt is control-flow sensitive
local function has_top_sensitive(stats)
  for _, s in ipairs(stats) do
    local t = s.type
    if t == "Break" or t == "Continue" or t == "Goto" or t == "Label" then return true end
    -- a top-level Return is semantically OK to move, but keep conservative
    if t == "Return" then return true end
  end
  return false
end

local function deep_has_continue(stats)
  local found = false
  local function w(blk)
    for _, s in ipairs(blk) do
      local t = s.type
      if t == "Continue" then found = true end
      if t == "While" then w(s.body)
      elseif t == "Repeat" then w(s.body)
      elseif t == "If" then
        for _, cl in ipairs(s.clauses) do w(cl.body) end
        if s.orelse then w(s.orelse) end
      elseif t == "NumericFor" or t == "GenericFor" then w(s.body)
      elseif t == "Do" then w(s.body)
      elseif t == "LocalFunction" then w(s.func.body)
      elseif t == "FunctionDecl" then w(s.func.body)
      end
    end
  end
  w(stats)
  return found
end

local function flatten_block(stats, varname)
  local n = #stats
  if n < 3 then return stats end
  if has_top_sensitive(stats) then return stats end
  if deep_has_continue(stats) then return stats end

  local clauses = {}
  for i, s in ipairs(stats) do
    local body = { s }
    if i < n then
      body[#body + 1] = { type = "Assign",
                          targets = { { type = "Name", name = varname } },
                          exprs = { { type = "Number", value = i + 1 } } }
    else
      body[#body + 1] = { type = "Assign",
                          targets = { { type = "Name", name = varname } },
                          exprs = { { type = "Number", value = -1 } } }
    end
    clauses[#clauses + 1] = {
      cond = { type = "Binop", op = "==",
               l = { type = "Name", name = varname },
               r = { type = "Number", value = i } },
      body = body,
    }
  end
  local dispatcher = {
    type = "Local", names = { varname }, exprs = { { type = "Number", value = 1 } },
  }
  local loop = {
    type = "While",
    cond = { type = "Binop", op = "~=",
             l = { type = "Name", name = varname },
             r = { type = "Number", value = -1 } },
    body = { { type = "If", clauses = clauses } },
  }
  return { dispatcher, loop }
end

-- API: C.run(chunk_ast, seed, opts) mutates
function C.run(chunk, seed, opts)
  opts = opts or {}
  if opts.mode == "vm" then return { flattened = 0, note = "superseded by vm" } end
  local bitutil = require("bitutil")
  local rng = bitutil.newrng((seed or os.time()) + 4242)
  local count = 0

  local function walk(stats)
    local flat = flatten_block(stats, "_cf" .. tostring(math.floor(rng.int(10 ^ 5, 10 ^ 7))))
    if #flat ~= #stats then count = count + 1 end
    -- recurse into remaining structures
    local function rec(blk)
      for _, s in ipairs(blk) do
        local t = s.type
        if t == "While" then rec(s.body)
        elseif t == "Repeat" then rec(s.body)
        elseif t == "If" then
          for _, cl in ipairs(s.clauses) do rec(cl.body) end
          if s.orelse then rec(s.orelse) end
        elseif t == "NumericFor" or t == "GenericFor" then rec(s.body)
        elseif t == "Do" then rec(s.body)
        elseif t == "LocalFunction" then rec(s.func.body)
        elseif t == "FunctionDecl" then rec(s.func.body)
        end
      end
    end
    rec(flat)
    return flat
  end

  chunk.body = walk(chunk.body)
  return { flattened = count }
end

return C
