-- rename.lua :: scope-correct local identifier renaming
local bitutil = require("bitutil")
local R = {}

local KEYWORDS = {
  ["and"]=true,["break"]=true,["do"]=true,["else"]=true,["elseif"]=true,["end"]=true,
  ["false"]=true,["for"]=true,["function"]=true,["goto"]=true,["if"]=true,["in"]=true,
  ["local"]=true,["nil"]=true,["not"]=true,["or"]=true,["repeat"]=true,["return"]=true,
  ["then"]=true,["true"]=true,["until"]=true,["while"]=true,
}

local CHARS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_0123456789"

local function gen_name(state)
  for _ = 1, 64 do
    local len = state.rng.int(6, 10)
    local t = {}
    for i = 1, len do
      local pos = state.rng.int(1, #CHARS)
      local c = CHARS:sub(pos, pos)
      if i == 1 and c:match("%d") then c = "_" end
      t[i] = c
    end
    local nm = "_" .. table.concat(t)
    if not state.used[nm] and not KEYWORDS[nm] then
      state.used[nm] = true
      return nm
    end
  end
  error("rename: exhausted names", 0)
end

local function newscope(parent)
  return { m = {}, parent = parent }
end

local function define(sc, old, new) sc.m[old] = new end

local function resolve(sc, old)
  local c = sc
  while c do
    if c.m[old] then return c.m[old] end
    c = c.parent
  end
  return nil -- global, leave as-is
end

local X -- forward

local function xform_expr(e, sc, state)
  local t = e.type
  if t == "Name" then
    local nn = resolve(sc, e.name)
    if nn then e.name = nn end
  elseif t == "Index" then
    xform_expr(e.obj, sc, state); xform_expr(e.key, sc, state)
  elseif t == "Call" then
    xform_expr(e.fn, sc, state)
    for i = 1, #e.args do xform_expr(e.args[i], sc, state) end
  elseif t == "Method" then
    xform_expr(e.obj, sc, state)
    for i = 1, #e.args do xform_expr(e.args[i], sc, state) end
  elseif t == "Binop" then
    xform_expr(e.l, sc, state); xform_expr(e.r, sc, state)
  elseif t == "Unop" or t == "Paren" then
    xform_expr(e.e, sc, state)
  elseif t == "Table" then
    for _, en in ipairs(e.entries) do
      if en.kind == "keyed" then xform_expr(en.key, sc, state) end
      xform_expr(en.val, sc, state)
    end
  elseif t == "Function" then
    local inner = newscope(sc)
    for _, p in ipairs(e.params) do
      local nn = gen_name(state)
      define(inner, p, nn)
      -- mutate param list in place
    end
    for i, p in ipairs(e.params) do e.params[i] = inner.m[p] or p end
    X.block(e.body, inner, state)
  end
end

X = {}

function X.block(stats, sc, state)
  for _, s in ipairs(stats) do X.stmt(s, sc, state) end
end

function X.stmt(s, sc, state)
  local t = s.type
  if t == "Local" then
    for i = 1, #s.exprs do xform_expr(s.exprs[i], sc, state) end
    for i, nm in ipairs(s.names) do
      local nn = gen_name(state)
      define(sc, nm, nn)
      s.names[i] = nn
    end
  elseif t == "LocalFunction" then
    local nn = gen_name(state)
    define(sc, s.name, nn)
    s.name = nn
    local inner = newscope(sc)
    for i, p in ipairs(s.func.params) do
      local pn = gen_name(state)
      define(inner, p, pn)
      s.func.params[i] = pn
    end
    X.block(s.func.body, inner, state)
  elseif t == "FunctionDecl" then
    local first = resolve(sc, s.path[1])
    if first then s.path[1] = first end
    local inner = newscope(sc)
    local start = s.is_method and 2 or 1
    for i = start, #s.func.params do
      local p = s.func.params[i]
      local pn = gen_name(state)
      define(inner, p, pn)
      s.func.params[i] = pn
    end
    X.block(s.func.body, inner, state)
  elseif t == "Assign" then
    for i = 1, #s.targets do xform_expr(s.targets[i], sc, state) end
    for i = 1, #s.exprs do xform_expr(s.exprs[i], sc, state) end
  elseif t == "CompoundAssign" then
    xform_expr(s.target, sc, state); xform_expr(s.expr, sc, state)
  elseif t == "ExprStat" then
    xform_expr(s.expr, sc, state)
  elseif t == "Do" then
    X.block(s.body, newscope(sc), state)
  elseif t == "While" then
    xform_expr(s.cond, sc, state)
    X.block(s.body, newscope(sc), state)
  elseif t == "Repeat" then
    local inner = newscope(sc)
    X.block(s.body, inner, state)
    -- cond sees body scope (locals declared in body visible to until-cond)
    xform_expr(s.cond, inner, state)
  elseif t == "If" then
    for _, cl in ipairs(s.clauses) do
      xform_expr(cl.cond, sc, state)
      X.block(cl.body, newscope(sc), state)
    end
    if s.orelse then X.block(s.orelse, newscope(sc), state) end
  elseif t == "NumericFor" then
    xform_expr(s.start, sc, state); xform_expr(s.stop, sc, state)
    if s.step then xform_expr(s.step, sc, state) end
    local inner = newscope(sc)
    local vn = gen_name(state)
    define(inner, s.var, vn)
    s.var = vn
    X.block(s.body, inner, state)
  elseif t == "GenericFor" then
    for i = 1, #s.exprs do xform_expr(s.exprs[i], sc, state) end
    local inner = newscope(sc)
    for i, v in ipairs(s.vars) do
      local vn = gen_name(state)
      define(inner, v, vn)
      s.vars[i] = vn
    end
    X.block(s.body, inner, state)
  elseif t == "Return" then
    for i = 1, #s.exprs do xform_expr(s.exprs[i], sc, state) end
  end
  -- Break/Continue/Goto/Label: nothing
end

-- API: Rename.run(chunk_ast, seed) mutates AST
function R.run(chunk, seed)
  local rng = bitutil.newrng(seed or os.time())
  local state = { rng = rng, used = {} }
  X.block(chunk.body, newscope(nil), state)
  return chunk
end

return R
