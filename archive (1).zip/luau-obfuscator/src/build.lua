-- build.lua :: orchestrates pipeline and emits protected standalone output
local bitutil = require("bitutil")
local Integrity = require("integrity")
local Protection = require("protection")
local Protections = require("protections")
local EnvLogger = require("envlogger")
local B = {}

local WATERMARK = "------[Skynox Obfuscator]"
local MOCKERY = "Lol trying to Deobfuscate or Env Log try better luck next time"

local function i32le(value)
  value = value % 4294967296
  return string.char(value % 256, math.floor(value / 256) % 256,
    math.floor(value / 65536) % 256, math.floor(value / 16777216) % 256)
end

local function source_protection_block(manifest, wrapped_key, profile, seed, env_logger_src)
  local lines = {
    Protection.runtime(profile, "__skx_fail", MOCKERY),
    Protections.extras({ fail = "__skx_fail", mockery = MOCKERY,
      rng = bitutil.newrng((seed or 0) + 99991) }),
  }
  if env_logger_src and env_logger_src ~= "" then lines[#lines+1] = env_logger_src end
  lines[#lines+1] = Integrity.runtime(manifest, "__skx_fail")
  lines[#lines+1] = ("local __skx_wrapped_key=%.0f"):format(wrapped_key)
  lines[#lines+1] = [==[
local function __skx_xor32(a,b)
  local r,p=0,1
  a,b=a%4294967296,b%4294967296
  for _=1,32 do
    local x,y=a%2,b%2
    if x~=y then r=r+p end
    a=(a-x)/2 b=(b-y)/2 p=p*2
  end
  return r
end
local function __skx_norm(v)
  v=v%4294967296
  if v>=2147483648 then return v-4294967296 end
  return v
end
local function __skx_lshift(v,n)
  n=n%32
  if n==0 then return __skx_norm(v) end
  return __skx_norm((v%4294967296)*2^n)
end
local function __skx_rshift(v,n)
  n=n%32
  if n==0 then return __skx_norm(v) end
  return __skx_norm(math.floor((v%4294967296)/2^n))
end
local function __skx_decrypt(data,key)
  local v=key%4294967296
  if v==0 then v=222222229 end
  local out={}
  for i=1,#data do
    v=__skx_xor32(v,__skx_lshift(v,13))%4294967296
    v=__skx_xor32(v,__skx_rshift(v,17))%4294967296
    v=__skx_xor32(v,__skx_lshift(v,5))%4294967296
    out[i]=string.char(__skx_xor8(data:byte(i),v%256))
  end
  return table.concat(out)
end
local __skx_key=__skx_xor32(
  __skx_xor32(__skx_wrapped_key,__SKX_SEAL_C),__SKX_GUARD_C)%4294967296
__skx_guard(true)
]==]
  return table.concat(lines, "\n")
end

-- API: B.build(input_src, opts) -> output_src
function B.build(input_src, opts)
  opts = opts or {}
  local seed
  if opts.seed == nil then
    -- Stronger default entropy: mix wall time, high-res clock fraction,
    -- and input length so successive builds in the same second still vary.
    local base = os.time()
    local frac = 0
    if type(os.clock) == "function" then
      local ok, clk = pcall(os.clock)
      if ok and type(clk) == "number" then frac = (clk % 1) * 1e9 end
    end
    seed = (base * 1000003 + math.floor(frac) + (#input_src % 1000003) * 7919) % 9007199254740991
    if seed == 0 then seed = 0x9E3779B9 end
  else
    seed = tonumber(opts.seed)
    if not seed or seed ~= seed or seed == math.huge or seed == -math.huge or
       seed ~= math.floor(seed) or math.abs(seed) > 9007199254740991 then
      error("build: seed must be a safe integer", 0)
    end
  end

  local mode = opts.mode or "source"
  local intensity = opts.intensity or "medium"
  if mode ~= "source" and mode ~= "vm" then
    error("build: mode must be 'source' or 'vm'", 0)
  end
  if intensity ~= "light" and intensity ~= "medium" and intensity ~= "paranoid" then
    error("build: intensity must be 'light', 'medium', or 'paranoid'", 0)
  end
  if opts.protections ~= nil and opts.protections ~= "on" and opts.protections ~= "off" then
    error("build: protections must be 'on' or 'off'", 0)
  end
  if opts.cfflatten ~= nil and opts.cfflatten ~= "on" and opts.cfflatten ~= "off" then
    error("build: cfflatten must be 'on' or 'off'", 0)
  end
  if opts.anti_tamper ~= nil and opts.anti_tamper ~= "on" and
     opts.anti_tamper ~= "off" and opts.anti_tamper ~= true and
     opts.anti_tamper ~= false then
    error("build: anti_tamper must be on/off", 0)
  end
  -- envlogger policy: off by default, explicit opt-in only
  if opts.envlogger ~= nil and opts.envlogger ~= false and opts.envlogger ~= "off" then
    if type(opts.envlogger) ~= "table" and type(opts.envlogger) ~= "string" and type(opts.envlogger) ~= "boolean" then
      error("build: envlogger must be table/string/boolean", 0)
    end
  end

  local rng = bitutil.newrng(seed)
  local protected = opts.protections ~= "off" and opts.anti_tamper ~= "off" and
    opts.anti_tamper ~= false
  local strict_protection = opts.maximum == true or intensity == "paranoid"
  local protection = Protection.create(seed, { strict = strict_protection })
  local env_policy = EnvLogger.compile(opts.envlogger, {seed=seed, mode=mode})
  -- logger code is emitted only when enabled; otherwise output is bit-identical for fixed seed
  local env_logger_src = ""
  if env_policy.enabled then
    env_logger_src = EnvLogger.runtime(env_policy, "__skx_fail", {strict=strict_protection})
  end

  local Parser = require("parser")
  local Rename = require("rename")
  local Lower = require("lower")
  local NumEnc = require("numenc")
  local StrEnc = require("strenc")
  local DeadCode = require("deadcode")
  local CFF = require("cfflatten")
  local Compiler = require("vm.compiler")
  local Gen = require("vm.gen")
  local Printer = require("printer")

  local ast = assert(Parser.new(input_src):parse_chunk())

  if mode == "source" then Lower.run(ast) end
  if not opts.no_rename then Rename.run(ast, seed) end

  local header = {}
  if mode == "source" then
    local nummeta = NumEnc.run(ast, seed, { intensity = intensity })
    local strmeta = StrEnc.run(ast, seed, {})
    if strmeta.count > 0 then header[#header + 1] = StrEnc.header(strmeta) end
    if nummeta.needs_bxor then
      header[#header + 1] = nummeta.bxor_marker ..
        "=function(a,b)local r,p=0,1 for j=1,32 do local x,y=a%2,b%2 if x~=y then r=r+p end a=(a-x)/2 b=(b-y)/2 p=p*2 end return r end"
    end
  end

  if mode == "source" then
    if not opts.no_deadcode then DeadCode.run(ast, seed, {}) end
    -- NOTE: statement-level CFF breaks lexical scoping across states
    -- (locals defined in one state are invisible in others). Only enabled
    -- on explicit opt-in; the VM mode supersedes it structurally.
    if opts.cfflatten == "on" then CFF.run(ast, seed, { mode = mode }) end
    local body = Printer.print(ast)
    local out = {}
    out[#out + 1] = "--" .. WATERMARK
    out[#out + 1] = "--seed:" .. seed .. " mode:source"
    if protected then
      local payload = body
      if #header > 0 then payload = table.concat(header, "\n") .. "\n" .. payload end
      local payload_key = rng.int(1, 2147483000)
      local source_seed_a = Integrity.hash("SKX3/SRC/F",
        bitutil.bxor(payload_key, seed))
      local source_seal_a = Integrity.hash(payload, source_seed_a, false)
      local source_seed_b = Integrity.hash("SKX3/SRC/R",
        bitutil.bxor(source_seal_a, payload_key))
      local source_seal_b = Integrity.hash(payload, source_seed_b, true)
      payload = "SKX3SRC\n" .. i32le(source_seal_a) .. i32le(source_seal_b) .. payload
      local encrypted_payload = Integrity.crypt(payload, payload_key)
      local chunked = {}
      local size = math.max(200, math.ceil(#encrypted_payload / 4))
      local i = 1
      while i <= #encrypted_payload do
        chunked[#chunked + 1] = encrypted_payload:sub(i, i + size - 1)
        i = i + size
      end
      if #chunked == 0 then chunked[1] = "" end

      local decls, names = {}, {}
      for ci, c in ipairs(chunked) do
        decls[#decls + 1] = "local __SKX_SEG_" .. ci .. '="' ..
          Printer.escape_string(c) .. '"'
        names[#names + 1] = "__SKX_SEG_" .. ci
      end
      local manifest = Integrity.create(chunked, seed)
      local wrapped_key = Integrity.wrap(payload_key,
        bitutil.bxor(manifest.link, protection.token_c))
      out[#out + 1] = table.concat(decls, "\n")
      out[#out + 1] = "local __SKX_SEG={" .. table.concat(names, ",") .. "}"
      out[#out + 1] = source_protection_block(manifest, wrapped_key, protection, seed, env_logger_src)
      -- boundary telemetry: use logger phase helper if present, otherwise no-op
      local _env_log_src = ""
      if env_policy.enabled then
        _env_log_src = [[
 if __skx_log.emit then __skx_log.emit("INTEGRITY_PHASE","ok",{phase="decrypt_start"}) end
]]
      end
      out[#out + 1] = _env_log_src .. [[local __skx_src=__skx_decrypt(table.concat(__SKX_SEG),__skx_key)
 if #__skx_src<16 or __skx_src:sub(1,8)~="SKX3SRC\n" then __skx_fail() end
 local function __skx_u32(s,p)
   local a,b,c,d=s:byte(p,p+3)
   if not d then __skx_fail() end
   return a+b*256+c*65536+d*16777216
 end
 local __skx_src_a,__skx_src_b=__skx_u32(__skx_src,9),__skx_u32(__skx_src,13)
 __skx_src=__skx_src:sub(17)
 local __skx_sa=__skx_hs("SKX3/SRC/F",__skx_xor32(__skx_key,__skx_seed))
 __skx_sa=__skx_hs(__skx_src,__skx_sa,false)
 local __skx_sb=__skx_hs("SKX3/SRC/R",__skx_xor32(__skx_sa,__skx_key))
 __skx_sb=__skx_hs(__skx_src,__skx_sb,true)
 if __skx_sa~=__skx_src_a or __skx_sb~=__skx_src_b then __skx_fail() end
]] .. (env_policy.enabled and [[ if __skx_log.emit then __skx_log.emit("INTEGRITY_PHASE","ok",{phase="integrity_ok"}) end
]] or "") .. [[ __skx_guard(true)
 if __skx_canary_recheck then __skx_canary_recheck() end
]] .. (env_policy.enabled and [[ if __skx_log.emit then __skx_log.emit("HOOK_STATE","ok",{}) end
]] or "") .. [[ local __skx_loader=load or loadstring
 if type(__skx_loader)~="function" then __skx_fail() end
]] .. (env_policy.enabled and [[ if __skx_log.emit then __skx_log.emit("INTEGRITY_PHASE","ok",{phase="load_start"}) end
]] or "") .. [[ local __skx_f,__skx_err=__skx_loader(__skx_src,"=skynox")
 if type(__skx_f)~="function" then __skx_fail() end
 do
   local t=__SKX_SEG
   if type(t)=="table" then for i=1,#t do t[i]=nil end end
   __SKX_SEG=nil
   __skx_src=nil
   if collectgarbage then pcall(collectgarbage) end
 end
]] .. (env_policy.enabled and [[ if __skx_log.emit then __skx_log.emit("INTEGRITY_PHASE","ok",{phase="wipe_ok"}) end
 if __skx_log.emit then __skx_log.emit("END","ok",{dropped=__skx_log.dropped or 0}) end
]] or "") .. [[ if __skx_canary_recheck then __skx_canary_recheck() end
 __skx_f()]]
    else
      out[#out + 1] = table.concat(header, "\n")
      out[#out + 1] = body
    end
    return table.concat(out, "\n"), { mode = mode, seed = seed, envlogger = {enabled=env_policy.enabled, mode=env_policy.mode, build_id=env_policy.build_id, schema=env_policy.schema} }
  end

  ------------------------------------------------------------------ vm mode
  -- Hardened pipeline: numeric operator ids -> binary blob ->
  -- cascade-encrypted segments -> integrity manifest -> decode -> engine.
  local BinFmt = require("binfmt")
  local Emit2 = require("emit2")

  local binmap, unmap = Gen.make_binmaps(rng)
  local root = Compiler.compile(ast, { binmap = binmap, unmap = unmap })
  local opmap, invmap = Gen.make_opmap(rng)
  root.opmap, root.invmap = opmap, invmap

  -- Konstant-index whitening: konstant slots are XORed with a per-build
  -- mask so heap-dumped interpreter frames reveal nothing. Unwrapped
  -- lazily inside KKREF via the same _x8 used for opcode masking.
  local kmask = rng.int(1, 16777215)
  local kmask_a = rng.int(1, 2147483647)
  local kmask_b = bitutil.bxor(kmask, kmask_a) % 4294967296
  do
    local function whiten(node)
      if type(node) ~= "table" then return end
      local kind = node.op or node[1]
      local is_expr = node.op ~= nil
      if is_expr then
        for _, child in ipairs(node.a) do
          if type(child) == "table" then whiten(child) end
        end
      else
        for i = 2, #node do
          local child = node[i]
          if type(child) == "table" then whiten(child) end
        end
      end
      if kind == "KON" then
        if is_expr then
          local cur = node.a[1]
          if type(cur) == "number" then node.a[1] = bitutil.bxor(cur % 16777216, kmask) end
        else
          if type(node[2]) == "number" then node[2] = bitutil.bxor(node[2] % 16777216, kmask) end
        end
      elseif kind == "MCALL" then
        if is_expr then
          local cur = node.a[2]
          if type(cur) == "number" then node.a[2] = bitutil.bxor(cur % 16777216, kmask) end
        else
          if type(node[3]) == "number" then node[3] = bitutil.bxor(node[3] % 16777216, kmask) end
        end
      elseif not is_expr and (kind == "SETGFN" or kind == "GFOR") then
        if type(node[2]) == "number" then node[2] = bitutil.bxor(node[2] % 16777216, kmask) end
      end
    end
    for _, proto in ipairs(root.allprotos) do whiten(proto.body) end
  end

  -- Crypto material is wrapped with verified payload seals before embedding.
  local ivseed = rng.int(1, 2147483000)
  local kseed_inner = rng.int(1, 2147483000)
  local sbox = BinFmt.make_sbox(rng)
  local wire_profile = BinFmt.make_profile(rng)

  -- 1) raw binary encode with a build-specific opcode mask.
  local mask = rng.int(1, 2147483000)
  local rawblob = BinFmt.encode(root, {
    mask = mask,
    keystream_seed = kseed_inner,
    profile = wire_profile,
    rng = rng,
  })
  rawblob = BinFmt.authenticate(rawblob, {
    mask = mask,
    keystream_seed = kseed_inner,
    ivseed = ivseed,
    profile = wire_profile,
  })

  -- 2) cascade encrypt whole blob
  local enc = BinFmt.encrypt(rawblob, ivseed, sbox)

  -- 3) split into independently checked payload segments.
  local pieces = {}
  do
    local nseg = rng.int(3, 7)
    local size = math.max(1, math.ceil(#enc / nseg))
    local i = 1
    while i <= #enc do
      pieces[#pieces + 1] = enc:sub(i, i + size - 1)
      i = i + size
    end
  end

  local decls, names, chunked, order = {}, {}, {}, {}
  for i, txt in ipairs(pieces) do
    names[#names + 1] = "__SKX_SEG_" .. i
    chunked[#chunked + 1] = txt
    order[i] = i
  end
  for i = #order, 2, -1 do
    local j = rng.int(1, i)
    order[i], order[j] = order[j], order[i]
  end
  for _, i in ipairs(order) do
    decls[#decls + 1] = ('local __SKX_SEG_%d="%s"'):format(
      i, Printer.escape_string(pieces[i]))
  end

  local manifest = Integrity.create(chunked, seed)
  local wrapped_mask = Integrity.wrap(mask, manifest.forward)
  local wrapped_iv = Integrity.wrap(ivseed, manifest.reverse)
  local wrapped_key = Integrity.wrap(kseed_inner, manifest.link)

  if protected then
    wrapped_mask = Integrity.wrap(mask,
      bitutil.bxor(manifest.forward, protection.token_a))
    wrapped_iv = Integrity.wrap(ivseed,
      bitutil.bxor(manifest.reverse, protection.token_b))
    wrapped_key = Integrity.wrap(kseed_inner,
      bitutil.bxor(manifest.link, protection.token_c))
  end

  local out = {}
  out[#out + 1] = "--" .. WATERMARK
  out[#out + 1] = "--seed:" .. seed .. " mode:vm"
  out[#out + 1] = "--" .. WATERMARK
  out[#out + 1] = Emit2.assemble({
    banner = WATERMARK,
    mockery = MOCKERY,
    seed = seed,
    wrapped_mask = wrapped_mask,
    wrapped_iv = wrapped_iv,
    wrapped_key = wrapped_key,
    seg_decls = decls,
    seg_refs = names,
    integrity_src = Integrity.runtime(manifest, "__mock"),
    guard_src = protected and Protection.runtime(protection, "__mock", MOCKERY) or "",
    guard_tokens = protected and protection or nil,
    env_logger_src = env_logger_src,
    env_policy = env_policy,
    wire_profile = wire_profile,
    sbox_str = sbox.str,
    opmap = opmap,
    binmap = binmap,
    unmap = unmap,
    kmask_a = kmask_a,
    kmask_b = kmask_b,
    mangle_rng = rng,
  })

  return table.concat(out, "\n"), { mode = mode, seed = seed, envlogger = {enabled=env_policy.enabled, mode=env_policy.mode, build_id=env_policy.build_id, schema=env_policy.schema} }
end

B.WATERMARK = WATERMARK
B.MOCKERY = MOCKERY
return B
