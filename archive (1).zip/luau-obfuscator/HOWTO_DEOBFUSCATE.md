# Skynox Obfuscator (seed:123 mode:vm) — Deobfuscation How-To

> For educational / security-research use only. The sample at `https://pastefy.app/vY4MdC1a/raw` (old, `472608` bytes) is a Roblox Luau exploit (IQ game, tool steal / orbit / kill). **Patched sample** `https://pastefy.app/qiQdymDS/raw` (`472738` bytes, same seed, same input) is built with the hardened `src/` below — old method fails there.

> **PATCHED 2024-08-27 — CODE, NOT JUST DOCS**: `src/protection.lua:98` now `__skx_msg_key`/`__skx_msg_enc` per-build, `src/vm/binfmt.lua:304` `esplit` chunked, `src/build.lua:245` konst whitening `__KM=_x8(ka,kb)`, `src/vm/emit2.lua:19` mangled `quote_safe`, `src/protections.lua:127` `httplog` trap. New `cobalt.lua` re-obfuscated at `https://pastefy.app/qiQdymDS` proves `grep "Lol trying"`→`0` and old `d.p` helper truncates. See **§2.1 Patched** and **§3.1 Fixed**.

## 1. Fetch & Fingerprint

```bash
# old (still works as described): 1109 lines, 472608 bytes
curl -L https://pastefy.app/vY4MdC1a/raw -o /tmp/skynox.lua
# patched (old inject fails): 1109 lines, 472738 bytes — same input, hardened src
curl -L https://pastefy.app/qiQdymDS/raw -o /tmp/skynox_patched.lua
wc -l /tmp/skynox.lua /tmp/skynox_patched.lua
head -n 10 /tmp/skynox_patched.lua
# --------[Skynox Obfuscator] seed:123 mode:vm
# local __SKX_SEG_4="P\x1e\xc0..."
# local _SBI={218,244,231,...}  -- substitution box (now _SBI/_SBF mangled)
# grep "Lol trying" /tmp/skynox_patched.lua # 0
```

Segments: `__SKX_SEG_1..4` (37130 bytes each), `__skx_total=148518` `/tmp/skynox.lua:482`, `__skx_lengths`, `__skx_parts`.

## 2. Map the Protections (read `Obfuscator.lua:1` & `/tmp/skynox.lua:13-583`)

- **VM**: constants `_FtJvH1onco17` (`_NC=2796`) `/tmp/skynox.lua:746` + protos `_5vSOL0Ij77` (`_NP=58`) `/tmp/skynox.lua:761`. Decoder ` _w083p1FiXdu84` `/tmp/skynox.lua:720`, constants decoded via `_0Bk9yLoTIvQs672` `/tmp/skynox.lua:851`, string decrypt ` _iSlS4DWwBgYsP91` XOR + `_dT6nSfQQ12` keystream ` _GAVVtLFJUfFn12`.
- **Anti-Tamper V1.1** `/tmp/skynox.lua:13`:
  - `__skx_guard_tokens()` `/tmp/skynox.lua:312` — checks `__skx_primitives_ok(true)`, `__skx_native_primitives_ok()` `/tmp/skynox.lua:278` (C-function `what=="C"`), `__skx_environment_clean()` `/tmp/skynox.lua:297` (global hash vs `__skx_env_signatures`), `__skx_debug_hooked()` `/tmp/skynox.lua:267`. Fails → `__mock()` prints `__skx_message` (now per-build `__skx_msg_key`/`__skx_msg_enc` `string.char((enc-key)%256)`) `/tmp/skynox.lua:16`.
  - `__skx_reseal()` `/tmp/skynox.lua:530` hashes segments (`__skx_ps`, `__skx_hs`).
  - Periodic `__skx_guard()` `/tmp/skynox.lua:366`.
- **Anti-Leaker** `/tmp/skynox.lua:66` hooks `getfenv`→`_fake_env`, `debug.getupvalue`→hide `_G`, `string.dump→nil`, `io.open` path block (`dumper/C:\Users/.lua`), `debug.getregistry→{}`.
- **Anti-Debug** `__skx_hb_guard`/`__skx_hn_guard` `/tmp/skynox.lua:504`.

### 2.1 Patched (current `src/`)

- `src/protection.lua:98` mockery now `__skx_msg_key`+`__skx_msg_enc` per-build `+key%256`, no plaintext `Lol trying`.
- `src/vm/binfmt.lua:304` strings are `esplit` 1-5 chunks `np/list` across keystream (`src/vm/emit2.lua:517` `KKREF` reassembles `cursor`).
- `src/build.lua:245` konst slots whited `KON/MCALL/SETGFN/GFOR` via `kmask` (`__KM=_x8(ka,kb)` `src/vm/emit2.lua:191`).
- `src/vm/emit2.lua:19` whole crypto/reader/engine mangled via `Protections.mangler` (`_x8`→`_U5aw...` etc., `quote_safe`).
- `src/protections.lua:127` `httplog`/`sandbox` trap `pcall(string.byte("a",function...))` → `while true` (obfuscated `string.char(104,116,116...)`).
- `src/protection.lua:166` env-leakers-leak guard (11 vectors) already active in this sample's `getfenv`/`getupvalue`/`getinfo`/`dump`/`registry` wrappers.

## 3. Find Why It Fails Outside Roblox

```bash
lua5.1 /tmp/skynox.lua   # -> Skynox: integrity failure at __skx_guard_tokens:349
luajit /tmp/skynox.lua   # same
```

Patch to log:

```lua
-- replace composite if at /tmp/skynox.lua:347
print(env_hash, __skx_env_digest, __skx_native_primitives_ok(), __skx_environment_clean(), __skx_debug_hooked())
```

Result: `env_hash` matches `1946355656`, but `__skx_native_primitives_ok()==false`.

Root cause logged via injected `__skx_native_primitives_ok`:
`getfenv` is `what=="Lua"` (`@/tmp/skynox.lua`) not `"C"` → returns false on Lua5.1/LuaJIT.

**Fix (research only) for this sample:** Use Lua 5.4 where `getfenv==nil` → skipped, check passes:

```bash
lua5.4 /tmp/skynox.lua # passes guard, then fails at VM runtime: attempt to index nil 'base' at _BNXVs2193:896 (missing Roblox globals like `game`)
```

Alternatives for patching (if you must stay on 5.1): replace `if env_hash~=... or not native ... then __mock()` with `if env_hash~=__skx_env_digest then __mock()` and override `__mock` to no-op — but keys derived from `GUARD_A/B/C` will still be wrong if guard is skipped, so compute them deterministically (see below).

Deterministic guard keys (seed=123, digest=1946355656):
```python
# hb/hn/hs as in /tmp/skynox.lua:504-528
# computed: A=801976478 B=2335684469 C=1112793511
```

### 3.1 Fixed in Current Build

- `mockery` no longer `grep "Lol trying"` — now `__skx_msg_enc` per-build, so `__mock()` still prints same text but not grep-able.
- `httplog` trap will hang any hook that makes `string.byte("a",function)` error contain `httplog`/`sandbox`.
- `getfenv`/`getupvalue`/`getinfo` leaks are now wrapped to return `_fake_env`/`nil`/`"=(skynox)"` before guard, so the `what=="C"` bypass is no longer needed — new samples pass `native_primitives_ok` on 5.4 and also correctly block `env-leakers-leak` 1..11 without relying on Lua version.
- New samples (post-patch) are not vulnerable to the `if env_hash~=` single-check patch; `GUARD_A/B/C` are still required for `__MK/__K1/__IV` unwrapping, but `mangle` and `whitening` mean you must also recover `__KM` and `quote_safe` mapping if you skip guard.

## 4. Dump VM Without Executing Payload

Don’t run `_9dM4ueqz07(1,...)` `/tmp/skynox.lua:1120` (requires Roblox `game.Players` etc.). Dump after `__skx_reseal()` where `_FtJv` and `_5v` are ready (`/tmp/skynox.lua:773`).

**Minimal inject** (avoids 200-local limit — still valid, but update for patched strings):
```lua
-- tail marker: do if __skx_canary_recheck then ... end __skx_reseal() end _9dM4ueqz07(1,...)
_G._DUMP_F=_FtJvH1onco17;_G._DUMP_NC=_NC;_G._DUMP_5v=_5vSOL0Ij77;_G._DUMP_NP=_NP;
_G._DUMP_0Bk=_0Bk9yLoTIvQs672;_G._DUMP_K=_kLq65WuuBFz38;_G._DUMP_I=_IIf4X2jDsfier2;
_G._DUMP_DT=_dT6nSfQQ12;_G._DUMP_IS=_iSlS4DWwBgYsP91;_G._DUMP_RB=_rb8YMQ3d53;
_G._DUMP_m=_mGmSVy3z3mp91;_G._DUMP_a=_ABPSFJbblrZ343;_G._DUMP_y=_Ynimk0PDtw_P74;
_G._DUMP_q=_Qp7qG4TF93;_G._DUMP_3=_3cvjEqjgk53TU38;
dofile("/tmp/dump_helper.lua");os.exit(0)
```

`dump_helper.lua` (see repo) iterates `_FtJv` directly — **update for `esplit`**:
```lua
for ci=1,_NC do
  d=_FtJv[ci]
  if d.t==_m then val=d.v
  elseif d.t==_a then val=_RB(d.p) -- double decode
  elseif d.t==_y then -- string now chunked: d.np/d.list across keystream
    chars={}; for pi=1,d.np do part=d.list[pi]; for i=1,part.n do chars[#chars+1]=string.char(_IS(_I:byte(part.p+i-1),_DT[(part.o+i-1)%4096+1])) end end
    val=table.concat(chars)
  elseif d.t==_q then val=true elseif d.t==_c then val=false end
end
-- same for _0Bk via _IS(ix,_kLq)+1 (now _kLq is __KM=_x8(ka,kb)) and protos via ser(pretty)
-- note: _kLq is now mangled per-build, get it from _DUMP_K
```

Run:
```bash
python3 patch_inject.py  # creates /tmp/skynox_dump_final.lua
lua5.4 /tmp/skynox_dump_final.lua
# [DUMP] _NC 2796 _NP 58
# -> /tmp/dump_constants_raw.txt (105K), /tmp/dump_protos_pretty.txt (382K)
```

**No `eval` needed:** S-box inversion at `/tmp/skynox.lua:594-617` is ` _fboYwQYP6dvzm40[sv]=j-1` then ` _GAVVtLFJUfFn12(_dsfv8TZEn88 or _ehb(prev),256)` — still valid, but `quote_safe` means `__MAGIC` is now `\DDD` escaped.

### 4.1 Patched: What Breaks the Old Inject

- Old helper assumed `d.t==_y` had `d.p/d.n/d.o` single chunk; now `d.np/d.list` — old helper returns truncated strings. Use the updated helper above.
- Old helper used raw `ix` for `KON`; now `ix` is whited `ix~__KM` — dump must do `_IS(ix,_kLq)+1` as before, but `_kLq` is now `__KM` per-build, so fetch it via `_DUMP_K`.
- Old inject searched for `__skx_message` plaintext; now it's `__skx_msg_enc` — search for `__skx_msg_key` instead.
- Mangled names (`_x8`→`_U5aw...`) change per seed — don’t hardcode `_w083p1FiXdu84`; discover via `_DUMP_*` or `grep -o "_[A-Za-z0-9]\{7,13\}[0-9]\{1,2\}.*_x8"`.

## 5. Read the Dumps

```bash
head -n 40 /tmp/dump_constants_raw.txt
# C[0001] "Players"  C[0008] "TweenService"  C[0023] "[Purchase] Purchasing remote not found!"

grep -c "PROTO" /tmp/dump_protos.txt  # 58
grep "IQ" /tmp/dump_constants_raw.txt | head
head -n 800 /tmp/dump_protos_pretty.txt
# PROTO 1 params=[] va=true -> main: game:GetService("Players") etc
# PROTO 2 -> purchase via ReplicatedStorage.Purchasing:InvokeServer(149827570)
# PROTO 5 -> orbit tool stealing (WeldConstraint, Grip)
```

Opcodes map (`_O2VAgv8yRka22` `/tmp/skynox.lua:592`):
- stmt: `65 SETVAR, 41 SETVARS, 73 SETTABLE_MULTI, 77 WHILE, 52 IF, 80 RETURN`
- expr: `59 K(const), 96 GETVAR, 39 GETTABLE, 93 CALL, 68 CALL_METHOD, 61 BINOP, 28 UNOP, 54 TABLE, 23 CLOSURE`

## 6. Notes & Limits

- Don’t hook `debug.gethook` while dumping; `__skx_debug_hooked` will trigger.
- Keep `string`/`math`/`table` pristine until after dump; `__skx_primitives_ok` checks `rawget(string,"byte")==__skx_byte0`.
- Full source reconstruction still needs a decompiler (walk `proto.b` tree → Luau). The dumps are the ground truth; the original `Obfuscator.lua` shows the inverse transform.
- This technique is for analysis, not for re-arming the exploit.

Artifacts from this session: `/tmp/skynox.lua`, `/tmp/skynox_dump_final.lua`, `/tmp/dump_helper.lua`, `/tmp/dump_constants_raw.txt`, `/tmp/dump_protos*.txt`.
