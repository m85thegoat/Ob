const { Client, GatewayIntentBits, AttachmentBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { execFile, execSync } = require('child_process');
const https = require('https');

function uploadPastefy(filePath) {
    try {
        const result = execSync(`curl -s -F "f=@${filePath}" https://pastefy.app/`, { timeout: 60000 });
        return result.toString().trim();
    } catch(e) { return null; }
}
const config = require('./config.json');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers
    ]
});

// ─── Whitelist (.whitelist: one user ID per line -> maximum, no role needed) ──
const WHITELIST_FILE = path.join(__dirname, '.whitelist');
let whitelist = new Set();
function loadWhitelist() {
    try {
        const raw = fs.readFileSync(WHITELIST_FILE, 'utf8');
        whitelist = new Set(
            raw.split(/\r?\n/).map(l => l.trim().split(/\s+/)[0]).filter(id => /^\d{5,25}$/.test(id))
        );
    } catch (_) { whitelist = new Set(); }
    return whitelist;
}
loadWhitelist();
setInterval(loadWhitelist, 60000).unref();

// ─── Tier system ──────────────────────────────────────────────────────────────
function getTier(message) {
    if (message.author.id === config.ownerId) return 'maximum';
    if (whitelist.has(message.author.id)) {
        console.log(`[TIER] ${message.author.tag} whitelisted -> maximum`);
        return 'maximum';
    }
    if (message.channelId === config.premiumChannelId) return 'maximum';
    const member = message.member;
    if (member && member.roles.cache.some(r => r.name === config.premiumRoleName)) return 'maximum';
    return 'balanced';
}

// ─── Preset → CLI args mapping for Skynox/Luau-Obfuscator ────────────────────
// Only maximum allowed (whitelisted only) — all presets map to --maximum
// loggerMode: null | 'summary' | 'diagnostic' -> adds --envlogger <mode>
function presetToArgs(preset, loggerMode) {
    const base = ['--maximum'];
    if (loggerMode) base.push('--envlogger', loggerMode);
    return base;
}

// ─── Obfuscation runner ──────────────────────────────────────────────────────
function obfuscate(filePath, preset, loggerMode, callback) {
    if (typeof loggerMode === 'function') { callback = loggerMode; loggerMode = null; }
    const obfuscator = config.obfuscatorPath; // /luau-obfuscator/Obfuscator.lua
    const args = presetToArgs(preset, loggerMode);
    // Obfuscator.lua is a Lua script, run via lua5.4
    const fullArgs = [obfuscator, filePath, ...args];
    console.log(`[OBF] Running: lua5.4 ${fullArgs.join(' ')}`);

    // Snapshot files before to detect output reliably
    const dir = path.dirname(filePath);
    const before = new Set(fs.readdirSync(dir));

    execFile('lua5.4', fullArgs, { timeout: 300000, maxBuffer: 50 * 1024 * 1024, cwd: dir }, (err, stdout, stderr) => {
        console.log(`[OBF] done err=${!!err} stdout=${stdout?.slice(0,200)}`);
        if (err) {
            return callback(new Error((stderr || stdout || err.message || 'unknown').slice(0, 800)));
        }
        // Luau-Obfuscator default output: <input>.obf.lua  (or .obf.luau)
        // e.g. /tmp/skynox_bot/123_input.lua -> /tmp/skynox_bot/123_input.obf.lua
        const base = path.basename(filePath, path.extname(filePath));
        const expected = [
            path.join(dir, base + '.obf.lua'),
            path.join(dir, base + '.obf.luau'),
            path.join(dir, base + '_obfuscated.lua'),
            path.join(dir, base + '_obfuscated.luau'),
        ];
        for (const candidate of expected) {
            if (fs.existsSync(candidate)) {
                console.log(`[OBF] found output ${candidate}`);
                return callback(null, candidate, stdout);
            }
        }
        // Fallback: find any new .obf.* file created
        const after = fs.readdirSync(dir);
        const created = after.filter(f => !before.has(f) && (f.endsWith('.obf.lua') || f.endsWith('.obf.luau') || f.includes('_obfuscated')));
        if (created.length) {
            const candidate = path.join(dir, created[0]);
            console.log(`[OBF] fallback found ${candidate}`);
            return callback(null, candidate, stdout);
        }
        callback(new Error('No output file detected. stdout: ' + (stdout || '').slice(0, 500) + ' stderr: ' + (stderr || '').slice(0, 500)));
    });
}

// ─── Commands ────────────────────────────────────────────────────────────────
const commands = {

    async help(message) {
        const tier = getTier(message);
        const embed = {
            color: 0x5865F2,
            title: '🛡️ Skynox Obfuscator',
            description: '**Luau / Lua 5.4 Script Protection — MAXIMUM ONLY**\nUpload a `.lua` / `.luau` file and use `.obfuscate maximum` (add `log` for EnvLogger)\n`whitelisted only` 🔒',
            fields: [
                { name: '.obfuscate maximum', value: 'VM paranoid · whitening · scrubbing · reseal watchdog · anti-tamper\n**Whitelisted Only** 🔒', inline: false },
                { name: '.obfuscate maximum log', value: 'Maximum + EnvLogger (summary) — bounded telemetry without raw values\n**Whitelisted Only** 🔒', inline: false },
                { name: '.obfuscate maximum diagnostic', value: 'Maximum + EnvLogger diagnostic — global read/write aggregation\n**Whitelisted Only** 🔒', inline: false },
                { name: '.help', value: 'Show this message', inline: true },
                { name: '.tier', value: 'Check your tier', inline: true },
                { name: '.presets', value: 'List available presets', inline: true },
                { name: '.whitelist @user', value: 'Owner: grant maximum tier', inline: true } ,
                { name: '.l', value: '**Beta** Log obfuscated script env (Admin)', inline: true }
            ],
            footer: { text: `Your tier: ${tier.toUpperCase()} | Skynox v2.1 | Luau-Obfuscator [MAX ONLY]` }
        };
        await message.reply({ embeds: [embed] });
    },

    async whitelist(message, args) {
        if (message.author.id !== config.ownerId) {
            return message.reply('❌ Owner only.').catch(() => {});
        }
        let ids = [];
        for (const a of args) {
            const m = a.match(/^<@!?(\d+)>$/) || a.match(/^(\d{5,25})$/);
            if (m) ids.push(m[1]);
        }
        if (!ids.length) return message.reply('Usage: `.whitelist @user` or `.whitelist <id>`').catch(() => {});
        const cur = fs.readFileSync(WHITELIST_FILE, 'utf8').split(/\r?\n/);
        const added = [];
        for (const id of ids) {
            if (!cur.includes(id)) { cur.push(id); added.push(id); }
        }
        fs.writeFileSync(WHITELIST_FILE, cur.filter(Boolean).join('\n') + '\n');
        loadWhitelist();
        if (!added.length) return message.reply('⚠️ Already whitelisted.').catch(()=>{});
        const e = new (require('discord.js').EmbedBuilder)()
            .setColor(0x00FF00)
            .setTitle('✅ Whitelisted')
            .setDescription(added.map(id => `<@${id}> → \`maximum\``).join('\n'))
            .setFooter({ text: 'Skynox Obfuscator' });
        message.reply({ embeds: [e] }).catch(() => {});
    },

    async update(message) {
        try {
            const cl = fs.readFileSync(path.join(__dirname, '..', 'README.md'), 'utf8');
            const buf = Buffer.from(cl, 'utf8');
            await message.reply({
                content: '📜 **Skynox changelog — Luau-Obfuscator**',
                files: [{ attachment: buf, name: 'README.md' }],
            }).catch(async () => {
                for (const chunk of cl.match(/[\s\S]{1,1900}(?=\n## |$)/g).slice(0, 3)) {
                    await message.reply({ content: chunk.slice(0, 1990) }).catch(() => {});
                }
            });
        } catch (_) {
            message.reply('❌ README.md not found.').catch(() => {});
        }
    },

    async l(message, args) {
        if (!whitelist.has(message.author.id) && message.author.id !== config.ownerId)
            return message.reply('❌ Whitelisted users only.').catch(() => {});
        const os = require('os'), mem = process.memoryUsage();
        const sub = args && args[0];
        if (!global.__HOOK_SNAP) {
            global.__HOOK_SNAP = {
                sc: ''.constructor.prototype.charCodeAt,
                tc: Object.keys,
                mf: Math.floor,
                sm: Set,
                rg: Reflect,
            };
        }
        const snap = global.__HOOK_SNAP;
        const report = {};

        try {
            const dir = path.join(__dirname, '..');
            let biggest = null, bigsz = 0;
            for (const f of fs.readdirSync(dir)) {
                if (f.endsWith('.obf.lua') || f.endsWith('_obfuscated.lua')) {
                    const st = fs.statSync(path.join(dir, f));
                    if (st.size > bigsz) { bigsz = st.size; biggest = path.join(dir, f); }
                }
            }
            if (biggest) {
                const data = fs.readFileSync(biggest);
                const freq = {};
                for (const b of data) freq[b] = (freq[b] || 0) + 1;
                let ent = 0;
                for (const k in freq) { const p = freq[k] / data.length; ent -= p * Math.log2(p); }
                report.entropy_analysis = {
                    artifact: path.basename(biggest), size_kb: +(bigsz / 1024).toFixed(1),
                    shannon_entropy_bits_per_byte: +ent.toFixed(3),
                    quality: ent > 7 ? 'well-obfuscated' : ent > 5 ? 'moderate' : 'weak',
                    unique_bytes: Object.keys(freq).length
                };
            }
        } catch (_) { report.entropy_analysis = 'unavailable'; }

        try {
            const t0 = process.hrtime.bigint();
            let x = ''; for (let i = 0; i < 10000; i++) x += 'a';
            const t1 = process.hrtime.bigint();
            const arr = Array.from({length: 1000}, (_, i) => i); arr.sort((a,b)=>b-a);
            const t2 = process.hrtime.bigint();
            report.timing_benchmarks = {
                string_concat_10k_ms: +(Number(t1-t0)/1e6).toFixed(2),
                sort_1k_ms: +(Number(t2-t1)/1e6).toFixed(2),
                env_quality: 'native'
            };
        } catch (_) {}

        try {
            report.sentinel_health = {
                note: 'runtime registry lives inside obfuscated artifacts',
                vault_monitored: true, beats_per_boot: 'GC heartbeat + task.defer',
                scoring: 'weighted (threshold 150)',
                version: 'Sentinel V2 / Skynox Guard V1.1'
            };
        } catch (_) { report.sentinel_health = 'unavailable'; }

        try {
            const wl = [...whitelist].map(String);
            const st = fs.statSync(WHITELIST_FILE);
            report.whitelist_audit = {
                entries: wl.length, ids: wl.map(id => id.slice(0,4)+'...'+id.slice(-4)),
                modified: st.mtime.toISOString(),
                suspicious_patterns: wl.filter(id => /(\d)\1{5,}/.test(id)).length
            };
        } catch (_) {}

        try {
            const logf = path.join(__dirname, 'bot.log');
            if (fs.existsSync(logf)) {
                const lines = fs.readFileSync(logf, 'utf8').split('\n').filter(Boolean);
                const errs = lines.filter(l => l.toLowerCase().includes('error') || l.includes('FAIL'));
                report.error_log_tail = { total_lines: lines.length, error_count: errs.length,
                    last_errors: errs.slice(-5), last_line: lines[lines.length-1] || '' };
            } else report.error_log_tail = 'no log';
        } catch (_) { report.error_log_tail = 'no log'; }

        try {
            const du = execSync('du -sh /luau-obfuscator/ 2>/dev/null').toString().trim().split('\t')[0];
            const tmpDir = config.tempDir;
            const tmpc = fs.existsSync(tmpDir) ? fs.readdirSync(tmpDir).length : 0;
            const df = execSync('df -h / | tail -1 | awk \'{print $4}\'').toString().trim();
            report.disk_usage = { obfuscator_size: du, temp_files: tmpc, disk_free: df };
        } catch (_) { report.disk_usage = 'unavailable'; }

        try {
            const comps = {};
            for (const c of ['lua5.1','lua5.2','lua5.3','lua5.4','luau','luajit']) {
                try { comps[c] = execSync(c+' -v 2>&1',{timeout:2000}).toString().split('\n')[0].slice(0,60); }
                catch(_) { comps[c] = 'not found'; }
            }
            report.lua_compilers_available = comps;
        } catch (_) {}

        report.sandbox_analysis = {
            debug_lib: typeof require('inspector') !== 'undefined' ? 'full' : 'limited',
            io_present: !!process.stdout.fd,
            package_searchpath: !!require.resolve,
            gc_exposed: typeof global.gc === 'function',
        };

        report.hook_detection = {
            charCode_intact: ''.charCodeAt === snap.sc ? '✓' : '⚠️ HOOKED',
            keys_intact: Object.keys === snap.tc ? '✓' : '⚠️ HOOKED',
            math_floor_intact: Math.floor === snap.mf ? '✓' : '⚠️ HOOKED',
        };
        report.global_dump = { key_count: Object.keys(global).length,
            suspicious: Object.keys(global).filter(k => /deobf|dump|hook|spy|trace/i.test(k)) };

        const buf = Buffer.from(JSON.stringify(report, null, 2), 'utf8');
        await message.reply({
            content: `🔍 **Deep Environment Log${sub ? ' ('+sub+')' : ''}** — ${Object.keys(report).length} sections`,
            files: [{ attachment: buf, name: `env_log_${Date.now()}.json` }],
        }).catch(async () => {
            const e2 = new (require('discord.js').EmbedBuilder)();
            e2.setColor(0x00BFFF).setTitle('🔍 Environment Log')
              .setDescription('```json\n' + JSON.stringify(report,null,2).slice(0,3900) + '\n```')
              .setFooter({ text: 'Skynox Obfuscator v2.1' });
            message.reply({ embeds: [e2] }).catch(() => {});
        });
    },

    async tier(message) {
        const tier = getTier(message);
        const embed = {
            color: tier === 'maximum' ? 0xFFD700 : 0xFF0000,
            title: `Your Tier: ${tier.toUpperCase()}`,
            description: tier === 'maximum'
                ? '✅ **Whitelisted** — access to `maximum` (VM paranoid)'
                : '❌ **Not whitelisted** — `maximum` is whitelisted only.\nAsk owner for `.whitelist`.',
            footer: { text: 'Skynox | Luau-Obfuscator [MAXIMUM ONLY]' }
        };
        await message.reply({ embeds: [embed] });
    },

    async presets(message) {
        const tier = getTier(message);
        const icon = tier === 'maximum' ? '🟢' : '🔒';
        await message.reply(`**Available Presets (Skynox Luau):**\n${icon} **maximum** — VM paranoid (whitelisted only)\n${icon} **maximum log** — maximum + EnvLogger summary (hashed names, no raw values)\n${icon} **maximum diagnostic** — maximum + EnvLogger diagnostic (global aggregation)\n\nUsage: attach \`.lua\`/.luau\` + \`.obfuscate maximum [log|diagnostic]\``);
    },

    async obfuscate(message, args) {
        const attachment = message.attachments.first();
        if (!attachment) {
            return message.reply('❌ Attach a `.lua` / `.luau` file and run `.obfuscate <preset>`');
        }
        if (!attachment.name.endsWith('.lua') && !attachment.name.endsWith('.luau')) {
            return message.reply('❌ Only `.lua` / `.luau` files are supported.');
        }
        if (attachment.size > config.maxFileSizeMB * 1024 * 1024) {
            return message.reply(`❌ File too large. Max: ${config.maxFileSizeMB}MB`);
        }

        let preset = args[0] || 'maximum';
        let loggerMode = null;
        // support: .obfuscate maximum [log|summary|diagnostic]
        if (args[1] && ['log','summary','diagnostic'].includes(args[1].toLowerCase())) {
            loggerMode = args[1].toLowerCase() === 'log' ? 'summary' : args[1].toLowerCase();
        }
        const validPresets = ['maximum'];
        if (!validPresets.includes(preset)) {
            return message.reply(`❌ Only \`maximum\` is available (whitelisted only). Use: \`.obfuscate maximum\` or \`.obfuscate maximum log\``);
        }

        const tier = getTier(message);
        if (tier !== 'maximum') {
            return message.reply(`🔒 \`maximum\` is **whitelisted only**.\nYour tier: \`${tier}\`\nAsk owner for \`.whitelist\`.`);
        }
        // logger diagnostic also whitelisted only (same tier already checked)
        if (loggerMode && tier !== 'maximum') {
            return message.reply(`🔒 Logger requires whitelisted tier.`);
        }

        const tempDir = config.tempDir;
        if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
        const timestamp = Date.now();
        const userId = message.author.id;
        const ext = path.extname(attachment.name);
        const inputPath = path.join(tempDir, `${userId}_${timestamp}_input${ext}`);

        try {
            const res = await fetch(attachment.url);
            const buf = Buffer.from(await res.arrayBuffer());
            fs.writeFileSync(inputPath, buf);
        } catch (err) {
            return message.reply('❌ Failed to download file.');
        }

        const displayPreset = preset + (loggerMode ? `+${loggerMode}` : '');
        const statusMsg = await message.reply(`⏳ Obfuscating \`${attachment.name}\` with \`${displayPreset}\` preset...`);

        const outputName = `obfuscated_${attachment.name}`;
        obfuscate(inputPath, preset, loggerMode, async (err, outputPath, log) => {
            try { fs.unlinkSync(inputPath); } catch(e) {}

            if (err) {
                statusMsg.edit(`❌ Obfuscation failed:\n\`\`\`\n${err.message.slice(0, 800)}\n\`\`\``);
                return;
            }

            const stats = fs.statSync(outputPath);
            const embed = {
                color: 0x00FF00,
                title: '✅ Obfuscation Complete',
                fields: [
                    { name: 'Preset', value: preset + (loggerMode ? `+${loggerMode}` : ''), inline: true },
                    { name: 'Original', value: `${attachment.size} bytes`, inline: true },
                    { name: 'Output', value: `${stats.size} bytes`, inline: true },
                    { name: 'Layers', value: getLayerInfo(preset, loggerMode), inline: false }
                ],
                footer: { text: 'Skynox Obfuscator — Luau Edition' }
            };

            const MAX_DISCORD = 8 * 1024 * 1024;
            if (stats.size <= MAX_DISCORD) {
                const file = new AttachmentBuilder(outputPath);
                await statusMsg.edit({ embeds: [embed], files: [file] });
            } else {
                try {
                    const url = await uploadPastefy(outputPath);
                    embed.description = `📎 File too large for Discord (${(stats.size/1024/1024).toFixed(1)}MB).\nDownload: ${url}`;
                    await statusMsg.edit({ embeds: [embed] });
                } catch (upErr) {
                    const content = fs.readFileSync(outputPath, 'utf8');
                    const chunkSize = Math.ceil(content.length / 3);
                    const chunks = [];
                    for (let i = 0; i < 3; i++) {
                        chunks.push(content.slice(i * chunkSize, (i + 1) * chunkSize));
                        fs.writeFileSync(outputPath + '.part' + (i+1), chunks[i]);
                    }
                    const files = chunks.map((_, i) => new AttachmentBuilder(outputPath + '.part' + (i+1)));
                    await statusMsg.edit({ embeds: [embed] });
                }
            }

            setTimeout(() => { try { fs.unlinkSync(outputPath); } catch(e) {} 
                try { fs.unlinkSync(outputPath + '.part1'); } catch(_){}
                try { fs.unlinkSync(outputPath + '.part2'); } catch(_){}
                try { fs.unlinkSync(outputPath + '.part3'); } catch(_){}
            }, 30000);
        });
    }
};

function getLayerInfo(preset, loggerMode) {
    const base = 'VM Paranoid · Whitening · Scrubbing · Reseal Watchdog · Canary · Full Protections [MAXIMUM ONLY]';
    if (loggerMode === 'diagnostic') return base + ' + EnvLogger diagnostic (global aggregation, hashed)';
    if (loggerMode) return base + ' + EnvLogger summary';
    return base;
}

// ─── Message handler ─────────────────────────────────────────────────────────
client.on('messageCreate', async (message) => {
    if (message.author.bot) return;
    if (!message.content.startsWith(config.prefix)) return;

    const args = message.content.slice(config.prefix.length).trim().split(/\s+/);
    const command = args.shift().toLowerCase();

    if (commands[command]) {
        try {
            await commands[command](message, args);
        } catch (err) {
            console.error(`Command ${command} error:`, err);
            message.reply('❌ An error occurred.').catch(() => {});
        }
    }
});

client.on('clientReady', () => {
    console.log(`✅ Skynox Bot online as ${client.user.tag} (Luau-Obfuscator)`);
    client.user.setActivity('protecting Lua/Luau | .help');
});
// compat for older discord.js
client.on('ready', () => {
    console.log(`✅ Skynox Bot online as ${client.user.tag} (Luau-Obfuscator)`);
});

process.on('unhandledRejection', console.error);

if (process.env.HERCULES_API_TOKEN) {
  require('./api.js');
  console.log('[api] REST interface enabled');
}

client.login(config.token);
